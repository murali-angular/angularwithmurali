import React from 'react';
import './App.css';
import MainContent from './components/MainContent';


class App extends React.Component {
  render() {
    return (
      <div>
        <MainContent />
      </div>
    )
  }
}

export default App;
