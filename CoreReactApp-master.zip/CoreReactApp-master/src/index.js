import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Link, BrowserRouter as Router, Switch, Redirect} from 'react-router-dom';
import MainContent from './components/MainContent';
import Header from './components/Header';
import Footer from './components/Footer';
import Enquiry from './components/Enquiry';
import Notfound from './components/Enquiry';
import Product from './components/products';

const routing = (
  <Router>
    <Header />
    <Switch>
      <Route exact path="/" component={App} />
      <Route path="/home" component={MainContent} />
      <Route path="/enquiry" component={Enquiry} />
      <Route path = "/products" component = {Product} />
      <Route component={Notfound} />
      <Redirect from='*' to='/' />
    </Switch>
    <Footer />
  </Router>
)

ReactDOM.render(routing, document.getElementById('root'));
// ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
