import React from 'react';

class Product extends React.Component {

    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-4">
                        <span>rgerg</span>
                    </div>
                    <div className="col-md-4">
                        <span>rgerg</span>
                    </div>
                    <div className="col-md-4">
                        <span>rgerg</span>
                    </div>
                </div>
            </div>
        )
    }

}

export default Product;
