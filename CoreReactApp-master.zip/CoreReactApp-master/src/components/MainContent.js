import React from 'react';

class MainContent extends React.Component {
    render() {
        return (
            <div className="how-section1">
                <div className="row">
                    <div className="col-md-6 how-img">
                        <img src="https://image.ibb.co/dDW27U/Work_Section2_freelance_img1.png" className="rounded-circle img-fluid"
                            alt="" />
                    </div>
                    <div className="col-md-6">
                        <h4>Find Hospitals</h4>
                        <h4 className="subheading">Ambufree is a great place to find more hospitals</h4>
                        <p className="text-muted">
                            Find hospitals. You can search the Hospitals website to locate public and private hospitals across
                            hyderabad. Simply enter the name of the hospital into the search box, or enter your Area.
            </p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <h4>Find Right Doctor</h4>
                        <h4 className="subheading">Find Right Doctor and Book Instant Appointment</h4>
                        <p className="text-muted">
                            Choosing a new doctor can be a challenge, especially if you have moved to a new community. Asking for
                            recommendations from coworkers, neighbors, and friends is a good way to start, but ultimately you will
                            have to decide which physician is best suited to your individual needs and situation.
            </p>
                    </div>
                    <div className="col-md-6 how-img">
                        <img src="https://image.ibb.co/cHgKnU/Work_Section2_freelance_img2.png" className="rounded-circle img-fluid"
                            alt="" />
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6 how-img">
                        <img src="https://image.ibb.co/ctSLu9/Work_Section2_freelance_img3.png" className="rounded-circle img-fluid"
                            alt="" />
                    </div>
                    <div className="col-md-6">
                        <h4>Get Hospital Ambulance</h4>
                        <h4 className="subheading">Avail Hospital Ambulance across Hyderabad</h4>
                        <p className="text-muted">Free ambulance services will be provided.To avail Hospital ambualnce you need to
                            provide
                contact details.</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <h4>Instant Ambulance</h4>
                        <h4 className="subheading">Book Ambualnce across Hyderabad anytime anywhere</h4>
                        <p className="text-muted">Can book ambualnce for schedule dates or events etc.Our ambulances contain all the
                modern equipments necessary for patients.</p>
                    </div>
                    <div className="col-md-6 how-img">
                        <img src="https://image.ibb.co/gQ9iE9/Work_Section2_freelance_img4.png" className="rounded-circle img-fluid"
                            alt="" />
                    </div>
                </div>
            </div>
        )
    }
}

export default MainContent