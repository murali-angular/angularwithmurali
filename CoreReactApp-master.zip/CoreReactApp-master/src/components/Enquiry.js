import React from 'react';

class Enquiry extends React.Component {

    constructor() {
        super()
        this.state = {
            PersonName: ''
        }
        this.handleInput.bind()
    }

    handleInput() {
        this.setState({ PersonName: document.getElementsByName('PersonName').value })
    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-6">
                        <input type="text" name="PersonName" value={this.setState.PersonName} onChange={this.handleInput} />
                    </div>
                </div>
            </div>
        )
    }
}

export default Enquiry