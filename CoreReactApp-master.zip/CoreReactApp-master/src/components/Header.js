import React from 'react';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import logo from '../common/images/logo.png';

class Header extends React.Component {
    render() {
        return (
            <Navbar sticky="top" collapseOnSelect expand="lg" bg="dark" variant="dark">
                {/* <Navbar.Brand><img className="logostyle" src={logo} /></Navbar.Brand> */}
                <Navbar.Brand>title</Navbar.Brand>
                <Navbar.Collapse id="responsive-navbar-nav" className="dropdown-link">
                    <Nav>
                        <NavDropdown title="My Profile" id="collasible-nav-dropdown">
                            <NavDropdown.Item>Action</NavDropdown.Item>
                            <NavDropdown.Item>Another action</NavDropdown.Item>
                        </NavDropdown>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

        )
    }
}

export default Header