export const environment = {
  production: true,
  prod_URL: 'https://ambufree.com'
};
