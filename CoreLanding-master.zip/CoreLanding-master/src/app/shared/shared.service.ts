import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment.prod';
import { Contact } from './common/contactus';
import { MessageModel } from './common/message';
import { ScheduleAmb } from './common/scheduleAmb';

@Injectable({
  providedIn: 'root'
})
export class SharedService {


  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Contact/InsertContactEnquiry';
  messageurl = environment.prod_URL + 'Message/SendMessageFreeAmb';
  mailurl = environment.prod_URL + 'MailMessage/RegisterPatientMail';
  postscheduleurl = environment.prod_URL + 'ScheduleAmbulance/InsertScheduleAmb';

  public sendenquiry(contactobj: Contact): Observable<any> {
    return this.http.post(this.posturl, contactobj);
  }

  public MessageToPatient(message: MessageModel) {
    return this.http.post(this.messageurl, message);
  }

  public BookScheduleAmb(contactobj: ScheduleAmb): Observable<any> {
    return this.http.post(this.postscheduleurl, contactobj);
  }

}
