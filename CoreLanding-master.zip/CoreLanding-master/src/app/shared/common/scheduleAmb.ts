export class ScheduleAmb {
    ScheduleAmbId: number;
    GuestName: string;
    GuestNumber: string;
    GuestFromAddress: string;
    GuestToAddress: string;
    GuestRemarks: string;
    BookedDateTime: Date;
    ScheduleStatus: string;
    AddedDate: Date;
    EditDate: Date;
}
