export class HospDetails {
    HospId: any;
    SignUpID: any;
    AgentId: any;
    HospName: string;
    HospMail: string;
    HospNum: string;
    HospAltNum: string;
    HospAddress: string;
    HospType: string;
    HospImgPath: string;
    IsSubscribe: string;
    SubscriptionPlan: string;
    HospDesc: string;
    AddedDate: Date;
    EditDate: Date;
}


export class HospAmbReg {
    HospId: string;
    HospAmbId: any;
    HospAmbName: string;
    HospAmbNumber: string;
    HospAmbEmail: string;
    HospAmbAddress: string;
    HospAmbNumberPlate: string;
    HospAmbType: string;
    HospAmbDriverName: string;
    HospAmbDriverNumber: string;
    IsSubscribe: string;
    SubscriptionPlan: string;
    HospAmbImgID: string;
    HospAmbImgPath: string;
    AddedDate: Date;
    EditDate: Date;
}

export class HospDoc {
    HospId: any;
    HospDocId: any;
    HospDocName: string;
    HospDocMail: string;
    HospDocNum: string;
    HospDocAltNum: string;
    HospDocQualification: string;
    HospDocStartTime: string;
    HospDocEndTime: string;
    HospDocSpecialization: string;
    HospDocDescription: string;
    HospDocImgPath: string;
    HospDocConsultingFee: string;
    HospDocAddress: string;
    AddedDate: Date;
    EditDate: Date;

}

