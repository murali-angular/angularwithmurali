export class BookFreeAmb {

    HospId: string;
    HospAmbId: any;
    HospAmbName: string;
    HospAmbNumber: number;
    HospAmbEmail: string;
    HospAmbAddress: string;
    HospAmbNumberPlate: string;
    HospAmbType: string;
    HospAmbDriverName: string;
    HospAmbDriverNumber: string;
    IsSubscribe: string;
    SubscriptionPlan: string;
    HospAmbImgPath: string;

    PatientID: any;
    PatientName: string;
    PatientNumber: string;
    PatientAddress: string;
    PatientCondition: string;
    PatientGender: string;
    patientMail: string;

    SelectedDate: Date;
    SelectedTime: Date;
    AddedDate: Date;
    EditDate: Date;
}
