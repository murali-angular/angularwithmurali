import { AmbRegistration } from "./ambRegistration";
import { HospDetails } from "./hospAmbReg";

export class SearchCustomAmb {
    FromLoc: string;
    ToLoc: string;
    ExactDate: Date;
}

export class SearchServiceType {
    ServiceType = 'Hospital';
    SearchbyLocation: string;
    SearchbyName: string;
    AmbType: string;
}

export class SearchEntireAmbandHospDetails {
    ambList : AmbRegistration[];
    hosplistobj : HospDetails[];
}