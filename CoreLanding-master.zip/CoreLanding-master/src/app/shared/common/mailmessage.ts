export class MailMessage {
    UserName: string;
    Password: string;
    AmbType: string;
    AmbName: string;
    SelectedDate: Date;
    SelectedTime: Date;
    AmbNum: string;
    UserNum: string;
    UserEmail: string;
    UserAddress: string;
    AmbNumberPlate: string;
    DriverName: string;
    DriverNum: string;
    ClientName: string;
    AddedDate: Date;
    EditedDate: Date;
}
