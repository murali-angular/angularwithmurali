export class PatientRegistration {
    SignUpId: any;
    PatientID: any;
    PatientName: string;
    PatientNumber: string;
    PatientAddress: string;
    PatientCondition: string;
    PatientGender: string;
    patientMail: string;
}
