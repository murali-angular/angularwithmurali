export class AmbRegistration {
    AmbId: string;
    SignUpID: string;
    AgentId: string;
    AmbName: string;
    AmbNumber: string;
    AmbAltNumber: string;
    AmbMail: string;
    AmbAddress: string;
    AmbNumberPlate: string;
    AmbType: string;
    DriverName: string;
    DriverNum: string;
    IsSubscribe: string;
    SubscriptionPlan: string;
    AmbImgPath: string;
    AmbDescription: string;
    AddedDate: Date;
    EditDate: Date;
}
