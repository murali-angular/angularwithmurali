export class Login {
    UserName: string;
    Password: any;
}

export class SignUp {
    SignUpId: any;
    UserTypeID: any;
    UserMail: string;
    UserMobile: string;
    UserPwd: string;
    AddedDate: Date;
    EditDate: Date;
}

export class ChangePwd {
    SignUpId: any;
    CurrentPwd: string;
    NewPwd: string;
    ConfirmPwd: string;
}

export class ForgotPwd{
    Number : string;
    Password : string;
}
