export class AgentRegistration {
    AgentId: any;
    AgentName: string;
    AgentNumber: string;
    AgentAltNumber: string;
    AgentMail: string;
    AgentGender: boolean;
    AgentAddress: string;
    AgentCode: string;
}
