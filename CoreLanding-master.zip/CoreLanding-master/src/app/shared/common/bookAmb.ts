export class BookAmbulance {
    AmbBookID: string;
    AmbID: any;
    AmbName: string;
    AmbNumber: number;
    AmbMail: string;
    AmbAddress: string;
    AmbNumberPlate: string;
    AmbType: string;
    DriverName: string;
    DriverNum: string;
    PatientID: string;
    PatientName: string;
    PatientNumber: string;
    PatientEmail: string;
    PatientAddress: string;
    PatientCondition: string;
    PatientGender: string;
    SelectedDate: Date;
    SelectedTime: Date;
    AddedDate: Date;
    EditDate: Date;
}


export class BookDoctorAppoint {
    BookDocId: any;
    HospDocId: any;
    PatientID: any;
    SelectedDate: string;
    SelectedTime: string;
}
