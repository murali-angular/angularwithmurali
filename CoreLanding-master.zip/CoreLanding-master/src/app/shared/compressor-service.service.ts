import { Injectable, Renderer2 } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CompressorServiceService {

  constructor(
    // renderfactory: RendererFactory2
  ) { }

  compressFile(imageDataUrlSource, render: Renderer2, ratio = 50, quality = 50) {
    /** @type {?} */
    const promise = new Promise((/**
      * @param {?} resolve
      * @param {?} reject
      * @return {?}
      */
      function (resolve, _reject) {
        quality = quality / 100;
        ratio = ratio / 100;
        /** @type {?} */
        const sourceImage = new Image();
        // important for safari: we need to wait for onload event
        sourceImage.onload = (/**
          * @return {?}
          */
          function () {
            /** @type {?} */
            const canvas = render.createElement('canvas');
            /** @type {?} */
            const ctx = canvas.getContext('2d');

            // same as default UP
            ctx.drawImage(sourceImage, 0, 0, canvas.width, canvas.height);

            /** @type {?} */
            const mime = imageDataUrlSource.substr(5, imageDataUrlSource.split(';')[0].length - 5);
            // TODO test on mime
            /** @type {?} */
            const result = canvas.toDataURL(mime, quality);
            resolve(result);
          });
        sourceImage.src = imageDataUrlSource;
      }));
    return promise;
  }


}
