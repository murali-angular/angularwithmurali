import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TermsConditionsComponent } from './terms-conditions.component';


const routes: Routes = [
  {
    path: '', component: TermsConditionsComponent,
    children: [
      {
        path: '', component: TermsConditionsComponent, data: {
          title: 'Terms and Conditions'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class TermsConditionsRoutingModule { }
