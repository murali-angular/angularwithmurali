import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, UrlSegment } from '@angular/router';


@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.css']
})
export class ErrorMessageComponent implements OnInit {

  constructor(
    private router: Router,
    private route: ActivatedRoute) {

     }

  ngOnInit() {
  }

  goLogin() {
    this.router.navigate(['/login']);
  }

}
