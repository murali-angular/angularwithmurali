import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-error-message',
  template: `<router-outlet></router-outlet>`

})
export class ParentErrorMessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
