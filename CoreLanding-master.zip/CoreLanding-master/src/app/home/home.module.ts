import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { SharedModule } from '../shared/shared.module';
import { SharedService } from '../shared/shared.service';
import { HttpClientModule } from '@angular/common/http';
import { CarouselModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CommonModule, FormsModule, HomeRoutingModule, SharedModule, HttpClientModule, CarouselModule.forRoot()
  ],
  bootstrap: [HomeComponent],
  declarations: [HomeComponent],
  providers: [SharedService],
})
export class HomeModule { }
