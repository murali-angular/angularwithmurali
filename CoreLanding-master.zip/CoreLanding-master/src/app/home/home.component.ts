import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../shared/shared.service';
import { Contact } from '../shared/common/contactus';
import { MessageModel } from '../shared/common/message';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { ScheduleAmb } from '../shared/common/scheduleAmb';
import { NotificationsService } from '../shared/notification/notifications.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [SharedService, NotificationsService]
})
export class HomeComponent implements OnInit {

  cityList = [{ name: 'Hyderabad' }, { name: 'Benguluru' }];
  serviceList = [{ name: 'Hospital' }, { name: 'Ambulance' }];

  con: Contact = new Contact();
  obj: ScheduleAmb = new ScheduleAmb();
  MessageStatement = 'Thank you for contacting AMBUFREE. We will contact you soon.www.ambufree.com';
  messagemodel: MessageModel = new MessageModel();

  modalRef: BsModalRef;

  constructor(private service: SharedService, private router: Router, private modalService: BsModalService) {

  }

  ngOnInit() {
  }


  sendContactEnquiry() {
    this.service.sendenquiry(this.con).subscribe(data => {
      // this.toastr.success('Thanks, We will contact you soon..');
      this.sendBookAmbMessageToPatient();
      this.con = new Contact();
    }, erro => {
      this.con = new Contact();
    });
  }

  sendBookAmbMessageToPatient() {
    this.messagemodel.message = this.MessageStatement;
    this.messagemodel.patName = this.con.UserName;
    this.messagemodel.numbers = this.con.UserNum;
    this.service.MessageToPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

  onclickbookAmb(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  onclickFreeAmb(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  bookAmb() {
    this.obj.ScheduleStatus = 'ScheduleBook';
    this.service.BookScheduleAmb(this.obj).subscribe(data => {

    });
  }

  SendEnquiry() {
    this.obj.ScheduleStatus = 'Enquiry';
    this.service.BookScheduleAmb(this.obj).subscribe(data => {

    });
  }

}
