import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-contact-us',
  template: `<router-outlet></router-outlet>`
})
export class ParentContactUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
