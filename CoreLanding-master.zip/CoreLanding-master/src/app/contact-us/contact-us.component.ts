import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../shared/shared.service';
import { Contact } from '../shared/common/contactus';
import { MessageModel } from '../shared/common/message';
import { MailMessage } from '../shared/common/mailmessage';
import { NotificationsService } from '../shared/notification/notifications.service';


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
  providers: [SharedService]
})
export class ContactUsComponent implements OnInit {
  con: Contact = new Contact();

  MessageStatement = 'Hi patName,Thank you for contacting AMBUFREE. We will contact you soon.www.ambufree.com';
  messagemodel: MessageModel = new MessageModel();
  mail: MailMessage = new MailMessage();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private contactservice: SharedService,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    //   setTimeout((router: Router) => {
    //     this.router.navigate(['/login']);
    // }, 10000);
  }

  sendContactEnquiry() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.contactservice.sendenquiry(this.con).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Thank You..we will contact you soon');
      this.sendBookAmbMessageToPatient();
    }, erro => {
      this.con = new Contact();
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  sendBookAmbMessageToPatient() {
    this.messagemodel.message = this.MessageStatement;
    this.messagemodel.patName = this.con.UserName;
    this.messagemodel.numbers = this.con.UserNum;
    this.contactservice.MessageToPatient(this.messagemodel).subscribe(data => {
      this.con = new Contact();
    }, erro => {
    });
  }
}
