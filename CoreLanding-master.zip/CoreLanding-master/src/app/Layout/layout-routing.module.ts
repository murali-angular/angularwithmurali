import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: '',
                redirectTo: 'home'
            },
            {
                path: 'home',
                loadChildren: '../home/home.module#HomeModule'
            },
            {
                path: 'aboutus',
                data: { title: 'About Us' },
                loadChildren: '../about-us/about-us.module#AboutUsModule'
            },
            {
                path: 'contactus',
                data: { title: 'Contact Us' },
                loadChildren: '../contact-us/contact-us.module#ContactUsModule'
            },
            {
                path: 'error',
                data: { title: '404 Error',  },
                loadChildren: '../error-message/error-message.module#ErrorMessageModule'
            },
            {
                path: 'thankyou',
                data: { title: 'Thank You',  },
                loadChildren: '../thank-you-page/thank-you-page.module#ThankYouPageModule'
            },
            {
                path: 'termsandconditions',
                data: { title: 'Thank You',  },
                loadChildren: '../terms-conditions/terms-conditions.module#TermsConditionsModule'
            },
            // {
            //     path: 'forgotpassword',
            //     data: { title: 'Forgot Password' },
            //     loadChildren: '../theme/pages/default/forgot-pwd/forgot-pwd.module#ForgotPwdModule'
            // }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LayoutRoutingModule { }
