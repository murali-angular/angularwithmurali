import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ThankYouPageComponent } from './thank-you-page.component';
import { ParentThankYouPageComponent } from './parent-thank-you-page.component';
import { ThankYouPageRoutingModule } from './thank-you-page-routing.module';
@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ThankYouPageRoutingModule
  ],
  bootstrap: [ThankYouPageComponent],
  declarations: [ThankYouPageComponent, ParentThankYouPageComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ThankYouPageModule { }
