import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';


@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {

    constructor() {

    }
    ngOnInit() {

    }

}



