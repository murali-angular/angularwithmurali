import { Pipe, PipeTransform } from '@angular/core';
import { HospDetails } from '../theme/pages/common/hospAmbReg';
@Pipe({
    name: 'searchHospFilter',
    pure: false
})
export class SearchHospFilterPipe implements PipeTransform {


    transform(items: HospDetails[], filter: HospDetails): HospDetails[] {
        if (!items || !filter) {
            return items;
        }
        return items.filter((item: HospDetails) => this.applyFilter(item, filter));
    }

    applyFilter(receive: HospDetails, filter: HospDetails): boolean {
        for (let field in filter) {
            if (filter[field]) {
                if (typeof filter[field] === 'string') {
                    if (receive[field].toString().toLowerCase().indexOf(filter[field].toString().toLowerCase()) === -1) {
                        return false;
                    }
                } else if (typeof filter[field] === 'number') {
                    if (receive[field] !== filter[field]) {
                        return false;
                    }
                }
            }
        }
        return true;
    }


}