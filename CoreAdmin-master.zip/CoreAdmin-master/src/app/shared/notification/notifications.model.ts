export class Notification {
    constructor(public type: string = '',
        public message: string = '',
        public param?: any[],
        public onClose?: boolean) {
    }
}

export class Notifications {
    constructor(public type: string = '',
        public message: string = '',
        public batchKeyMessage: any[]) {
    }
}

export class Alert {
    type: AlertType;
    message: string;
}

export enum AlertType {
    Success,
    Error,
    Info,
    Warning
}


