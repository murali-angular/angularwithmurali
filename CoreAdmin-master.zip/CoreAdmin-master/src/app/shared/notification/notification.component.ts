import { Component, OnDestroy, ViewChild, ElementRef, TemplateRef, OnInit } from '@angular/core';
import { NotificationsService } from './notifications.service';
import { Notification, AlertType, Alert } from './notifications.model';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css'],
  providers: [BsModalService]
})
export class NotificationComponent implements OnDestroy, OnInit {
  alerts: Alert[] = [];
  // alert: Alert = new Alert();
  preferModalRef: BsModalRef;
  public configModal = {
    animated: true,
    keyboard: true,
    // backdrop: true,
    // ignoreBackdropClick: true
  };

  notes: any[];
  loader = false;
  detailedMessage = '';
  loaderByStatus = false;
  message = '';
  subscription: Subscription;
  public param: any;
  // @ViewChild('detailed') detailed: ElementRef;
  // @ViewChild('copy') copy: ElementRef;
  // @ViewChild('batchkey') batchkey: ElementRef;
  // @ViewChild('staticModal') staticModal;
  // @ViewChild('copybatch') copybatch: ElementRef;
  divtext: string;
  onClose = false;
  private date = new Date();
  errorObject: { Error: string, Page: string, CreatedDate: string } = { Error: '', Page: '', CreatedDate: '' };
  settings = {
    actions: { edit: false, checkbox: false },
    NoOfrecordPage: 5,
    columns: [
      {
        //  filter: true,
        //  name: 'PUTAWAYLINENO'
      }
    ]
  };

  buttonSettings = {
    subHeader: 'MESSAGE.DETAILEDMESSAGE'
  };

  constructor(private notifications: NotificationsService, private modalService: BsModalService) {
    this.notes = new Array<Notification>();
    this.subscription = notifications.noteAdded.subscribe(note => {
      this.notes.pop();
      if (note !== undefined) {
        this.detailedMessage = '';
        this.notes.push(note);
        if (note.type === 'success') {
          setTimeout(() => { this.hide.bind(this)(note); }, 3000);
        }
        if (note.type === 'danger' || note.type === 'warn') {
          this.onClose = note.onClose;
          this.errorObject.Error = `${note.message}`;
          this.errorObject.Page = location.pathname;
          this.errorObject.CreatedDate = this.date.toLocaleString();
          const rt = note['message'].split('|');
          if (rt[1] && rt[1].substr(55, 8) === 'QSV00002') {
            this.notes.pop();
            // note['type'] = 'warn';
            // setTimeout(() => { this.hide.bind(this)(note); }, 1000);
          }

          for (let index = 1; index < rt.length; index++) {
            this.detailedMessage += rt[index];
          }


        }
        if (note.param !== undefined) {
          this.param = { VALUE1: note.param[0] };
        }
      }

    });

    notifications.loading.subscribe(status => {
      this.loader = status;
    });

    notifications.loadingByStatus.subscribe(status => {
      this.loaderByStatus = status.status;
      this.message = status.message;
    });

    notifications.chineNotification.subscribe(note => {
      if (note !== undefined) {
        this.detailedMessage = '';
        this.notes.push(note);
        this.errorObject.Error = `${note.message}`;
        this.errorObject.Page = location.pathname;
        this.errorObject.CreatedDate = this.date.toLocaleString();
        const rt = note['message'].split('|');
        for (let index = 1; index < rt.length; index++) {
          this.detailedMessage += rt[index];
        }

      }
    });

  }

  ngOnInit() {
    this.notifications.getAlert().subscribe((alert: Alert) => {
      if (!alert) {
        // clear alerts when an empty alert is received
        this.alerts = [];
        return;
      }

      // add alert to array
      this.alerts.push(alert);
    });
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }

  private hide(note) {
    // this.notifications.clearNotification();
    const index = this.notes.indexOf(note);

    if (index >= 0) {
      this.notes.splice(index, 1);
    }
    if (this.onClose) {
      window.location.reload();
    }
    this.onClose = false;
  }


  showmore(event) {
    window.open('data:text/xml;charset=utf-8,<?xml version="1.0" encoding="UTF-8"?>' + this.detailedMessage, '', '_blank');
  }

  CopyMessageToClip(status) {
    if (document.queryCommandSupported && document.queryCommandSupported('copy')) {
      const textarea = document.createElement('textarea');
      // textarea.textContent = status ? document.getElementById('newdetail').innerText : this.batchkey.nativeElement.innerText;
      textarea.textContent = document.getElementById('newdetail').innerText;
      textarea.style.position = 'fixed';  // Prevent scrolling to bottom of page in MS Edge.
      document.body.appendChild(textarea);
      textarea.select();
      try {
        const successful = document.execCommand('copy');  // Security exception may be thrown by some browsers.
        const msg = successful ? 'Copied!' : 'Whoops, not copied!';
        if (status) {
          document.getElementById('newcopy').style.color = 'green';
          document.getElementById('newcopy').setAttribute('title', msg);
        }
        // else {
        //   this.copybatch.nativeElement.style.color = 'green';
        //   this.copybatch.nativeElement.setAttribute('title', msg);
        // }
      } catch (ex) {
        console.warn('Copy to clipboard failed.', ex);
        return false;
      } finally {
        document.body.removeChild(textarea);
      }
    }
  }

  close() {
    this.preferModalRef.hide();
    document.getElementById('newcopy').style.color = 'black';
    document.getElementById('newcopy').setAttribute('title', 'copy to clipboard');
  }

  openPrefereModal(template: TemplateRef<any>) {
    this.preferModalRef = this.modalService.show(template, Object.assign({}, '', { class: 'wmx-xl' }));
  }

  removeAlert(alert: Alert) {
    this.alerts = this.alerts.filter(x => x !== alert);
  }

  cssClass(alert: Alert) {
    if (!alert) {
      return;
    }

    // return css class based on alert type
    switch (alert.type) {
      case AlertType.Success:
        return 'alert alert-success';
      case AlertType.Error:
        return 'alert alert-danger';
      case AlertType.Info:
        return 'alert alert-info';
      case AlertType.Warning:
        return 'alert alert-warning';
    }
  }

}
