import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { NotificationComponent } from './notification/notification.component';
import { NotificationsService } from './notification/notifications.service';
import { SearchFilterPipe } from './searchfilter.pipe';
import { SearchHospFilterPipe } from './searchhosp.pipe';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AngularMaterialModule } from './angular-material.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    AngularMaterialModule
  ],
  declarations: [NotificationComponent,
    SearchFilterPipe,
    SearchHospFilterPipe
  ],
  exports: [NotificationComponent,
    NotificationComponent,
    SearchFilterPipe,
    SearchHospFilterPipe,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularMaterialModule]
})

export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [NotificationsService]
    };
  }
}
