import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-about-us',
  template: `<router-outlet></router-outlet>`
})
export class ParentAboutUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
