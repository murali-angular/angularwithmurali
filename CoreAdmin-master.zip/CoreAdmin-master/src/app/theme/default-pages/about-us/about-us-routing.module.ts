import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './about-us.component';
import { ParentAboutUsComponent } from './parent-about-us.component';

const routes: Routes = [
  {
    path: '', component: ParentAboutUsComponent,
    children: [
      {
        path: '', component: AboutUsComponent, data: {
          title: 'About US'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class AboutUsRoutingModule { }
