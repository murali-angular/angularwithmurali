import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, UrlSegment } from '@angular/router';


@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {

  constructor(
    private router: Router,
    private route: ActivatedRoute) {

     }

  ngOnInit() {
    // setTimeout((router: Router) => {
    //   this.router.navigate(['/login']);
    // }, 10000);
  }

}
