import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AboutUsComponent } from './about-us.component';
import { ParentAboutUsComponent } from './parent-about-us.component';
import { AboutUsRoutingModule } from './about-us-routing.module';


@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    AboutUsRoutingModule
  ],
  bootstrap: [AboutUsComponent],
  declarations: [AboutUsComponent, ParentAboutUsComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class AboutUsModule { }
