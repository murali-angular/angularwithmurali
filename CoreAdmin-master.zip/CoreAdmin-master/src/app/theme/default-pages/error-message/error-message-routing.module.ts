import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorMessageComponent } from './error-message.component';
import { ParentErrorMessageComponent } from './parent-error-message.component';

const routes: Routes = [
  {
    path: '', component: ParentErrorMessageComponent,
    children: [
      {
        path: '', component: ErrorMessageComponent, data: {
          title: '404 Error'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class ErrorMessageRoutingModule { }
