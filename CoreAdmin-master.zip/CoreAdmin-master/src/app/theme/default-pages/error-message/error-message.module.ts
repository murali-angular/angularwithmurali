import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ParentErrorMessageComponent } from './parent-error-message.component';
import { ErrorMessageComponent } from './error-message.component';
import { ErrorMessageRoutingModule } from './error-message-routing.module';
@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ErrorMessageRoutingModule
  ],
  bootstrap: [ErrorMessageComponent],
  declarations: [ErrorMessageComponent, ParentErrorMessageComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ErrorMessageModule { }
