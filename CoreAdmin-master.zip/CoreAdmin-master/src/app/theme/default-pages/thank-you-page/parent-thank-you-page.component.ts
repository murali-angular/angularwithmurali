import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-thank-you-page',
  template : `<router-outlet></router-outlet>`
})
export class ParentThankYouPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
