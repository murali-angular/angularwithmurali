import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItems } from '../../pages/common/menu';
import { SignupService } from '../../pages/default/signup/signup.service';
import { isNullOrUndefined } from 'util';


@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
    providers: [SignupService]
})
export class HeaderComponent implements OnInit, AfterViewInit {
    MenuList: MenuItems = new MenuItems();
    MenuListObj: MenuItems[] = [];

    isNavbarCollapsed = true;

    constructor(private router: Router, private service: SignupService) {

    }

    ngOnInit() {
        this.getLocalstorage();
        this.MenusAssignedByUserType();
    }

    ngAfterViewInit() {
        this.ngOnInit();
    }

    gomyprofilepage() {
        this.router.navigateByUrl('/myprofile');
    }
    gomybookingpage() {
        this.router.navigateByUrl('/mybookings');
    }
    gochangepwdpage() {
        this.router.navigateByUrl('/changepassword');
    }
    gologoutpage() {
        this.router.navigateByUrl('/myprofile');
    }

    getLocalstorage() {
        return localStorage.getItem('loggedUser');
    }

    gomysignuppage() {
        this.router.navigateByUrl('/signup');
    }
    gologinpage() {
        this.router.navigateByUrl('/login');
    }

    onLogout() {
        localStorage.removeItem('loggedUser');
        this.MenuListObj = [];
        // this.toastr.success('You are successfully logout');
        this.router.navigate(['thankyou']);
    }

    MenusAssignedByUserType() {
        this.MenuListObj = [];
        // tslint:disable-next-line: deprecation
        if (!isNullOrUndefined(localStorage.getItem('loggedUserTypeId'))) {
            this.service.GetUserMenusByUserTypeId(localStorage.getItem('loggedUserTypeId')).subscribe(data => {
                this.MenuListObj = data;
            }, erro => {
                this.MenuListObj = [];
            });
        }
    }
}



