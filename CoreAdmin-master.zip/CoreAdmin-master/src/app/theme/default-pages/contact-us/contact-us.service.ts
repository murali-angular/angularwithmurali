import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment.prod';
import { Contact } from '../../pages/common/contactus';
import { MessageModel } from '../../pages/common/message';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class ContactUsService {


  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Contact/InsertContactEnquiry';
  messageurl = environment.prod_URL + 'Message/SendMessageFreeAmb';
  mailurl = environment.prod_URL + 'MailMessage/RegisterPatientMail';

  public sendenquiry(contactobj: Contact): Observable<any> {
    return this.http.post(this.posturl, contactobj);
  }

  public MessageToPatient(message: MessageModel) {
    return this.http.post(this.messageurl, message);
  }
}
