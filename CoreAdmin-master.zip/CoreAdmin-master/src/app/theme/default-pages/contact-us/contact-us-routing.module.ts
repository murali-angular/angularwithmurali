import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactUsComponent } from './contact-us.component';
import { ParentContactUsComponent } from './parent-contact-us.component';

const routes: Routes = [
  {
    path: '', component: ParentContactUsComponent,
    children: [
      {
        path: '', component: ContactUsComponent, data: {
          title: 'Contact US'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class ContactUsRoutingModule { }
