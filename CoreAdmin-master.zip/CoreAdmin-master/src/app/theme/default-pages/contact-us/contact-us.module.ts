import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ContactUsComponent } from './contact-us.component';
import { ParentContactUsComponent } from './parent-contact-us.component';
import { ContactUsRoutingModule } from './contact-us-routing.module';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../../../shared/shared.module';


@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ContactUsRoutingModule,
    HttpModule,
    SharedModule
  ],
  bootstrap: [ContactUsComponent],
  declarations: [ContactUsComponent, ParentContactUsComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class ContactUsModule { }


