import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, UrlSegment } from '@angular/router';
import { Contact } from '../../pages/common/contactus';
import { ContactUsService } from './contact-us.service';
import { MessageModel } from '../../pages/common/message';
import { MailMessage } from '../../pages/common/mailmessage';
import { NotificationsService } from '../../../shared/notification/notifications.service';
import { Notification } from '../../../shared/notification/notifications.model';


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
  providers: [ContactUsService]
})
export class ContactUsComponent implements OnInit {
  con: Contact = new Contact();

  MessageStatement = 'Hi patName,Thank you for contacting AMBUFREE. We will contact you soon.www.ambufree.com';
  messagemodel: MessageModel = new MessageModel();
  mail: MailMessage = new MailMessage();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private contactservice: ContactUsService,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    //   setTimeout((router: Router) => {
    //     this.router.navigate(['/login']);
    // }, 10000);
  }

  sendContactEnquiry() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.contactservice.sendenquiry(this.con).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Thank You..we will contact you soon');
      this.sendBookAmbMessageToPatient();
    }, erro => {
      this.con = new Contact();
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  sendBookAmbMessageToPatient() {
    this.messagemodel.message = this.MessageStatement;
    this.messagemodel.patName = this.con.UserName;
    this.messagemodel.numbers = this.con.UserNum;
    this.contactservice.MessageToPatient(this.messagemodel).subscribe(data => {
      this.con = new Contact();
    }, erro => {
    });
  }
}
