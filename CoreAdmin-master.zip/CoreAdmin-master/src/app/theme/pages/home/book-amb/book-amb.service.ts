import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { BookAmbulance } from '../../common/bookAmb';
import { PatientRegistration } from '../../common/patientRegistration';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class BookAmbService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'BookAmbulance/InsertBookAmbulance';
  getbyidurl = environment.prod_URL + 'BookAmbulance/GetBookAmbulanceDetailsByAmbOwnerID/';
  updateurl = environment.prod_URL + 'Patient/UpdatePatientDetailsByID';
  bookmailpatienturl = environment.prod_URL + 'MailMessage/BookAmbPatientMail';
  bookmailOwnerurl = environment.prod_URL + 'MailMessage/BookAmbOwnerMail';
  bookedambPatientMsgurl = environment.prod_URL + 'Message/SendMessageBookAmbPatient';
  bookedAmbOwnerMsgurl = environment.prod_URL + 'Message/SendMessageBookAmbOwner';
  bookedSuperAdminMsgurl = environment.prod_URL + 'Message/SendMessageBookDetailsToSuperAdmin';


  public BookAmbulance(ambulance: BookAmbulance): Observable<any> {
    return this.http.post(this.posturl, ambulance);
  }

  public updatePatient(patientobjID: PatientRegistration): Observable<any> {
    return this.http.post(this.updateurl, patientobjID);
  }

  public BookMailToPatient(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailpatienturl, mail);
  }

  public BookMailToAmbOwner(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailOwnerurl, mail);
  }

  public MessageToBookedAmbPatient(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedambPatientMsgurl, message);
  }

  public MessageToBookedAmbOwner(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedAmbOwnerMsgurl, message);
  }

  public MessageToSuperAdmin(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedSuperAdminMsgurl, message);
  }

}
