import { Component, OnInit, Input } from '@angular/core';
import { BookAmbService } from './book-amb.service';
import { BookAmbulance } from '../../common/bookAmb';
import { ActivatedRoute, Router } from '@angular/router';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Login } from '../../common/login';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { PatientRegistration } from '../../common/patientRegistration';
import { PatientBookingsService } from '../../patients/patient-bookings/patient-bookings.service';
import { PatientRegistrationService } from '../../agents/patient-registration/patient-registration.service';
import { AmbulanceRegistrationService } from '../../agents/ambulance-registration/ambulance-registration.service';


@Component({
  selector: 'app-book-amb',
  templateUrl: './book-amb.component.html',
  styleUrls: ['./book-amb.component.css'],
  providers: [BookAmbService]
})
export class BookAmbComponent implements OnInit {

  myForm: FormGroup;
  bookambobj: BookAmbulance = new BookAmbulance();
  ambobj: AmbRegistration = new AmbRegistration();
  ambId: any;
  SelectedAmbID;

  login: Login = new Login();
  MessageStatement = 'You have booked VehicleName,Type on date at time.';
  MessageStatement2 = 'Ambulance Driver Details: DriverNme, DriverNum, numberplate.For more details call AmbNumber';
  MessageClientStatement = 'Hi,patName, patNum,has booked VehicleName  of Type on date at time.';
  MessageClientStatement2 = 'PickUp Address: patientAddress .www.ambufree.com';
  MessageSuperAdmin = 'patName, patNum has booked VehicleName, AmbNumber on date at time';

  mail: MailMessage = new MailMessage();
  selectedambdetails: AmbRegistration = new AmbRegistration();
  bookAmb: BookAmbulance = new BookAmbulance();
  isBookedUserDisabled = true;
  isEditHidden = false;
  isUpdateHidden = true;
  messagemodel: MessageModel = new MessageModel();
  patientDetails: PatientRegistration = new PatientRegistration();
  // AmbOwnerDetails: AmbOwnerRegistration = new AmbOwnerRegistration();
  // autocompletepatientaddress: string;

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private service: BookAmbService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    // private toastr: ToastrService,
    public domSanitizer: DomSanitizer,
    private patientservice: PatientRegistrationService,
    private ambulanceservice: AmbulanceRegistrationService,

  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      PatientName: this.valid.signupform.FirstName,
      PatientNumber: this.valid.signupform.MobileNumber,
      SelectedDate: this.valid.signupform.Required,
      SelectedTime: this.valid.signupform.Required,
      PatientAddress: this.valid.signupform.Required,
      // PatientCondition: this.valid.signupform.remarks
    });
    if (this.route.snapshot.url[1] !== undefined) {
      this.SelectedAmbID = this.route.snapshot.url[1].path;
      if (this.SelectedAmbID !== undefined && this.route.snapshot.url[0].path === 'getambdetails') {
        this.RetieveAmbulanceByID(this.SelectedAmbID);
        this.getPatientDetails();
      }
    }
  }


  RetieveAmbulanceByID(AID) {
    this.ambulanceservice.GetAmbulanceByID(AID).subscribe(data => {
      this.selectedambdetails = data;
    }, erro => {
    });
  }

  // autoCompleteCallback1(selectedData: any) {
  //   this.autocompletepatientaddress = selectedData.formatted_address;
  // }

  getPatientDetails() {
    this.patientservice.GetPatientDetailsByID(localStorage.getItem('loggedUser')).subscribe(data => {
      this.patientDetails = data;
    }, erro => {
    });
  }


  BookAmbulance() {
    // this.bookAmb.PatientAddress = this.autocompletepatientaddress;
    this.bookAmb.AmbID = this.SelectedAmbID;
    // this.bookAmb.AmbOwnerID = this.selectedambdetails.AmbOwnID;
    this.bookAmb.PatientName = this.patientDetails.PatientName;
    this.bookAmb.PatientNumber = this.patientDetails.PatientNumber;
    this.bookAmb.PatientEmail = '';
    this.bookAmb.PatientAddress = this.patientDetails.PatientAddress;
    this.bookAmb.PatientID = this.patientDetails.PatientID;
    this.service.BookAmbulance(this.bookAmb).subscribe(data => {
      // this.toastr.success('Ambulance Booked Successfully');
      this.sendBookAmbMessage();
      // this.sendBookAmbOwnerMessage();
      // this.sendToSuperAdmin();
      // this.sendBookAmbToAmbOwnerMailMessage();
      // this.sendBookAmbToPatientMailMessage();
      this.router.navigate(['/Thankyou']);
    }, erro => {
    });
  }

  EditPatientProfile() {
    this.isEditHidden = true;
    this.isUpdateHidden = false;
    this.isBookedUserDisabled = false;
  }

  sendBookAmbMessage() {
    this.messagemodel.Type = this.selectedambdetails.AmbType;
    this.messagemodel.VehicleName = this.selectedambdetails.AmbName;
    this.messagemodel.message = this.MessageStatement + this.MessageStatement2;
    // this.messagemodel.AmbNumber = this.AmbOwnerDetails.AmbOwnNum;
    this.messagemodel.DriverNme = this.selectedambdetails.DriverName;
    this.messagemodel.DriverNum = this.selectedambdetails.DriverNum;
    // this.messagemodel.date = this.bookAmb.SelectedDate;
    // this.messagemodel.time = this.bookAmb.SelectedTime;
    this.messagemodel.numbers = this.bookAmb.PatientNumber;
    this.messagemodel.numberplate = this.selectedambdetails.AmbNumberPlate;
    this.service.MessageToBookedAmbPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

  // RetrieveAmbOwnerById() {
  //   this.ambownerservice.GetByAmbOwnerName(this.selectedambdetails.AmbOwnID).subscribe(data => {
  //     this.AmbOwnerDetails = data;
  //   }, erro => {
  //   });
  // }

  // sendBookAmbOwnerMessage() {
  //   this.messagemodel.Type = this.selectedambdetails.AmbType;
  //   this.messagemodel.VehicleName = this.selectedambdetails.AmbName;
  //   this.messagemodel.messageClient = this.MessageClientStatement + this.MessageClientStatement2;
  //   this.messagemodel.date = this.bookAmb.SelectedDate;
  //   this.messagemodel.time = this.bookAmb.SelectedTime;
  //   this.messagemodel.numbers = this.bookAmb.DriverNum;
  //   this.messagemodel.patName = this.bookAmb.PatientName;
  //   this.messagemodel.patNum = this.bookAmb.PatientNumber;
  //   // this.messagemodel.patientAddress = this.autocompletepatientaddress;
  //   this.service.MessageToBookedAmbOwner(this.messagemodel).subscribe(data => {
  //   }, erro => {
  //   });
  // }

  // sendToSuperAdmin() {
  //   // this.messagemodel.Type = this.selectedambdetails.AmbType;
  //   this.messagemodel.VehicleName = this.selectedambdetails.AmbName;
  //   this.messagemodel.messageClient = this.MessageSuperAdmin;
  //   this.messagemodel.date = this.bookAmb.SelectedDate;
  //   this.messagemodel.time = this.bookAmb.SelectedTime;
  //   this.messagemodel.numbers = '8639148429';
  //   this.messagemodel.patName = this.bookAmb.PatientName;
  //   this.messagemodel.patNum = this.bookAmb.PatientNumber;
  //   this.messagemodel.AmbNumber = this.bookAmb.DriverNum;
  //   // this.messagemodel.patientAddress = this.autocompletepatientaddress;
  //   this.service.MessageToSuperAdmin(this.messagemodel).subscribe(data => {
  //   }, erro => {
  //   });
  // }

  sendBookAmbToPatientMailMessage() {
    this.mail.UserName = this.bookAmb.PatientName;
    this.mail.SelectedDate = this.bookAmb.SelectedDate;
    this.mail.SelectedTime = this.bookAmb.SelectedTime;
    this.mail.DriverName = this.selectedambdetails.DriverName;
    this.mail.DriverNum = this.selectedambdetails.DriverNum;
    this.mail.AmbNumberPlate = this.selectedambdetails.AmbNumberPlate;
    this.mail.AmbName = this.selectedambdetails.AmbName;
    this.mail.AmbNum = this.selectedambdetails.DriverNum;
    this.mail.UserEmail = this.selectedambdetails.AmbMail;
    this.service.BookMailToPatient(this.mail).subscribe(data => {
      // this.mail = new MailMessage();
    }, erro => {
      this.mail = new MailMessage();
    });
  }

  sendBookAmbToAmbOwnerMailMessage() {
    // this.mail.ClientName = this.ambobj.AmbOwnName;
    this.mail.SelectedDate = this.bookAmb.SelectedDate;
    this.mail.SelectedTime = this.bookAmb.SelectedTime;
    this.mail.DriverName = this.bookAmb.PatientName;
    this.mail.DriverNum = this.bookAmb.PatientNumber;
    this.mail.AmbNumberPlate = this.bookAmb.PatientAddress;
    this.mail.AmbName = this.selectedambdetails.AmbName;
    this.mail.UserEmail = this.selectedambdetails.AmbMail;
    this.service.BookMailToAmbOwner(this.mail).subscribe(data => {
      // this.mail = new MailMessage();
    }, erro => {
      this.mail = new MailMessage();
    });
  }

  updatePatientProfile() {
    this.service.updatePatient(this.patientDetails).subscribe(data => {
      this.isUpdateHidden = true;
    }, erro => {
    });
  }

}
