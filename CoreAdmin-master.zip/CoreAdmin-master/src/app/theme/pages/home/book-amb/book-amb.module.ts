import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BookAmbRoutingModule } from './book-amb-routing.module';
import { BookAmbComponent } from './book-amb.component';
import { BookAmbService } from './book-amb.service';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [
    CommonModule, FormsModule, BookAmbRoutingModule, ReactiveFormsModule, SharedModule, HttpModule
  ],
  declarations: [BookAmbComponent],
  bootstrap: [BookAmbComponent],
  providers: [BookAmbService, Validation]
})
export class BookAmbModule { }
