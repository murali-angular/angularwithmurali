import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbList } from '../../common/ambulanceList';
import { SearchEntireAmbandHospDetails, SearchServiceType } from '../../common/searchCustomAmb';
import { AmbRegistration } from '../../common/ambRegistration';
import { HospDetails } from '../../common/hospAmbReg';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class AmbSearchService {

  search: SearchServiceType = new SearchServiceType();
  constructor(private http: HttpClient) { }

  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulanceById/';
  getsearchurl = environment.prod_URL + 'Ambulance/GetAmbulanceSearch/';
  getsearchhospurl = environment.prod_URL + 'Hospital/GetHospSearch/';

  public GetAmbulance(): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.geturl);
  }

  public GetAmbulanceByID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyid + ID);
  }

  public searchCustomAmbResults(body: SearchServiceType): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.getsearchurl + body.SearchbyLocation + '/' + body.SearchbyName);
  }

  public searchHospResults(body: SearchServiceType): Observable<HospDetails[]> {
    return this.http.get<HospDetails[]>(this.getsearchhospurl + body.SearchbyLocation + '/' + body.SearchbyName);
  }

  // public searchCustomResults(body: SearchServiceType): Observable<any> {
  //   return this.http.get(this.getsearchurl + body.SearchbyLocation + '/' + body.SearchbyName)
  //     .map((res: Response) => res.json() as SearchEntireAmbandHospDetails)
  //     .catch((error: any) => Observable.throw(error.json().error));
  //   this.searchCustomAmbResults(this.search);
  //   this.searchCustomHospResults(this.search);

  // }

}
