import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AmbSearchRoutingModule } from './amb-search-routing.module';
import { AmbSearchComponent } from './amb-search.component';
import { AmbSearchService } from './amb-search.service';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { SearchFilterPipe } from '../../../../shared/searchfilter.pipe';
import { SearchHospFilterPipe } from '../../../../shared/searchhosp.pipe';
@NgModule({
  imports: [
    CommonModule, FormsModule, AmbSearchRoutingModule, SharedModule, HttpModule
  ],
  bootstrap: [AmbSearchComponent],
  declarations: [AmbSearchComponent],
  providers: [AmbSearchService, SearchFilterPipe, SearchHospFilterPipe],
})
export class AmbSearchModule { }
