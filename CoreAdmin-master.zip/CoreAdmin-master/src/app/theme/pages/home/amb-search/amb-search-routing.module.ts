import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AmbSearchComponent } from './amb-search.component';

const routes: Routes = [
  {
    path: '',
    component: AmbSearchComponent,
    data: {
      title: 'Search Results',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/:Type/:Location/:Name',
    component: AmbSearchComponent,
    data: {
      title: 'Search Results',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AmbSearchRoutingModule { }
