import { Component, OnInit } from '@angular/core';
import { BookAmbulance } from '../../common/bookAmb';
import { ActivatedRoute, Router } from '@angular/router';
import { AmbRegistration } from '../../common/ambRegistration';
import { FormBuilder } from '@angular/forms';
import { AmbSearchService } from './amb-search.service';
import { DomSanitizer } from '@angular/platform-browser';
import { HospitalDetailsService } from '../../agents/hospital-details/hospital-details.service';
import { HospDetails } from '../../common/hospAmbReg';
import { SearchServiceType, SearchEntireAmbandHospDetails } from '../../common/searchCustomAmb';
import { NotificationsService } from '../../../../shared/notification/notifications.service';
import { Notification } from '../../../../shared/notification/notifications.model';
import { SearchFilterPipe } from '../../../../shared/searchfilter.pipe';
import { SearchHospFilterPipe } from '../../../../shared/searchhosp.pipe';


@Component({
  selector: 'app-amb-search',
  templateUrl: './amb-search.component.html',
  styleUrls: ['./amb-search.component.css'],
  providers: [AmbSearchService, HospitalDetailsService, SearchFilterPipe, SearchHospFilterPipe]
})
export class AmbSearchComponent implements OnInit {
  newsearch: SearchEntireAmbandHospDetails = new SearchEntireAmbandHospDetails();
  searchObj: SearchServiceType = new SearchServiceType();
  bookambobj: BookAmbulance = new BookAmbulance();
  ambobj: AmbRegistration = new AmbRegistration();
  ambId: any;
  ambList: AmbRegistration[];
  searchambObj: AmbRegistration = new AmbRegistration();
  searchhospObj: HospDetails = new HospDetails();

  hosplistobj: HospDetails[];
  selectedamb: any;
  slocation: any;
  sambulance: any;
  stype;
  AmbType: string;
  ServiceType: string;
  AmbTypeList = [{ name: 'BLS Ambulance' }, { name: 'ALS Ambulance' }, { name: 'Transport Ambulance' },
  { name: 'Ventilator Ambulance' }, { name: 'Air Ambulance' }, { name: 'Oxygen Ambulance' }, { name: 'Body Freezer Ambulance' },
  { name: 'AC Ambulance' }, { name: 'ICU Ambulance' }, { name: 'Cardiac Care Ambulance' }, { name: 'Accident Case Ambulance' },
  { name: 'Critical Care Ambulance' }, { name: 'Train Ambulance' }, { name: 'Diagnostic Ambulance' }, { name: 'Other Ambulance' }];

  ServiceTypeList = [{ name: 'Hospital' }, { name: 'Ambulance' }];
  ishospsearch: boolean;
  isambsearch: boolean;
  HospTypeList = [{ name: 'General Hospital' }, { name: 'Multi-Speciality Hospital' }, { name: 'Super specialty' }, { name: '' }];


  constructor(private fb: FormBuilder,
    private route: ActivatedRoute, private router: Router,
    private service: AmbSearchService,
    private hospservice: HospitalDetailsService,
    private notes: NotificationsService,
    private _sanitizer: DomSanitizer) {

  }

  ngOnInit() {
    if (this.route.snapshot.url[1] !== undefined) {
      this.stype = this.route.snapshot.url[1].path;
      this.slocation = this.route.snapshot.url[2].path;
      this.sambulance = this.route.snapshot.url[3].path;
      if (this.stype !== undefined && this.route.snapshot.url[0].path === 'edit') {
        if (this.stype === 'Hospital' || this.searchObj.ServiceType === 'HospitalAmbulance') {
          this.RetieveHospitalList();
          this.searchObj.ServiceType = 'Hospital';
          this.ishospsearch = true;
          this.isambsearch = false;
        }
        if (this.stype === 'Ambulance') {
          this.getAllAmbList();
          this.searchObj.ServiceType = 'Ambulance';
          this.ishospsearch = false;
          this.isambsearch = true;
        }
      }
    }
  }

  bookAmb(ambId: any) {
    this.router.navigateByUrl('/bookAmbulance/edit' + ambId);
    // this.selectedamb = ambId;
  }

  getambId(ambID): any {
    this.service.GetAmbulanceByID(ambID).subscribe(data => {
      return data;
    }, error => {
    });
  }

  getAllAmbList() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetAmbulance().subscribe(data => {
      this.ambList = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  GetImage(img) {
    return this._sanitizer.bypassSecurityTrustResourceUrl(img);
  }

  RetieveHospitalList() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospitalsList().subscribe(data => {
      this.hosplistobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
    });
  }

  BookFreeAmb(hospId) {
    this.router.navigateByUrl('/hospital/edit/' + hospId);
  }

  onChangeServiceType() {
    if (this.searchObj.ServiceType === 'Hospital') {
      this.ishospsearch = true;
      this.isambsearch = false;

      this.RetieveHospitalList();
    }
    if (this.searchObj.ServiceType === 'Ambulance') {
      this.isambsearch = true;
      this.ishospsearch = false;

      this.getAllAmbList();

    }
  }

  searchCustomResults() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.searchObj.SearchbyLocation = this.slocation;
    this.searchObj.SearchbyName = this.sambulance;
    this.service.searchCustomAmbResults(this.searchObj).subscribe(data => {
      this.ambList = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  searchCustomHospResults() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.searchObj.SearchbyLocation = this.slocation;
    this.searchObj.SearchbyName = this.sambulance;
    this.service.searchHospResults(this.searchObj).subscribe(data => {
      this.hosplistobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  CallAmbulance(AID) {
    this.router.navigateByUrl('/scheduleAmb/edit/' + AID);
  }

}
