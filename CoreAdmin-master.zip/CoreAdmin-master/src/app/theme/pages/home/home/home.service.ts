import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { SearchServiceType } from '../../common/searchCustomAmb';
import { MenuItems } from '../../common/menu';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HomeService {


  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Search/GetAgentsAmbList';
  menuposturl = environment.prod_URL + 'Menu/InsertMenu';
  geturlbyid = environment.prod_URL + 'Menu/GetMenuBySignUpId';

  public SearchResults(searchObj: SearchServiceType): Observable<any> {
    return this.http.post(this.posturl, searchObj);
  }

  public InsertMenu(menuObj: MenuItems): Observable<any> {
    return this.http.post(this.menuposturl, menuObj);
  }

  public getMenuBySignupId(ID: any): Observable<any> {
    return this.http.get(this.geturlbyid + ID);
  }


}
