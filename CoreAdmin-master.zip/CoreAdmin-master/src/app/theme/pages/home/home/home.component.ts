import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';
import { Router } from '@angular/router';
import { SearchServiceType } from '../../common/searchCustomAmb';
import { MenuItems } from '../../common/menu';
import { Contact } from '../../common/contactus';
import { ContactUsService } from '../../../default-pages/contact-us/contact-us.service';
import { MessageModel } from '../../common/message';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [HomeService, ContactUsService]
})
export class HomeComponent implements OnInit {

  cityList = [{ name: 'Hyderabad' }, { name: 'Benguluru' }];
  serviceList = [{ name: 'Hospital' }, { name: 'Ambulance' }];
  searchObj: SearchServiceType = new SearchServiceType();
  MenuList: MenuItems = new MenuItems();
  con: Contact = new Contact();

  MessageStatement = 'Thank you for contacting AMBUFREE. We will contact you soon.www.ambufree.com';
  messagemodel: MessageModel = new MessageModel();

  constructor(private service: HomeService, private router: Router,
    private contactservice: ContactUsService) {

  }

  ngOnInit() {
  }

  searchcustomresults() {
    this.router.navigateByUrl('/searchAmb/edit/' + this.searchObj.ServiceType
      + '/' + this.searchObj.SearchbyLocation + '/' + this.searchObj.SearchbyName);
  }

  GetMenuBySignupId() {
    if (localStorage.getItem('loggedUser') !== '') {
      this.service.getMenuBySignupId(localStorage.getItem('loggedUser')).subscribe(data => {
        this.MenuList = data;
      }, erro => {
      });
    }
  }

  sendContactEnquiry() {
    this.contactservice.sendenquiry(this.con).subscribe(data => {
      // this.toastr.success('Thanks, We will contact you soon..');
      this.sendBookAmbMessageToPatient();
      this.con = new Contact();
    }, erro => {
      this.con = new Contact();
    });
  }

  sendBookAmbMessageToPatient() {
    this.messagemodel.message = this.MessageStatement;
    this.messagemodel.patName = this.con.UserName;
    this.messagemodel.numbers = this.con.UserNum;
    this.contactservice.MessageToPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

}
