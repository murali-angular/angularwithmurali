import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { HomeService } from './home.service';
@NgModule({
  imports: [
    CommonModule, FormsModule, HomeRoutingModule, SharedModule, HttpModule
  ],
  bootstrap: [HomeComponent],
  declarations: [HomeComponent],
  providers: [HomeService],
})
export class HomeModule { }
