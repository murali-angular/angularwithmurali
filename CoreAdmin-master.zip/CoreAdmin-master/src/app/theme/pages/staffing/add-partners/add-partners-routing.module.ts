import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddPartnersComponent } from './add-partners.component';

const routes: Routes = [
  {
    path: '',
    component: AddPartnersComponent,
    data: {
      title: 'Add partner',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddPartnersRoutingModule { }
