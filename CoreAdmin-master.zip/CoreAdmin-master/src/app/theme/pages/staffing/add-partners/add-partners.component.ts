import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AddRefferals } from '../../common/refferals';
import { Validation } from 'src/app/shared/Validator';
import { ActivatedRoute } from '@angular/router';
import { AddReferalService } from '../../refferals/add-referal/add-referal.service';
import { Partners } from '../../common/partners';

@Component({
  selector: 'app-add-resource',
  templateUrl: './add-partners.component.html',
  styleUrls: ['./add-partners.component.scss']
})
export class AddPartnersComponent implements OnInit {

  myForm: FormGroup;
  partnerobj: Partners = new Partners();
  public loading = false;
  constructor(private fb: FormBuilder, private valid: Validation,
    private route: ActivatedRoute,
    private service: AddReferalService,
    // private toastr: ToastrService,
    // private spinner: NgxSpinnerService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      PartnerName: this.valid.signupform.FirstName,
      PartnerNum: this.valid.signupform.MobileNumber,
      PartnerAltNum: this.valid.signupform.showpass,
      PartnerMailId: this.valid.signupform.Email,
      PartnerAddress: this.valid.signupform.remarks,
      CatogeryType: this.valid.signupform.remarks,
      PartnerStatus: this.valid.signupform.showpass,
    });
  }

  createPartner() {

  }

}
