import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { StaffingService } from '../staffing.service';
import { HttpClientModule } from '@angular/common/http';
import { AssignResourceRoutingModule } from './assign-resource-routing.module';
import { AssignResourceComponent } from './assign-resource.component';

@NgModule({
  imports: [
    CommonModule, AssignResourceRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpClientModule

  ],
  declarations: [AssignResourceComponent],
  bootstrap: [AssignResourceComponent],
  providers: [StaffingService, Validation],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AssignResourceModule { }
