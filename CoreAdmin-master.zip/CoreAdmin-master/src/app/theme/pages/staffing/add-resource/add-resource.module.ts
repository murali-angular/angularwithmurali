import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { StaffingService } from '../staffing.service';
import { HttpClientModule } from '@angular/common/http';
import { AddResourceRoutingModule } from './add-resource-routing.module';
import { AddResourceComponent } from './add-resource.component';

@NgModule({
  imports: [
    CommonModule, AddResourceRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpClientModule

  ],
  declarations: [AddResourceComponent],
  bootstrap: [AddResourceComponent],
  providers: [StaffingService, Validation],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AddResourceModule { }
