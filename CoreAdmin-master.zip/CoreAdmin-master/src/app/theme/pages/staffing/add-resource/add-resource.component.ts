import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from 'src/app/shared/Validator';
import { ActivatedRoute } from '@angular/router';
import { AddReferalService } from '../../refferals/add-referal/add-referal.service';
import { Resources } from '../../common/resources';

@Component({
  selector: 'app-add-resource',
  templateUrl: './add-resource.component.html',
  styleUrls: ['./add-resource.component.scss']
})
export class AddResourceComponent implements OnInit {

  myForm: FormGroup;
  resourceobj: Resources = new Resources();
  public loading = false;
  constructor(private fb: FormBuilder, private valid: Validation,
    private route: ActivatedRoute,
    private service: AddReferalService,
    // private toastr: ToastrService,
    // private spinner: NgxSpinnerService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      ResourceName: this.valid.signupform.FirstName,
      ResourceNum: this.valid.signupform.MobileNumber,
      ResourceAltNum: this.valid.signupform.showpass,
      ResourceMailId: this.valid.signupform.Email,
      ResourceAddress: this.valid.signupform.remarks,
      ResourceType: this.valid.signupform.remarks,
      PartnerStatus: this.valid.signupform.showpass,
      IsActive : this.valid.signupform.showpass,
    });
  }

  createResource() {

  }
}
