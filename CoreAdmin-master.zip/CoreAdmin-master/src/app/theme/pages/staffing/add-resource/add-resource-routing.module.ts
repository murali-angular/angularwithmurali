import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddResourceComponent } from './add-resource.component';

const routes: Routes = [
  {
    path: '',
    component: AddResourceComponent,
    data: {
      title: 'Add Resource',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddResourceRoutingModule { }
