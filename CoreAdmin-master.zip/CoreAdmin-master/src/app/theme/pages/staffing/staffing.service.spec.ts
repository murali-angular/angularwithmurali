import { TestBed } from '@angular/core/testing';

import { StaffingService } from './staffing.service';

describe('StaffingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StaffingService = TestBed.get(StaffingService);
    expect(service).toBeTruthy();
  });
});
