import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddRefferals } from '../../common/refferals';

@Injectable({
  providedIn: 'root'
})
export class AddReferalService {


  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Hospital/InsertHospital';
  geturl = environment.prod_URL + 'Hospital/GetHospitalList';
  updateurl = environment.prod_URL + 'Hospital/updateHospital';
  deleteurl = environment.prod_URL + 'Hospital/DeleteHospital/';
  geturlbyid = environment.prod_URL + 'Hospital/GethospitalById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Hospital/GetAmbulanceAmbOwnID/';


  public GetLabTestByTestID(ID: any): Observable<AddRefferals> {
    return this.http.get<AddRefferals>(this.geturlbyAmbOwnid + ID);
  }

  public GetLabTestsList(): Observable<AddRefferals[]> {
    return this.http.get<AddRefferals[]>(this.geturl);
  }

  public SaveLabTest(hospobj: AddRefferals): Observable<any> {
    return this.http.post(this.posturl, hospobj);
  }


  public UpdateLabTest(hospobj: AddRefferals): Observable<any> {
    return this.http.post(this.updateurl, hospobj);
  }

  public DeleteLabTest(hospId): Observable<any> {
    return this.http.post(this.deleteurl, hospId);
  }
}



