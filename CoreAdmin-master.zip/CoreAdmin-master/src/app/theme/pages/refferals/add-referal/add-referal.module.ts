import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { AddReferalService } from './add-referal.service';
import { AddReferalComponent } from './add-referal.component';
import { AddReferalRoutingModule } from './add-referal-routing.module';

@NgModule({
  imports: [
    CommonModule, FormsModule, AddReferalRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [AddReferalComponent],
  bootstrap: [AddReferalComponent],
  providers: [AddReferalService, Validation]
})
export class AddReferalModule { }
