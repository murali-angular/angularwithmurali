import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from 'src/app/shared/Validator';
import { ActivatedRoute } from '@angular/router';
import { AddRefferals } from '../../common/refferals';
import { AddReferalService } from './add-referal.service';

@Component({
  selector: 'app-add-referal',
  templateUrl: './add-referal.component.html',
  styleUrls: ['./add-referal.component.scss']
})
export class AddReferalComponent implements OnInit {

  myForm: FormGroup;
  referalobj: AddRefferals = new AddRefferals();
  public loading = false;
  constructor(private fb: FormBuilder, private valid: Validation,
    private route: ActivatedRoute,
    private service: AddReferalService,
    // private toastr: ToastrService,
    // private spinner: NgxSpinnerService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      ReferralName: this.valid.signupform.FirstName,
      ReferralNum: this.valid.signupform.MobileNumber,
      ReferralAltNum: this.valid.signupform.showpass,
      ReferralMailId: this.valid.signupform.Email,
      ReferralAddress: this.valid.signupform.remarks,
      ReferralStatus: this.valid.signupform.showpass,
      ReferralPercentage : this.valid.signupform.showpass
    });
  }

  createReferral() {

  }

  // createPatient() {
  //   // this.spinner.show();
  //   this.service.InsertPatientDetails(this.referalobj).subscribe(data => {
  //     // this.toastr.success('Saved Successfully');
  //   }, erro => {

  //     // this.spinner.hide();
  //     // this.toastr.error('Saved Failed');
  //   });
  // }

}
