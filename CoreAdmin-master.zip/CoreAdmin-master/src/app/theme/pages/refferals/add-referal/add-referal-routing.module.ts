import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddReferalComponent } from './add-referal.component';

const routes: Routes = [
  {
    path: '',
    component: AddReferalComponent,
    data: {
      title: 'Add Refferal',
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddReferalRoutingModule { }
