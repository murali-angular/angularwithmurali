import { TestBed } from '@angular/core/testing';

import { AddReferalService } from './add-referal.service';

describe('AddReferalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddReferalService = TestBed.get(AddReferalService);
    expect(service).toBeTruthy();
  });
});
