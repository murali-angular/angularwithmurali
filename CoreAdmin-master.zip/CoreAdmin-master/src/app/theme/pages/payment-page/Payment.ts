export class PaymentPay {
    key: '92APPdssbyYG7U';
    image: 'https://i.imgur.com/n5tjHFD.png';
}
