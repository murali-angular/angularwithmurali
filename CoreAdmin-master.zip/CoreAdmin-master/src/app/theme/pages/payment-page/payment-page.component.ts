import { Component, OnInit } from '@angular/core';
import { PaymentPay } from './Payment';

@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.scss']
})

export class PaymentPageComponent implements OnInit {

  pay: PaymentPay = new PaymentPay();
  constructor() { }

  ngOnInit() {
  }


  paymenton() {
    // curl - u<YOUR_KEY>: <YOUR_SECRET>,
    //   -X POST https: api.razorpay.com/v1/orders,
    //   -H:"Content-Type: application/json",
    //   -d '{
    // "amount": "50000",
    //   "currency" : "INR",
    //   "receipt": "rcptid #1",
    //   "payment_capture": "0"
    // } '
}

}
