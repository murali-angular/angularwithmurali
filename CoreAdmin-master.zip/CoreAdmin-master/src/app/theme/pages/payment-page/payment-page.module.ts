import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaymentPageRoutingModule } from './payment-page-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { PaymentPageComponent } from './payment-page.component';
import { PaymentPageService } from './payment-page.service';
import { SharedModule } from '../../../shared/shared.module';
import { Validation } from '../../../shared/Validator';


@NgModule({
  imports: [
    CommonModule, FormsModule, PaymentPageRoutingModule, SharedModule, HttpClientModule, ReactiveFormsModule
  ],
  declarations: [PaymentPageComponent],
  bootstrap: [PaymentPageComponent],
  providers: [PaymentPageService, Validation]
})
export class PaymentPageModule { }
