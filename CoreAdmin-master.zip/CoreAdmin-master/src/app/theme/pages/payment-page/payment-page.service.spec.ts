import { TestBed } from '@angular/core/testing';

import { PaymentPageService } from './payment-page.service';

describe('PaymentPageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PaymentPageService = TestBed.get(PaymentPageService);
    expect(service).toBeTruthy();
  });
});
