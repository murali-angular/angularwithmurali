import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { Login, SignUp } from '../../common/login';
import { MessageModel } from '../../common/message';
import { MailMessage } from '../../common/mailmessage';
import { MenuItems } from '../../common/menu';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class SignupService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'SignUp/InsertUser';
  loginposturl = environment.prod_URL + 'Login/Authenticate';
  forgotpwdurl = environment.prod_URL + 'Account/ForgotPassword';
  forgotpwdMailurl = environment.prod_URL + 'MailMessage/ForgotPasswordMail';
  confirmpwdurl = environment.prod_URL + 'Login/ConfirmPassword';
  geturlbyid = environment.prod_URL + 'Patient/GetPatientDetailsByID/';
  messageurl = environment.prod_URL + 'Message/SendMessageRegistration';
  mailurl = environment.prod_URL + 'MailMessage/RegisterPatientMail';
  getMenuurl = environment.prod_URL + 'Menu/GetMenusByLoggedUser/';
  menuposturl = environment.prod_URL + 'Menu/InsertMenu';
  getmenuurlbyid = environment.prod_URL + 'Menu/GetMenusByLoggedUser/';

  public credentialslogin(login: Login): Observable<any> {
    return this.http.post(this.loginposturl, login);
  }

  public ForGotUserPassword(LoginUser): Observable<any> {
    return this.http.post(this.forgotpwdurl, LoginUser);
  }

  // public ForGotUserPassword(LoginUser): Observable<any> {
  //   const bodyString = JSON.stringify(body);
  //   const headers = new Headers({ 'Content-Type': 'application/json' });
  //   const options = new RequestOptions({ headers: headers });
  //   return this.http.post(this.posturl, LoginUser, options)
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForGotUserPassword(LoginUser): Observable<any> {
  //   return this.http.post(this.confirmpwdurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }


  // public ConfirmPassword(login: Login): Observable<any> {
  //   return this.http.post(this.forgotpwdurl, JSON.stringify(login))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForgotMail(LoginUser): Observable<any> {
  //   return this.http.post(this.forgotpwdMailurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForgotMessage(LoginUser): Observable<any> {
  //   return this.http.post(this.forgotpwdMailurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  public MessageToPatient(message: MessageModel) {
    return this.http.post(this.messageurl, message);
  }

  public InsertUserDetails(user: SignUp) {
    return this.http.post(this.posturl, user);
  }

  public MailMessageToRegisteredPatient(mail: MailMessage) {
    return this.http.post(this.mailurl, mail);
  }

  public InsertUserMenus(menu: MenuItems) {
    return this.http.post(this.menuposturl, menu);
  }

  public GetUserMenusByUserTypeId(ID: any): Observable<any> {
    return this.http.get(this.getmenuurlbyid + ID);
  }


}
