import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { SignupRoutingModule } from './signup-routing.module';
import { SignupComponent } from './signup.component';
import { SignupService } from './signup.service';
import { Validation } from '../../../../shared/Validator';

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, SignupRoutingModule, HttpModule, ReactiveFormsModule
  ],
  declarations: [SignupComponent],
  bootstrap: [SignupComponent],
  providers: [SignupService, Validation],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class SignupModule { }
