import { Component, OnInit, AfterContentInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SignupService } from './signup.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SignUp, Login } from '../../common/login';
import { Validation } from '../../../../shared/Validator';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { MenuItems } from '../../common/menu';
import { NotificationsService } from '../../../../shared/notification/notifications.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: [SignupService, NotificationsService]
})
export class SignupComponent implements OnInit, AfterViewInit {

  myForm: FormGroup;
  signupobj: SignUp = new SignUp();
  newlogin: Login = new Login();
  menu: MenuItems = new MenuItems();
  MenuListObj: MenuItems[] = [];
  agentMenu = [];
  mail: MailMessage = new MailMessage();
  messagemodel: MessageModel = new MessageModel();
  // MessageStatement = 'Thanks for registering with ambufree.com.Your Login Details UserName:UserKey and Password:Passkey';
  MessageStatementPatient = 'Thanks for registering with ambufree.com.Your Login Details UserName:UserKey and Password:Passkey';

  UserTypeList = [
    { name: 'Patient', value: 0 },
    { name: 'Hospital', value: 1 },
    { name: 'Ambulance', value: 2 },
    { name: 'Agent', value: 3 }
  ];

  isLogin = true;
  isResetPwd: boolean;
  isSignUp: boolean;

  constructor(private fb: FormBuilder, private valid: Validation, private notes: NotificationsService,
    private service: SignupService, private router: Router) {
  }

  ngOnInit() {
    this.MenuListObj = [];
    this.myForm = this.fb.group({
      UserMail: this.valid.signupform.Email,
      UserMobile: this.valid.signupform.MobileNumber,
      UserPwd: this.valid.signupform.Password,
      UserTypeID: this.valid.signupform.Required
    });
  }

  ngAfterViewInit() {
    // this.MenusAssignedByUserType();
  }

  refresh(): void {
    window.location.reload();
  }

  Signup() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.InsertUserDetails(this.signupobj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Profile Created successfully');
      this.newlogin.UserName = this.signupobj.UserMail;
      this.newlogin.Password = this.signupobj.UserPwd;
      this.AuthenticateLogin(this.newlogin);
      this.sendPatientregisterMessage();
      // this.sendPatientMailMessage();
      // this.AssignMenuBuUser();
      this.signupobj = new SignUp();
      this.messagemodel = new MessageModel();
      this.mail = new MailMessage();
      // this.newlogin = new Login();
    }, erro => {
      // this.toastr.error('Already Exists UserName or PhoneNum or Email');
      this.signupobj = new SignUp();
      this.notes.error('Signup Failed');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.newlogin = new Login();
    });
  }

  AuthenticateLogin(loginmodal) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    if (loginmodal) {
      this.service.credentialslogin(loginmodal).subscribe(data => {
        this.notes.loadingSpinnerByMessage(false, 'Loading');
        this.notes.success('Login successfully');
        this.newlogin = new Login();
        if (data.Status === 'PASS') {
          localStorage.setItem('loggedUser', data.SignUpID);
          localStorage.setItem('loggedUserTypeId', data.UserTypeId);
          this.MenusAssignedByUserType();
          if (localStorage.getItem('loggedUserTypeId') === '0') {
            this.router.navigate(['/home']);
          }
          if (localStorage.getItem('loggedUserTypeId') === '1' || localStorage.getItem('loggedUserTypeId') === '3') {
            this.router.navigate(['/hospitaldetails']);
          }
          if (localStorage.getItem('loggedUserTypeId') === '2' || localStorage.getItem('loggedUserTypeId') === '3') {
            this.router.navigate(['/ambualnceRegistration']);
          }
          if (localStorage.getItem('loggedUserTypeId') === null || localStorage.getItem('loggedUserTypeId') === undefined) {
            this.router.navigate(['/login']);
          }
          // this.refresh();
          // this.router.navigate(['/home']);
        }
      }, erro => {
        this.newlogin = new Login();
        this.notes.error('Login Failed');
        this.notes.loadingSpinnerByMessage(false, 'Loading');
        this.MenuListObj = [];

      });
    }
  }


  sendPatientregisterMessage() {
    this.messagemodel.UserKey = this.signupobj.UserMail || this.signupobj.UserMobile;
    this.messagemodel.Passkey = this.signupobj.UserPwd;
    this.messagemodel.message = this.MessageStatementPatient;
    this.messagemodel.numbers = this.signupobj.UserMobile;
    this.service.MessageToPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

  sendPatientMailMessage() {
    this.mail.UserName = this.signupobj.UserMail || this.signupobj.UserMobile;
    this.mail.Password = this.signupobj.UserPwd;
    this.mail.UserEmail = this.signupobj.UserMail;
    this.service.MailMessageToRegisteredPatient(this.mail).subscribe(data => {
    }, erro => {
    });
  }

  MenusAssignedByUserType() {
    this.MenuListObj = [];
    // tslint:disable-next-line: deprecation
    if (!isNullOrUndefined(localStorage.getItem('loggedUserTypeId'))) {
      this.service.GetUserMenusByUserTypeId(localStorage.getItem('loggedUserTypeId')).subscribe(data => {
        this.MenuListObj = data;
      }, erro => {
        this.MenuListObj = [];
      });
    }
  }

  // onclickfgtpwd() {
  //   this.isResetPwd = true;
  //   this.isLogin = false;
  //   this.isSignUp = false;
  // }

  // onclicksignup() {
  //   this.isResetPwd = false;
  //   this.isLogin = false;
  //   this.isSignUp = true;
  // }
}
