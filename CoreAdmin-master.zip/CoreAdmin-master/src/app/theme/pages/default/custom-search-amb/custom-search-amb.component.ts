import { Component } from '@angular/core';
import { SearchCustomAmb } from '../../common/searchCustomAmb';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomSearchAmbService } from './custom-search-amb.service';

@Component({
  selector: 'app-custom-search-amb',
  templateUrl: './custom-search-amb.component.html',
  styleUrls: ['./custom-search-amb.component.css'],
  providers:[CustomSearchAmbService]
})
export class CustomSearchAmbComponent {

  amblist = [];
  searchambObj: SearchCustomAmb = new SearchCustomAmb();

  constructor(private service: CustomSearchAmbService, private route: ActivatedRoute, private router: Router) {

  }

  searchCustomAmb(target) {
    this.service.GetAmbulanceBySearch(target).subscribe(data => {
      this.amblist = data;
    });
  }
}
