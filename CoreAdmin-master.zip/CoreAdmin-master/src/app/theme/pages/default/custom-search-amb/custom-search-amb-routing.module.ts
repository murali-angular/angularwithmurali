import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomSearchAmbComponent } from './custom-search-amb.component';

const routes: Routes = [
  {
    path: '',
    component: CustomSearchAmbComponent,
    data: {
      title: 'Search Ambulance',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomSearchAmbRoutingModule { }
