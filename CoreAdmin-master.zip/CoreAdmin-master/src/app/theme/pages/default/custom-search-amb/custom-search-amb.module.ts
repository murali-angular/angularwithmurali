import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { CustomSearchAmbRoutingModule } from './custom-search-amb-routing.module';
import { CustomSearchAmbComponent } from './custom-search-amb.component';
import { CustomSearchAmbService } from './custom-search-amb.service';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, CustomSearchAmbRoutingModule, HttpModule
  ],
  declarations: [CustomSearchAmbComponent],
  bootstrap: [CustomSearchAmbComponent],
  providers: [CustomSearchAmbService]
})
export class CustomSearchAmbModule { }
