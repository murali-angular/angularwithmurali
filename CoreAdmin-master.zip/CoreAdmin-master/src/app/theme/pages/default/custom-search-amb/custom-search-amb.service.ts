import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { SearchCustomAmb } from '../../common/searchCustomAmb';
import { AmbList } from '../../common/ambulanceList';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class CustomSearchAmbService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'CustomSearch/InsertPatient';
  geturl = environment.prod_URL + 'CustomSearch/InsertPatient';

  public GetAmbulanceBySearch(ambtarget: SearchCustomAmb): Observable<AmbList[]> {
    return this.http.get<AmbList[]>(this.geturl + '/' + ambtarget);
  }

}
