import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { Login } from '../../common/login';
import { environment } from '../../../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class LoginService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Login/Authenticate';
  forgotpwdurl = environment.prod_URL + 'Account/ForgotPassword';
  forgotpwdMailurl = environment.prod_URL + 'MailMessage/ForgotPasswordMail';
  confirmpwdurl = environment.prod_URL + 'Login/ConfirmPassword';
  getmenuurlbyid = environment.prod_URL + 'Menu/GetMenusByLoggedUser/';

  public credentialslogin(login: Login): Observable<any> {
    return this.http.post(this.posturl, login);
  }

  public ForGotUserPassword(LoginUser): Observable<any> {
    return this.http.post(this.forgotpwdurl, LoginUser);
  }

  // public ForGotUserPassword(LoginUser): Observable<any> {
  //   const bodyString = JSON.stringify(body);
  //   const headers = new Headers({ 'Content-Type': 'application/json' });
  //   const options = new RequestOptions({ headers: headers });
  //   return this.http.post(this.posturl, LoginUser, options)
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForGotUserPassword(LoginUser): Observable<any> {
  //   return this.http.post(this.confirmpwdurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }


  // public ConfirmPassword(login: Login): Observable<any> {
  //   return this.http.post(this.forgotpwdurl, JSON.stringify(login))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForgotMail(LoginUser): Observable<any> {
  //   return this.http.post(this.forgotpwdMailurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  // public ForgotMessage(LoginUser): Observable<any> {
  //   return this.http.post(this.forgotpwdMailurl, JSON.stringify(LoginUser))
  //     .map((res: Response) => {
  //       return res.json() as Login;
  //     })
  //     .catch(this.handleError);
  // }

  public GetUserMenusByUserTypeId(ID: any): Observable<any> {
    return this.http.get(this.getmenuurlbyid + ID);
  }

}
