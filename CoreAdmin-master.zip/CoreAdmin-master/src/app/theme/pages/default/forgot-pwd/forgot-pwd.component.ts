import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { NotificationsService } from '../../../../shared/notification/notifications.service';
import { Router } from '@angular/router';
import { ForgotPwdService } from './forgot-pwd.service';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { SignupService } from '../signup/signup.service';
import { ForgotPwd } from '../../common/login';

@Component({
  selector: 'app-forgot-pwd',
  templateUrl: './forgot-pwd.component.html',
  styleUrls: ['./forgot-pwd.component.css'],
  providers: [SignupService, NotificationsService]

})
export class ForgotPwdComponent implements OnInit {
  forgotpwdobj : ForgotPwd = new ForgotPwd();
  messagemodel: MessageModel = new MessageModel();
  MessageStatementPatient = 'Your Passowrd is Passkey.Thanks for Using ambufree.com.';

  constructor(private service: ForgotPwdService,
    private fb: FormBuilder, private valid: Validation,
    private notes: NotificationsService,
    private signupservice: SignupService,
    private router: Router) { }

  ngOnInit() {
  }

  ForgotPwd() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.forgotPassword(this.forgotpwdobj).subscribe(data => {
      this.forgotpwdobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      // this.notes.success('Password R successfully');
      this.sendPatientregisterMessage();
    }, erro => {
      this.forgotpwdobj = new ForgotPwd();
      // this.notes.error('Password Changed Failed');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  sendPatientregisterMessage() {
    this.messagemodel.Passkey = this.forgotpwdobj.Password;
    this.messagemodel.message = this.MessageStatementPatient;
    this.messagemodel.numbers = this.forgotpwdobj.Number;
    this.signupservice.MessageToPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

}
