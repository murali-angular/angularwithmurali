import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { SearchCustomAmb } from '../../common/searchCustomAmb';
import { AmbList } from '../../common/ambulanceList';
import { ForgotPwd } from '../../common/login';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ForgotPwdService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Default/ForgotPassword';

  public forgotPassword(obj: ForgotPwd): Observable<any> {
    return this.http.post(this.posturl, obj);
  }

}
