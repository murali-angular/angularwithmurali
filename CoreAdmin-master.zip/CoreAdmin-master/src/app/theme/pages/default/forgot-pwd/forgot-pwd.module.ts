import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { ForgotPwdRoutingModule } from './forgot-pwd-routing.module';
import { ForgotPwdComponent } from './forgot-pwd.component';
import { ForgotPwdService } from './forgot-pwd.service';
import { Validation } from '../../../../shared/Validator';

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, ForgotPwdRoutingModule
  ],
  declarations: [ForgotPwdComponent],
  bootstrap: [ForgotPwdComponent],
  providers: [ForgotPwdService, Validation],
  schemas : [CUSTOM_ELEMENTS_SCHEMA]
})
export class ForgotPwdModule { }
