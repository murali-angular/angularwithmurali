import { Component, OnInit } from '@angular/core';
import { ChangePwdService } from './change-pwd.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { NotificationsService } from '../../../../shared/notification/notifications.service';
import { Router } from '@angular/router';
import { SignUp, ChangePwd } from '../../common/login';

@Component({
  selector: 'app-change-pwd',
  templateUrl: './change-pwd.component.html',
  styleUrls: ['./change-pwd.component.css']
})
export class ChangePwdComponent implements OnInit {
  myForm: FormGroup;
  changepwdObj: ChangePwd = new ChangePwd();
  signupObj: SignUp = new SignUp();

  constructor(private service: ChangePwdService,
    private fb: FormBuilder, private valid: Validation,
    private notes: NotificationsService,
    private router: Router) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      CurrentPwd: this.valid.signupform.Required,
      NewPwd: this.valid.signupform.Password,
      ConfirmPwd: this.valid.signupform.Required,
    });
  }

  ChangePwd() {
    this.changepwdObj.SignUpId = localStorage.getItem('loggedUser');
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.changePwd(this.changepwdObj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Password Changed successfully');
      this.changepwdObj = new ChangePwd();
    }, erro => {
      this.changepwdObj = new ChangePwd();
      this.notes.error('Password Changed Failed');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }


}
