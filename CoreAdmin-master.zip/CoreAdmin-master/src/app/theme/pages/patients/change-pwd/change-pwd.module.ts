import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { ChangePwdRoutingModule } from './change-pwd-routing.module';
import { ChangePwdComponent } from './change-pwd.component';
import { ChangePwdService } from './change-pwd.service';

@NgModule({
  imports: [
    CommonModule, ChangePwdRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpModule

  ],
  declarations: [ChangePwdComponent],
  bootstrap: [ChangePwdComponent],
  providers: [ChangePwdService, Validation],
  schemas : [CUSTOM_ELEMENTS_SCHEMA]
})
export class ChangePwdModule { }
