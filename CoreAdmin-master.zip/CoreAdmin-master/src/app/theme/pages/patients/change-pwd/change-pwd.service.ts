import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { Login, SignUp, ChangePwd } from '../../common/login';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class ChangePwdService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'Login/ChangePwd';

  public changePwd(loginobj: ChangePwd): Observable<any> {
    return this.http.post(this.posturl, loginobj);
  }
}
