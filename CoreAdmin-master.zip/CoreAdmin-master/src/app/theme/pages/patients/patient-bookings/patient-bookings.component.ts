import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-bookings',
  templateUrl: './patient-bookings.component.html',
  styleUrls: ['./patient-bookings.component.scss']
})
export class PatientBookingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
