import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientBookingsComponent } from './patient-bookings.component';

const routes: Routes = [
  {
    path: '',
    component: PatientBookingsComponent,
    data: {
      title: 'My Bookings',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientBookingsRoutingModule { }
