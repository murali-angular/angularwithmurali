import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { BookAmbulance } from '../../common/bookAmb';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { PatientRegistration } from '../../common/patientRegistration';

@Injectable()
export class PatientBookingsService {

  constructor(private http: HttpClient) { }


  posturl = environment.prod_URL + 'Patient/InsertPatient';
  geturlbyid = environment.prod_URL + 'Patient/InsertPatient';
  getallpatUrl = environment.prod_URL + 'Patient/InsertPatient';

  public BookAmbulance(ambobj: BookAmbulance): Observable<any> {
    return this.http.post(this.posturl, ambobj);
  }

  public GetAmbulanceByID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyid + ID);
  }

  public GetPatientRecord(PatName: any): Observable<PatientRegistration> {
    return this.http.get<PatientRegistration>(this.geturlbyid + PatName);
  }

  public GetPatientsList(): Observable<PatientRegistration[]> {
    return this.http.get<PatientRegistration[]>(this.getallpatUrl);
  }


}
