import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { PatientBookingsRoutingModule } from './patient-bookings-routing.module';
import { PatientBookingsComponent } from './patient-bookings.component';
import { PatientBookingsService } from './patient-bookings.service';

@NgModule({
  imports: [
    CommonModule, PatientBookingsRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpModule

  ],
  declarations: [PatientBookingsComponent],
  bootstrap: [PatientBookingsComponent],
  providers: [PatientBookingsService, Validation]
})
export class PatientBookingsModule { }
