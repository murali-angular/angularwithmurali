import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { Validation } from '../../../../shared/Validator';
import { PatientProfileRoutingModule } from './patient-profile-routing.module';
import { PatientProfileComponent } from './patient-profile.component';
import { PatientProfileService } from './patient-profile.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, PatientProfileRoutingModule, SharedModule, HttpModule, ReactiveFormsModule
  ],
  declarations: [PatientProfileComponent],
  bootstrap: [PatientProfileComponent],
  providers: [PatientProfileService, Validation]
})
export class PatientProfileModule { }
