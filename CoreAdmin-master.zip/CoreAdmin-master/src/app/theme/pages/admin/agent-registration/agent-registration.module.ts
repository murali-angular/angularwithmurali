import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { AgentRegistrationRoutingModule } from './agent-registration-routing.module';
import { AgentRegistrationComponent } from './agent-registration.component';
import { AgentRegistrationService } from './agent-registration.service';

@NgModule({
  imports: [
    CommonModule, AgentRegistrationRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpModule
  ],
  declarations: [AgentRegistrationComponent],
  bootstrap: [AgentRegistrationComponent],
  providers: [AgentRegistrationService, Validation],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AgentRegistrationModule { }
