import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AgentRegistration } from '../../common/agentRegistration';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AgentRegistrationService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Ambulance/InsertAmbulance';
  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  updateurl = environment.prod_URL + 'Ambulance/updateambulance';
  deleteurl = environment.prod_URL + 'Ambulance/DeleteAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulanceById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Ambulance/GetAmbulanceAmbOwnID/';



  public GetAgentByID(ID: any): Observable<any> {
    return this.http.get<AgentRegistration>(this.geturlbyid + ID);
  }

  public GetAllAgent(): Observable<any> {
    return this.http.get(this.geturlbyid);
  }


  public SaveAgent(agentobj: AgentRegistration): Observable<any> {
    return this.http.post(this.posturl, agentobj);
  }


  public UpdateAgent(agentobj: AgentRegistration): Observable<any> {
    return this.http.post(this.updateurl, agentobj);
  }

  public DeleteAgent(agentID): Observable<any> {
    return this.http.post(this.deleteurl, agentID);
  }
}
