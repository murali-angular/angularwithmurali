import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { AgentRegistrationService } from './agent-registration.service';
import { AgentRegistration } from '../../common/agentRegistration';
import { ActivatedRoute } from '@angular/router';
import { NotificationsService } from '../../../../shared/notification/notifications.service';


@Component({
  selector: 'app-agent-registration',
  templateUrl: './agent-registration.component.html',
  styleUrls: ['./agent-registration.component.css'],
  providers: [AgentRegistrationService, NotificationsService]
})
export class AgentRegistrationComponent implements OnInit {

  myForm: FormGroup;
  agentObj: AgentRegistration = new AgentRegistration();
  agentId;
  base64Image;
  constructor(private fb: FormBuilder, private valid: Validation, private service: AgentRegistrationService,
    private notes: NotificationsService,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      AgentName: this.valid.signupform.FirstName,
      AgentNumber: this.valid.signupform.MobileNumber,
      patientMail: this.valid.signupform.Email,
      AgentGender: this.valid.signupform.Gender,
      AgentAltNumber: this.valid.signupform.MobileNumber,
      AgentAddress : this.valid.signupform.Required
    });
    if (this.route.snapshot.url[1] !== undefined) {
      this.agentId = this.route.snapshot.url[1].path;
      if (this.agentId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.editAgentById(this.agentId);
      }
    }
  }

  editAgentById(agentId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetAgentByID(agentId).subscribe(data => {
    this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.agentObj = data;
    }, error => {
    });
  }


  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {
      this.base64Image = myReader.result;
    };
    myReader.readAsDataURL(file);
  }

  CreateAgent() {
    // this.ambulance.AmbLocation = this.autocompleteaddress;
    // this.agentObj.AmbImgPath = this.base64Image;
    // this.ambulance.AmbOwnID = localStorage.getItem('loggedUser');
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.SaveAgent(this.agentObj).subscribe(data => {
    this.notes.loadingSpinnerByMessage(false, 'Loading');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Ambulance Saved Successfully');
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
      this.base64Image = '';
    });
  }

  UpdateAgent() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.UpdateAgent(this.agentObj).subscribe(data => {
    this.notes.loadingSpinnerByMessage(false, 'Loading');
    this.notes.success('Updated successfully');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Updated Successfully');
    }, erro => {
      this.notes.error('Update Failed');
    });
  }

  DeleteAgent(agentId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.DeleteAgent(agentId).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Deleted successfully');
      this.ngOnInit();
    }, erro => {
      this.notes.error('Delete Failed');
    });
  }
}
