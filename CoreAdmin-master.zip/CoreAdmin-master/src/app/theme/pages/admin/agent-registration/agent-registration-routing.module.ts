import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgentRegistrationComponent } from './agent-registration.component';

const routes: Routes = [
  {
    path: '',
    component: AgentRegistrationComponent,
    data: {
      title: 'Agent Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: AgentRegistrationComponent,
    data: {
      title: 'Create Agent',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/agentId',
    component: AgentRegistrationComponent,
    data: {
      title: 'Edit Agent',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AgentRegistrationRoutingModule { }
