import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HospListComponent } from './hosp-list.component';

describe('HospListComponent', () => {
  let component: HospListComponent;
  let fixture: ComponentFixture<HospListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HospListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HospListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
