import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';

@Component({
  selector: 'app-hosp-list',
  templateUrl: './hosp-list.component.html',
  styleUrls: ['./hosp-list.component.scss']
})
export class HospListComponent implements OnInit {


  dataSource;
  HospList: [] = [];

  constructor(public service: HospitalDetailsService, public router: Router) { }

  displayedColumns: string[] = ['HospName', 'HospNum', 'HospAltNum', 'HospAddress', 'HospType', 'View'];

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.getHospList();
  }

  getHospList() {
    this.service.GetHospitalsList().subscribe((res: any) => {
      this.HospList = res;
      this.dataSource = new MatTableDataSource(this.HospList);
      this.dataSource.paginator = this.paginator;
    });
  }

  addNewHospital() {
    this.router.navigate(['/createorder']);
  }

  editHospital(element) {
    console.log(element);
    this.router.navigate(['/subscriptiondtl/' + element.id]);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
