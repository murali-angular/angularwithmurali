import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { HospListRoutingModule } from './hosp-list-routing.module';
import { HospListComponent } from './hosp-list.component';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';


@NgModule({
  imports: [
    CommonModule, FormsModule, HospListRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [HospListComponent],
  bootstrap: [HospListComponent],
  providers: [HospitalDetailsService, Validation]
})
export class HospListModule { }
