import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { BookHospAmbRoutingModule } from './book-hosp-amb-routing.module';
import { BookHospAmbComponent } from './book-hosp-amb.component';
import { BookHospAmbService } from './book-hosp-amb.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, BookHospAmbRoutingModule, ReactiveFormsModule, SharedModule, HttpModule
  ],
  declarations: [BookHospAmbComponent],
  bootstrap: [BookHospAmbComponent],
  providers: [BookHospAmbService, Validation]
})
export class BookHospAmbModule { }
