import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookHospAmbComponent } from './book-hosp-amb.component';


const routes: Routes = [
  {
    path: '',
    component: BookHospAmbComponent,
    data: {
      title: 'Free Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: BookHospAmbComponent,
    data: {
      title: 'Free Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/:SelectedHospDocId',
    component: BookHospAmbComponent,
    data: {
      title: 'Free Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BookHospAmbRoutingModule { }
