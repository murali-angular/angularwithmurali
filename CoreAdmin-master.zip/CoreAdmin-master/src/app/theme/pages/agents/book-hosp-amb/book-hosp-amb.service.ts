import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { PatientRegistration } from '../../common/patientRegistration';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { BookFreeAmb } from '../../common/bookFreeAmb';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HospAmbReg } from '../../common/hospAmbReg';

@Injectable()
export class BookHospAmbService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'BookAmbulance/InsertBookAmbulance';
  getbyidurl = environment.prod_URL + 'BookAmbulance/GetBookAmbulanceDetailsByAmbOwnerID/';
  updateurl = environment.prod_URL + 'Patient/UpdatePatientDetailsByID';
  bookmailpatienturl = environment.prod_URL + 'MailMessage/BookAmbPatientMail';
  bookmailOwnerurl = environment.prod_URL + 'MailMessage/BookAmbOwnerMail';
  bookedambPatientMsgurl = environment.prod_URL + 'Message/SendMessageBookAmbPatient';
  bookedAmbOwnerMsgurl = environment.prod_URL + 'Message/SendMessageBookAmbOwner';
  bookedSuperAdminMsgurl = environment.prod_URL + 'Message/SendMessageBookDetailsToSuperAdmin';
  gethospamburlbyid = environment.prod_URL + 'Message/SendMessageBookDetailsToSuperAdmin';

  public BookAmbulance(ambulance: BookFreeAmb): Observable<any> {
    return this.http.post(this.posturl, ambulance);
  }

  public updatePatient(patientobjID: PatientRegistration): Observable<any> {
    return this.http.post(this.updateurl, patientobjID);
  }

  public BookMailToPatient(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailpatienturl, mail);
  }

  public BookMailToAmbOwner(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailOwnerurl, mail);
  }

  public MessageToBookedAmbPatient(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedambPatientMsgurl, message);
  }

  public MessageToBookedAmbOwner(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedAmbOwnerMsgurl, message);
  }

  public MessageToSuperAdmin(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedSuperAdminMsgurl, message);
  }

  public GetAmbulanceByID(ID: any): Observable<HospAmbReg> {
    return this.http.get<HospAmbReg>(this.gethospamburlbyid + ID);
  }


}
