import { Component, OnInit } from '@angular/core';
import { AgentsAmbListService } from './agents-amb-list.service';
import { Router } from '@angular/router';
import { AmbList } from '../../common/ambulanceList';
import { SearchFilterPipe } from '../../../../shared/searchfilter.pipe';
import { AmbRegistration } from '../../common/ambRegistration';


@Component({
  selector: 'app-agents-amb-list',
  templateUrl: './agents-amb-list.component.html',
  styleUrls: ['./agents-amb-list.component.css'],
  providers: [SearchFilterPipe]
})
export class AgentsAmbListComponent implements OnInit {

  ambList = [];
  search: AmbRegistration = new AmbRegistration();

  constructor(private service: AgentsAmbListService, private router: Router) {

  }

  ngOnInit() {
    this.getAmb();
  }

  getAmb() {
    this.service.GetAmbulance().subscribe(data => {
      this.ambList = data;
    }, error => {
    });
  }

  // callAmb(AmbId) {
  //   //// this can be done deepija
  // }

  callAmb(AID) {
    this.router.navigateByUrl('/scheduleAmb/edit/' + AID);
  }

  bookAmb(ambID) {
    this.router.navigateByUrl('/bookAmbualnce/' + ambID);
  }

  editAmbById(ambID) {
    this.router.navigateByUrl('/ambualnceRegistration/' + ambID);
  }

  deleteAmb(ambID) {
    this.service.RemoveAmbulanceByID(ambID).subscribe(data => {
    }, error => {
    });
  }
}


