import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AgentsAmbListRoutingModule } from './agents-amb-list-routing.module';
import { AgentsAmbListComponent } from './agents-amb-list.component';
import { AgentsAmbListService } from './agents-amb-list.service';
import { SharedModule } from '../../../../shared/shared.module';
import { BsDropdownModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule, FormsModule, AgentsAmbListRoutingModule, SharedModule, HttpClientModule, BsDropdownModule.forRoot()
  ],
  declarations: [AgentsAmbListComponent],
  bootstrap: [AgentsAmbListComponent],
  providers: [AgentsAmbListService]
})
export class AgentsAmbListModule { }
