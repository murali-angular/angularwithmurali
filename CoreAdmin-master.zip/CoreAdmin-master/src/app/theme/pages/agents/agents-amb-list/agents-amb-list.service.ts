import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbList } from '../../common/ambulanceList';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AmbRegistration } from '../../common/ambRegistration';

@Injectable()
export class AgentsAmbListService {

  constructor(private http: HttpClient) { }

  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulance';
  deleteurl = environment.prod_URL + 'Ambulance/GetAmbulance/';
  updateurl = environment.prod_URL + 'Ambulance/GetAmbulance';

  public GetAmbulance(): Observable<AmbList[]> {
    return this.http.get<AmbList[]>(this.geturl);
  }

  public GetAmbulanceByID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyid + ID);
  }

  public RemoveAmbulanceByID(ambulanceID): Observable<any> {
    return this.http.delete(this.deleteurl + ambulanceID);
  }

  public UpdateAmb(ambulance: AmbRegistration): Observable<any> {
    return this.http.post(this.updateurl, ambulance);
  }
}
