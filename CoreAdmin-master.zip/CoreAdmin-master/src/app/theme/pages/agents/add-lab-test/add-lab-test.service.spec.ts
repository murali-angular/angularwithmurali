import { TestBed } from '@angular/core/testing';

import { AddLabTestService } from './add-lab-test.service';

describe('AddLabTestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddLabTestService = TestBed.get(AddLabTestService);
    expect(service).toBeTruthy();
  });
});
