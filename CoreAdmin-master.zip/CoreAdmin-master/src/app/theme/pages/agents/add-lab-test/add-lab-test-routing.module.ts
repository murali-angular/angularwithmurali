import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddLabTestComponent } from './add-lab-test.component';

const routes: Routes = [
  {
    path: '',
    component: AddLabTestComponent,
    data: {
      title: 'Add lab Test',
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddLabTestRoutingModule { }
