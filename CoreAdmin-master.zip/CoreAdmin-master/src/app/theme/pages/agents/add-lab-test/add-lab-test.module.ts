import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { AddLabTestRoutingModule } from './add-lab-test-routing.module';
import { AddLabTestComponent } from './add-lab-test.component';
import { AddLabTestService } from './add-lab-test.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, AddLabTestRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [AddLabTestComponent],
  bootstrap: [AddLabTestComponent],
  providers: [AddLabTestService, Validation]
})
export class AddLabTestModule { }
