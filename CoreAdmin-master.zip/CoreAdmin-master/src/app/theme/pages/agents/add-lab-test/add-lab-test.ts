import { ConfigLabTest } from '../config-lab-test/config-lab-test';

export class AddLabTest {
    ReferalId ; string;
    ConfigTestId: string;
    PatientId: string;
    LabTests: ConfigLabTest[] = [];
    Discount: string;
    GrossTotal: string;
    NetTotal: string;

}

