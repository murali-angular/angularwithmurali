import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from 'src/app/shared/Validator';
import { NotificationsService } from 'src/app/shared/notification/notifications.service';
import { ActivatedRoute } from '@angular/router';
import { ConfigLabTest } from '../config-lab-test/config-lab-test';
import { AddLabTestService } from './add-lab-test.service';

@Component({
  selector: 'app-add-lab-test',
  templateUrl: './add-lab-test.component.html',
  styleUrls: ['./add-lab-test.component.scss']
})
export class AddLabTestComponent implements OnInit {

  myForm: FormGroup;
  addlabtestObj: ConfigLabTest = new ConfigLabTest();

  constructor(private fb: FormBuilder, private valid: Validation, private service: AddLabTestService,
    private notes: NotificationsService,
    private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      LabTestName: this.valid.signupform.FirstName,
      LabTestPrice: this.valid.signupform.MobileNumber,
      LabTestDesc: this.valid.signupform.showpass,
      Discount: this.valid.signupform.showpass,
      FinalPrice: this.valid.signupform.showpass,
    });
  }


  AddLabTest() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.SaveLabTest(this.addlabtestObj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Ambulance Saved Successfully');
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
    });
  }

  UpdateLab() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.UpdateLabTest(this.addlabtestObj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Updated successfully');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Updated Successfully');
    }, erro => {
      this.notes.error('Update Failed');
    });
  }

  DeleteLab(LabId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.DeleteLabTest(LabId).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Deleted successfully');
      this.ngOnInit();
    }, erro => {
      this.notes.error('Delete Failed');
    });
  }

}
