import { TestBed } from '@angular/core/testing';

import { ViewLabReportsService } from './view-lab-reports.service';

describe('ViewLabReportsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewLabReportsService = TestBed.get(ViewLabReportsService);
    expect(service).toBeTruthy();
  });
});
