import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLabReportsComponent } from './view-lab-reports.component';

describe('ViewLabReportsComponent', () => {
  let component: ViewLabReportsComponent;
  let fixture: ComponentFixture<ViewLabReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLabReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLabReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
