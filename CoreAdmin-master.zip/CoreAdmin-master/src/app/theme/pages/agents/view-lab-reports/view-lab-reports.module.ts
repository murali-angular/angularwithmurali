import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { ViewLabReportsRoutingModule } from './view-lab-reports-routing.module';
import { ViewLabReportsComponent } from './view-lab-reports.component';
import { ViewLabReportsService } from './view-lab-reports.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, ViewLabReportsRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [ViewLabReportsComponent],
  bootstrap: [ViewLabReportsComponent],
  providers: [ViewLabReportsService, Validation]
})
export class ViewLabReportsModule { }
