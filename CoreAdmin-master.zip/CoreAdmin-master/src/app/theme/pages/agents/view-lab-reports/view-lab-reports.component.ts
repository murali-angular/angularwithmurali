import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-lab-reports',
  templateUrl: './view-lab-reports.component.html',
  styleUrls: ['./view-lab-reports.component.scss']
})
export class ViewLabReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
