import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { PatientRegistration } from '../../common/patientRegistration';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { BookDoctorAppoint } from '../../common/bookAmb';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class BookHospDocService {

  constructor(private http: HttpClient) { }

  posturl = environment.prod_URL + 'BookHospDoc/InsertBookHospDoc';
  getbyidurl = environment.prod_URL + 'BookAmbulance/GetBookAmbulanceDetailsByAmbOwnerID/';
  updateurl = environment.prod_URL + 'Patient/UpdatePatientDetailsByID';
  bookmailpatienturl = environment.prod_URL + 'MailMessage/BookAmbPatientMail';
  bookmailOwnerurl = environment.prod_URL + 'MailMessage/BookAmbOwnerMail';
  bookedambPatientMsgurl = environment.prod_URL + 'Message/SendMessageDocApp';
  bookedAmbOwnerMsgurl = environment.prod_URL + 'Message/SendMessageToHospAboutDocApp';
  bookedSuperAdminMsgurl = environment.prod_URL + 'Message/SendMessageBookDetailsToSuperAdmin';


  public bookdocAppointment(hsopDocObj: BookDoctorAppoint): Observable<any> {
    return this.http.post(this.posturl, hsopDocObj);
  }

  public updatePatient(patientobjID: PatientRegistration): Observable<any> {
    return this.http.post(this.updateurl, patientobjID);
  }

  public BookMailToPatient(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailpatienturl, mail);
  }

  public BookMailToAmbOwner(mail: MailMessage): Observable<any> {
    return this.http.post(this.bookmailOwnerurl, mail);
  }

  public MessageToBookedAmbPatient(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedambPatientMsgurl, message);
  }

  public MessageToBookedAmbOwner(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedAmbOwnerMsgurl, message);
  }

  public MessageToSuperAdmin(message: MessageModel): Observable<any> {
    return this.http.post(this.bookedSuperAdminMsgurl, message);
  }


}
