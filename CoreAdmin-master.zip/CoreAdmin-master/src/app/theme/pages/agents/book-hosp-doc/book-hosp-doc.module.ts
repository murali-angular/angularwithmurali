import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { BookHospDocRoutingModule } from './book-hosp-doc-routing.module';
import { BookHospDocComponent } from './book-hosp-doc.component';
import { BookHospDocService } from './book-hosp-doc.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, BookHospDocRoutingModule, ReactiveFormsModule, SharedModule, HttpModule
  ],
  declarations: [BookHospDocComponent],
  bootstrap: [BookHospDocComponent],
  providers: [BookHospDocService, Validation]
})
export class BookHospDocModule { }
