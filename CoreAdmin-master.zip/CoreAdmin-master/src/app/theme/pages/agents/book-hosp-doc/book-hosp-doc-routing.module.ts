import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookHospDocComponent } from './book-hosp-doc.component';

// const routes: Routes = [
//   {
//     path: '', component: BookHospDocComponent,
//     children: [
//       {
//         path: '', component: BookHospDocComponent, data: {
//           title: 'Book Appointment'
//         }
//       },
//       {
//         path: 'edit/:HospDocId', component: BookHospDocComponent, data: {
//           title: 'Book Appointment'
//         }
//       }
//     ]
//   }
// ];

const routes: Routes = [
  {
    path: '',
    component: BookHospDocComponent,
    data: {
      title: 'Book Appointment ',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: BookHospDocComponent,
    data: {
      title: 'Book Appointment',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/:hospDocId',
    component: BookHospDocComponent,
    data: {
      title: 'Book Appointment',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class BookHospDocRoutingModule { }
