import { Component, OnInit, Input } from '@angular/core';
import { BookAmbulance, BookDoctorAppoint } from '../../common/bookAmb';
import { ActivatedRoute, Router } from '@angular/router';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Login } from '../../common/login';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { PatientRegistration } from '../../common/patientRegistration';
import { PatientRegistrationService } from '../../agents/patient-registration/patient-registration.service';
import { BookHospDocService } from './book-hosp-doc.service';
import { HospitalDoctorsService } from '../hospital-doctors/hospital-doctors.service';
import { HospDoc, HospDetails } from '../../common/hospAmbReg';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { NotificationsService } from '../../../../shared/notification/notifications.service';



@Component({
  selector: 'app-book-hosp-doc',
  templateUrl: './book-hosp-doc.component.html',
  styleUrls: ['./book-hosp-doc.component.css'],
  providers: [BookHospDocService, HospitalDoctorsService, PatientRegistrationService, HospitalDetailsService]
})
export class BookHospDocComponent implements OnInit {

  myForm: FormGroup;
  bookDocobj: BookDoctorAppoint = new BookDoctorAppoint();
  hospobj: HospDetails = new HospDetails();
  SelectedHospDocId;
  selecteddocdetails: HospDoc = new HospDoc();

  login: Login = new Login();
  MessageStatement = 'You have booked an Appointment with Dr DoctorNme on date at time. Location: HospAddress, HospNumber.Thanks for Booking www.ambufree.com';
  MessageClientStatement = 'Dr DoctorNme, patName, patNum,has booked an appointment with you on date at time.www.ambufree.com';

  mail: MailMessage = new MailMessage();

  isBookedUserDisabled = true;
  isEditHidden = false;
  isUpdateHidden = true;
  messagemodel: MessageModel = new MessageModel();
  patientDetails: PatientRegistration = new PatientRegistration();
  // autocompletepatientaddress: string;
  selectDate;
  selectTime;
  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private service: BookHospDocService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    // private toastr: ToastrService,
    public domSanitizer: DomSanitizer,
    private patientservice: PatientRegistrationService,
    private hospdocservice: HospitalDoctorsService,
    private hospdetailservice: HospitalDetailsService,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    if (this.route.snapshot.url[1] !== undefined) {
      this.SelectedHospDocId = this.route.snapshot.url[1].path;
      if (this.SelectedHospDocId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.RetieveHospDocByID(this.SelectedHospDocId);
        this.getPatientDetails();
      }
    }
    this.myForm = this.fb.group({
      PatientName: this.valid.signupform.FirstName,
      PatientNumber: this.valid.signupform.MobileNumber,
      PatientAddress: this.valid.signupform.Required,
      SelectedDate: this.valid.signupform.Required,
      SelectedTime: this.valid.signupform.Required,
      // PatientCondition: this.valid.signupform.remarks
    });
  }


  RetieveHospDocByID(AID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.GetDoctorRecordByID(AID).subscribe(data => {
      this.selecteddocdetails = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.editHospById(this.selecteddocdetails.HospId);
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  editHospById(hospID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdetailservice.GetHospByID(hospID).subscribe(data => {
      this.hospobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, error => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  getPatientDetails() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.patientservice.GetPatientDetailsByID(localStorage.getItem('loggedUser')).subscribe(data => {
      this.patientDetails = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }


  BookDocAppointment() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    // this.bookAmb.PatientAddress = this.autocompletepatientaddress;
    this.bookDocobj.HospDocId = this.SelectedHospDocId;
    // this.bookAmb.AmbOwnerID = this.selectedambdetails.AmbOwnID;
    // this.bookDocobj.PatientName = this.patientDetails.PatientName;
    // this.bookDocobj.PatientNumber = this.patientDetails.PatientNumber;
    // this.bookDocobj.PatientEmail = '';
    // this.bookDocobj.PatientAddress = this.patientDetails.PatientAddress;

    // this.bookDocobj.PatientID = this.patientDetails.PatientID;
    this.bookDocobj.PatientID = this.patientDetails.PatientID;
    this.bookDocobj.SelectedDate = this.selectDate;
    this.bookDocobj.SelectedTime = this.selectTime;

    this.service.bookdocAppointment(this.bookDocobj).subscribe(data => {

      this.updatePatientProfile();
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Appointment Booked Successfully');
      // this.toastr.success('Ambulance Booked Successfully');
      this.sendBookDocToPatientMessage();
      this.sendToHospAboutDocAppMessage();
      // this.sendToSuperAdmin();
      // this.sendBookAmbToAmbOwnerMailMessage();
      // this.sendBookAmbToPatientMailMessage();
      this.router.navigate(['/Thankyou']);
    }, erro => {
    });
  }

  // EditPatientProfile() {
  //   this.isEditHidden = true;
  //   this.isUpdateHidden = false;
  //   this.isBookedUserDisabled = false;
  // }


  sendBookDocToPatientMessage() {
    this.messagemodel.DoctorNme = this.selecteddocdetails.HospDocName;
    this.messagemodel.HospAddress = this.hospobj.HospName;
    this.messagemodel.HospNumber = this.hospobj.HospAltNum;
    this.messagemodel.message = this.MessageStatement;
    this.messagemodel.date = this.bookDocobj.SelectedDate;
    this.messagemodel.time = this.bookDocobj.SelectedTime;
    this.messagemodel.numbers = this.patientDetails.PatientNumber;
    this.service.MessageToBookedAmbPatient(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

  // RetrieveAmbOwnerById() {
  //   this.ambownerservice.GetByAmbOwnerName(this.selectedambdetails.AmbOwnID).subscribe(data => {
  //     this.AmbOwnerDetails = data;
  //   }, erro => {
  //   });
  // }

  sendToHospAboutDocAppMessage() {
    this.messagemodel.DoctorNme = this.selecteddocdetails.HospDocName;
    this.messagemodel.messageClient = this.MessageClientStatement;
    this.messagemodel.date = this.bookDocobj.SelectedDate;
    this.messagemodel.time = this.bookDocobj.SelectedTime;
    this.messagemodel.numbers = this.hospobj.HospNum;
    this.messagemodel.patName = this.patientDetails.PatientName;
    this.messagemodel.patNum = this.patientDetails.PatientNumber;
    this.service.MessageToBookedAmbOwner(this.messagemodel).subscribe(data => {
    }, erro => {
    });
  }

  // sendToSuperAdmin() {
  //   // this.messagemodel.Type = this.selectedambdetails.AmbType;
  //   this.messagemodel.VehicleName = this.selectedambdetails.AmbName;
  //   this.messagemodel.messageClient = this.MessageSuperAdmin;
  //   this.messagemodel.date = this.bookAmb.SelectedDate;
  //   this.messagemodel.time = this.bookAmb.SelectedTime;
  //   this.messagemodel.numbers = '8639148429';
  //   this.messagemodel.patName = this.bookAmb.PatientName;
  //   this.messagemodel.patNum = this.bookAmb.PatientNum;
  //   this.messagemodel.AmbNumber = this.bookAmb.DriverNum;
  //   // this.messagemodel.patientAddress = this.autocompletepatientaddress;
  //   this.service.MessageToSuperAdmin(this.messagemodel).subscribe(data => {
  //   }, erro => {
  //   });
  // }

  // sendBookAmbToPatientMailMessage() {
  //   this.mail.UserName = this.bookAmb.PatientName;
  //   this.mail.SelectedDate = this.bookAmb.SelectedDate;
  //   this.mail.SelectedTime = this.bookAmb.SelectedTime;
  //   this.mail.DriverName = this.selectedambdetails.DriverName;
  //   this.mail.DriverNum = this.selectedambdetails.DriverNum;
  //   this.mail.AmbNumberPlate = this.selectedambdetails.AmbNumberPlate;
  //   this.mail.AmbName = this.selectedambdetails.AmbName;
  //   this.mail.AmbNum = this.selectedambdetails.DriverNum;
  //   this.mail.UserEmail = this.selectedambdetails.AmbMail;
  //   this.service.BookMailToPatient(this.mail).subscribe(data => {
  //     // this.mail = new MailMessage();
  //   }, erro => {
  //     this.mail = new MailMessage();
  //   });
  // }

  // sendBookAmbToAmbOwnerMailMessage() {
  //   // this.mail.ClientName = this.ambobj.AmbOwnName;
  //   this.mail.SelectedDate = this.bookAmb.SelectedDate;
  //   this.mail.SelectedTime = this.bookAmb.SelectedTime;
  //   this.mail.DriverName = this.bookAmb.PatientName;
  //   this.mail.DriverNum = this.bookAmb.PatientNum;
  //   this.mail.AmbNumberPlate = this.bookAmb.PatientAddress;
  //   this.mail.AmbName = this.selectedambdetails.AmbName;
  //   this.mail.UserEmail = this.selectedambdetails.AmbMail;
  //   this.service.BookMailToAmbOwner(this.mail).subscribe(data => {
  //     // this.mail = new MailMessage();
  //   }, erro => {
  //     this.mail = new MailMessage();
  //   });
  // }

  updatePatientProfile() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.patientservice.updatePatient(this.patientDetails).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.isUpdateHidden = true;
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }


}
