import { Injectable } from '@angular/core';
import { environment } from '../../../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddLabTest } from '../add-lab-test/add-lab-test';

@Injectable({
  providedIn: 'root'
})
export class ConfigLabTestService {


  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Hospital/InsertHospital';
  geturl = environment.prod_URL + 'Hospital/GetHospitalList';
  updateurl = environment.prod_URL + 'Hospital/updateHospital';
  deleteurl = environment.prod_URL + 'Hospital/DeleteHospital/';
  geturlbyid = environment.prod_URL + 'Hospital/GethospitalById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Hospital/GetAmbulanceAmbOwnID/';


  public GetLabTestByTestID(ID: any): Observable<AddLabTest> {
    return this.http.get<AddLabTest>(this.geturlbyAmbOwnid + ID);
  }

  public GetLabTestsList(): Observable<AddLabTest[]> {
    return this.http.get<AddLabTest[]>(this.geturl);
  }

  public SaveConfigLabTest(hospobj: AddLabTest): Observable<any> {
    return this.http.post(this.posturl, hospobj);
  }


  public UpdateLabTest(hospobj: AddLabTest): Observable<any> {
    return this.http.post(this.updateurl, hospobj);
  }

  public DeleteLabTest(hospId): Observable<any> {
    return this.http.post(this.deleteurl, hospId);
  }
}
