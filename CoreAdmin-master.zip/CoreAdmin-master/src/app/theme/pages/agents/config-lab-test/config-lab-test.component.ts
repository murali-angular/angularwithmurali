import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from 'src/app/shared/Validator';
import { AddLabTestService } from '../add-lab-test/add-lab-test.service';
import { NotificationsService } from 'src/app/shared/notification/notifications.service';
import { ActivatedRoute } from '@angular/router';
import { AddLabTest } from '../add-lab-test/add-lab-test';
import { isNullOrUndefined } from 'util';
import { PatientRegistrationService } from '../patient-registration/patient-registration.service';
import { ConfigLabTest } from './config-lab-test';
import { ConfigLabTestService } from './config-lab-test.service';

@Component({
  selector: 'app-config-lab-test',
  templateUrl: './config-lab-test.component.html',
  styleUrls: ['./config-lab-test.component.scss']
})
export class ConfigLabTestComponent implements OnInit {

  // myForm: FormGroup;
  configlabObj: AddLabTest = new AddLabTest();
  labtestobj: ConfigLabTest = new ConfigLabTest();
  Patientlist: [] = [];
  labtestlist: [] = [];
  Referrallist: [] = [];

  fieldArray: any[] = [];
  newAttribute: ConfigLabTest = new ConfigLabTest();

  constructor(private fb: FormBuilder, private valid: Validation, private service: AddLabTestService,
    private notes: NotificationsService, private patservice: PatientRegistrationService,
    private route: ActivatedRoute,
    private configservice: ConfigLabTestService) {

  }

  ngOnInit() {
    // this.myForm = this.fb.group({
    //   PatientName: this.valid.signupform.FirstName,
    //   LabTestPrice: this.valid.signupform.MobileNumber,
    //   LabTestDesc: this.valid.signupform.showpass,
    //   Discount: this.valid.signupform.showpass,
    //   FinalPrice: this.valid.signupform.showpass,
    // });
  }

  getPatList() {
    this.patservice.GetPatientList().subscribe((res: any) => {
      this.Patientlist = res;
    });
  }

  getlabTestList() {
    this.service.GetLabTestsList().subscribe((res: any) => {
      this.labtestlist = res;
    });
  }

  // getReferralList() {
  //   this.service.GetReferralList().subscribe((res: any) => {
  //     this.Referrallist = res;
  //   });
  // }

  // onChangeLabName(LabId: string) {
  //   this.notes.loadingSpinnerByMessage(true, 'Loading');
  //   this.service.GetLabTestByTestID(LabId).subscribe(data => {
  //     this.notes.loadingSpinnerByMessage(false, 'Loading');
  //     this.ngOnInit();
  //   }, erro => {
  //   });
  // }

  ConfigLabTest() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.configservice.SaveConfigLabTest(this.configlabObj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Ambulance Saved Successfully');
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
    });
  }

  addFieldValue() {
    // tslint:disable-next-line: deprecation
    if (!isNullOrUndefined(this.newAttribute)) {
      this.fieldArray.push(this.newAttribute);
      // this.removeDuplicates(this.fieldArray);
    } else {
      this.fieldArray = [];
    }
  }


  removeDuplicates(arr: any[]) {
    this.fieldArray = [];
    for (let i = 0; i < arr.length; i++) {
      arr[i] = '' + arr[i] + '';
      if (this.fieldArray.indexOf(arr[i]) === -1) {
        this.fieldArray.push(arr[i]);
      }
    }
    return this.fieldArray;
  }


  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
    if (this.fieldArray.length <= 0) {
      this.newAttribute = new ConfigLabTest();
    }
  }

}
