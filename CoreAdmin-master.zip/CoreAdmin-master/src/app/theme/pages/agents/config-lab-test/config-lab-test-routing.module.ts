import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfigLabTestComponent } from './config-lab-test.component';

const routes: Routes = [
  {
    path: '',
    component: ConfigLabTestComponent,
    data: {
      title: 'Config lab Test',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigLabTestRoutingModule { }
