import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { ConfigLabTestRoutingModule } from './config-lab-test-routing.module';
import { ConfigLabTestComponent } from './config-lab-test.component';
import { ConfigLabTestService } from './config-lab-test.service';
import { PatientRegistrationService } from '../patient-registration/patient-registration.service';

@NgModule({
  imports: [
    CommonModule, FormsModule, ConfigLabTestRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [ConfigLabTestComponent],
  bootstrap: [ConfigLabTestComponent],
  providers: [ConfigLabTestService, Validation, PatientRegistrationService]
})
export class ConfigLabTestModule { }
