export class ConfigLabTest {
    LabTestId: string;
    LabTestName: string;
    LabTestDesc: string;
    LabTestPrice: string;
    Discount: string;
    AdditionDiscount: string;
    FinalPrice: string;
}


