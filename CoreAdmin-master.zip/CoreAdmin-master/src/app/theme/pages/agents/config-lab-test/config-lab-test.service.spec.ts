import { TestBed } from '@angular/core/testing';

import { ConfigLabTestService } from './config-lab-test.service';

describe('ConfigLabTestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConfigLabTestService = TestBed.get(ConfigLabTestService);
    expect(service).toBeTruthy();
  });
});
