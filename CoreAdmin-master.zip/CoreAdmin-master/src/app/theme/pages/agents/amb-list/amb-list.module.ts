import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { AmbListRoutingModule } from './amb-list-routing.module';
import { AmbListComponent } from './amb-list.component';
import { AmbulanceRegistrationService } from '../ambulance-registration/ambulance-registration.service';


@NgModule({
  imports: [
    CommonModule, FormsModule, AmbListRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [AmbListComponent],
  bootstrap: [AmbListComponent],
  providers: [AmbulanceRegistrationService, Validation]
})
export class AmbListModule { }
