import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { AmbulanceRegistrationService } from '../ambulance-registration/ambulance-registration.service';

@Component({
  selector: 'app-amb-list',
  templateUrl: './amb-list.component.html',
  styleUrls: ['./amb-list.component.scss']
})
export class AmbListComponent implements OnInit {


  dataSource;
  AmbList: [] = [];

  constructor(public service: AmbulanceRegistrationService, public router: Router) { }

  displayedColumns: string[] = ['AmbName', 'AmbNumber', 'AmbAltNumber', 'AmbAddress', 'AmbType' , 'DriverName', 'DriverNum', 'View'];

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.getAmbList();
  }

  getAmbList() {
    this.service.GetAmbulance().subscribe((res: any) => {
      this.AmbList = res;
      this.dataSource = new MatTableDataSource(this.AmbList);
      this.dataSource.paginator = this.paginator;
    });
  }

  addNewAmbulance() {
    this.router.navigate(['/createorder']);
  }

  editAmbulance(element) {
    console.log(element);
    this.router.navigate(['/subscriptiondtl/' + element.id]);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
