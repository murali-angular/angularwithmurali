import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgentHospListComponent } from './agent-hosp-list.component';

const routes: Routes = [
  {
    path: '',
    component: AgentHospListComponent,
    data: {
      title: 'Agents Hospital List',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentHospListRoutingModule { }
