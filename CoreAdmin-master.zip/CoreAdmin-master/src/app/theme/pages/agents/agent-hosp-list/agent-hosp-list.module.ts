import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { BsDropdownModule } from 'ngx-bootstrap';
import { AgentHospListRoutingModule } from './agent-hosp-list-routing.module';
import { AgentHospListComponent } from './agent-hosp-list.component';
import { AgentsAmbListService } from '../agents-amb-list/agents-amb-list.service';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule, FormsModule, AgentHospListRoutingModule, SharedModule, HttpClientModule, BsDropdownModule.forRoot()
  ],
  declarations: [AgentHospListComponent],
  bootstrap: [AgentHospListComponent],
  providers: [AgentsAmbListService, HospitalDetailsService]
})
export class AgentHospListModule { }
