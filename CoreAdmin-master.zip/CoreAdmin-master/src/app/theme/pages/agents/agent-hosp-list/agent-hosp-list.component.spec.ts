import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentHospListComponent } from './agent-hosp-list.component';

describe('AgentHospListComponent', () => {
  let component: AgentHospListComponent;
  let fixture: ComponentFixture<AgentHospListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentHospListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentHospListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
