import { Component, OnInit } from '@angular/core';
import { HospDetails } from '../../common/hospAmbReg';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { Router } from '@angular/router';
import { SearchHospFilterPipe } from '../../../../shared/searchhosp.pipe';

@Component({
  selector: 'app-agent-hosp-list',
  templateUrl: './agent-hosp-list.component.html',
  styleUrls: ['./agent-hosp-list.component.css'],
  providers: [SearchHospFilterPipe]

})
export class AgentHospListComponent implements OnInit {

  GetHospDetails = [];
  hospsearch: HospDetails = new HospDetails();

  constructor(private service: HospitalDetailsService, private router: Router) {

  }

  ngOnInit() {
    this.RetrieveHospitalsList();
  }

  // getAmb() {
  //   this.service.GetAmbulance().subscribe(data => {
  //     this.ambList = data;
  //   }, error => {
  //   });
  // }

  callAmb(AID) {
    this.router.navigateByUrl('/scheduleAmb/edit/' + AID);
  }

  bookAmb(ambID) {
    this.router.navigateByUrl('/bookAmbualnce/' + ambID);
  }

  editAmbById(ambID) {
    this.router.navigateByUrl('/ambualnceRegistration/' + ambID);
  }

  // deleteAmb(ambID) {
  //   this.service.RemoveAmbulanceByID(ambID).subscribe(data => {
  //   }, error => {
  //   });
  // }

  RetrieveHospitalsList() {
    // this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetHospitalsList().subscribe(data => {
      this.GetHospDetails = data;
      // this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      // this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

}
