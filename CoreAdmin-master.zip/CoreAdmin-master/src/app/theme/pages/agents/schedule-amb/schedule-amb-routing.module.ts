import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ScheduleAmbComponent } from './schedule-amb.component';

const routes: Routes = [
  {
    path: 'edit/:AmbID',
    component: ScheduleAmbComponent,
    data: {
      title: 'Contact Form',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ScheduleAmbRoutingModule { }
