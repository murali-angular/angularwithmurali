import { Component, OnInit, Input } from '@angular/core';
import { BookAmbulance, BookDoctorAppoint } from '../../common/bookAmb';
import { ActivatedRoute, Router } from '@angular/router';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Login } from '../../common/login';
import { MailMessage } from '../../common/mailmessage';
import { MessageModel } from '../../common/message';
import { PatientRegistration } from '../../common/patientRegistration';
import { PatientRegistrationService } from '../../agents/patient-registration/patient-registration.service';
import { HospDoc, HospDetails } from '../../common/hospAmbReg';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { ScheduleAmbService } from './schedule-amb.service';
import { Contact } from '../../common/contactus';



@Component({
    selector: 'app-schedule-amb',
    templateUrl: './schedule-amb.component.html',
    styleUrls: ['./schedule-amb.component.css'],
    providers: [ScheduleAmbService, PatientRegistrationService, HospitalDetailsService]

})
export class ScheduleAmbComponent implements OnInit {
    SelectedId;
    contactObj: Contact = new Contact();
    
    MessageStatement = 'Hi patName,Thank you for availing Ambulance service. We will contact you soon.www.ambufree.com';

    messagemodel: MessageModel = new MessageModel();
    mail: MailMessage = new MailMessage();

    constructor(private fb: FormBuilder,
        private route: ActivatedRoute,
        private valid: Validation, private service: ScheduleAmbService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        // private toastr: ToastrService,
        public domSanitizer: DomSanitizer,
        private patientservice: PatientRegistrationService,
        private hospdetailservice: HospitalDetailsService

    ) {

    }

    ngOnInit() {
        if (this.route.snapshot.url[1] !== undefined) {
            this.SelectedId = this.route.snapshot.url[1].path;
            if (this.SelectedId !== undefined && this.route.snapshot.url[0].path === 'edit') {
                // this.RetrieveAmbByID(this.SelectedId);
                // this.RetrieveHospAmbByID(this.SelectedId);
                // this.getPatientDetails();
            }
        }
    }

    ContactForAmbulance() {
        this.contactObj.UserServiceTypeId = this.SelectedId;
        this.contactObj.UserServiceType = 'For Ambulance';
        this.service.ContactForAmbulance(this.contactObj).subscribe(data => {
        this.sendBookAmbMessageToPatient();

        });
    }

    sendBookAmbMessageToPatient() {
        this.messagemodel.message = this.MessageStatement;
        this.messagemodel.patName = this.contactObj.UserName;
        this.messagemodel.numbers = this.contactObj.UserNum;
        this.service.MessageToPatient(this.messagemodel).subscribe(data => {
        }, erro => {
        });
      }

      back(){
        window.history.back();
      }

}
