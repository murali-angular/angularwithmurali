import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { MessageModel } from '../../common/message';
import { MailMessage } from '../../common/mailmessage';
import { Contact } from '../../common/contactus';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class ScheduleAmbService {

  posturl = environment.prod_URL + 'Contact/InsertContactEnquiry';
  messageurl = environment.prod_URL + 'Message/SendMessageFreeAmb';
  mailurl = environment.prod_URL + 'MailMessage/RegisterPatientMail';

  constructor(private http: HttpClient) { }


  public MessageToPatient(message: MessageModel): Observable<any> {
    return this.http.post(this.messageurl, message);
  }

  public MailMessageToRegisteredPatient(mail: MailMessage): Observable<any> {
    return this.http.post(this.mailurl, mail);
  }

  public ContactForAmbulance(contactObj: Contact): Observable<any> {
    return this.http.post(this.posturl, contactObj);
  }


}
