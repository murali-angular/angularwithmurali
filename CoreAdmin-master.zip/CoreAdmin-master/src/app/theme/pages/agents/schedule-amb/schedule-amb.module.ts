import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScheduleAmbRoutingModule } from './schedule-amb-routing.module';
import { ScheduleAmbComponent } from './schedule-amb.component';
import { ScheduleAmbService } from './schedule-amb.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { Validation } from '../../../../shared/Validator';

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, ScheduleAmbRoutingModule, HttpModule, ReactiveFormsModule
  ],
  bootstrap: [ScheduleAmbComponent],
  declarations: [ScheduleAmbComponent],
  providers: [ScheduleAmbService, Validation]
})
export class ScheduleAmbModule { }
