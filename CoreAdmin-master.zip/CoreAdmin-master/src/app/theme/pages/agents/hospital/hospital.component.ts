import { Component, OnInit, Input, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
// import { ToastrService } from 'ngx-toastr';
import { HospitalDoctorsService } from '../hospital-doctors/hospital-doctors.service';
import { HospAmbRegService } from '../hosp-amb-reg/hosp-amb-reg.service';
import { HospDetails, HospDoc } from '../../common/hospAmbReg';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { HospitalService } from './hospital.service';
import { NotificationsService } from '../../../../shared/notification/notifications.service';


@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css'],
  providers: [HospitalDetailsService, HospitalDoctorsService, HospAmbRegService, HospitalService]

})
export class HospitalComponent implements OnInit {

  myForm: FormGroup;
  hospobj: HospDetails = new HospDetails();
  hosplistobj: HospDetails[];
  HospId: any;
  // isTakenSubscription: boolean;
  base64Image: any;
  GetHospDetailsDoctorsList: HospDoc[];

  HospTypeList = [{ name: 'General Hospital' }, { name: 'Multi-SpecialityHospital' }];

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private hospservice: HospitalDetailsService,
    private hospdocservice: HospitalDoctorsService,
    private hospambservice: HospAmbRegService,
    public domSanitizer: DomSanitizer,
    private _sanitizer: DomSanitizer,
    private router: Router,
    private notes: NotificationsService
    // public toastr: ToastrService
  ) {

  }

  ngOnInit() {
    if (this.route.snapshot.url[1] !== undefined) {
      this.HospId = this.route.snapshot.url[1].path;
      if (this.HospId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.editHospById(this.HospId);
      }
    }
  }

  editHospById(hospID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospByID(hospID).subscribe(data => {
      this.hospobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.RetieveHospitalDoctorsList();
    }, error => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {
      this.base64Image = myReader.result;
    };
    myReader.readAsDataURL(file);
  }


  RetieveHospitalDoctorsList() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.GetDoctorsListbyHospId(this.HospId).subscribe(data => {
      this.GetHospDetailsDoctorsList = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');

    });
  }

  GetImage(img) {
    return this._sanitizer.bypassSecurityTrustResourceUrl(img);
  }

  bookHospitalDoctor(hospDocId) {
    this.router.navigateByUrl('/bookappointment/edit/' + hospDocId);
  }

  CallAmbulance(AID) {
    this.router.navigateByUrl('/scheduleAmb/edit/' + AID);
  }

}
