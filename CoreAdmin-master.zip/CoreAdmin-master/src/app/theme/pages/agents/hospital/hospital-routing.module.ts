import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HospitalComponent } from './hospital.component';

const routes: Routes = [
  {
    path: '',
    component: HospitalComponent,
    data: {
      title: 'Hospital Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: HospitalComponent,
    data: {
      title: 'Hospital Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/:hospId',
    component: HospitalComponent,
    data: {
      title: 'Edit Hospital',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HospitalRoutingModule { }
