import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { HospitalRoutingModule } from './hospital-routing.module';
import { HospitalComponent } from './hospital.component';
import { HospitalService } from './hospital.service';
import { TabsModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CommonModule, HospitalRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpModule, TabsModule.forRoot()

  ],
  declarations: [HospitalComponent],
  bootstrap: [HospitalComponent],
  providers: [HospitalService, Validation]
})
export class HospitalModule { }
