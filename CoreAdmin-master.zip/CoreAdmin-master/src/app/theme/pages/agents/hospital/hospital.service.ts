import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { HospDetails } from '../../common/hospAmbReg';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class HospitalService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Ambulance/InsertAmbulance';
  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  updateurl = environment.prod_URL + 'Ambulance/updateambulance';
  deleteurl = environment.prod_URL + 'Ambulance/DeleteAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulanceById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Ambulance/GetAmbulanceAmbOwnID/';

  public GetHospitalByHospID(Id): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.geturl + Id);
  }

  public GetHospByID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyid + ID);
  }

  public GetAmbulanceByAmbOwnID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyAmbOwnid + ID)
  }


  public SaveHospital(hospobj: HospDetails): Observable<any> {
    return this.http.post(this.posturl, hospobj);
  }


  public UpdateHosp(hospobj: HospDetails): Observable<any> {
    return this.http.post(this.updateurl, hospobj);
  }

  public DeleteHosp(hospId): Observable<any> {
    return this.http.post(this.deleteurl, hospId);
  }


  // public getAppointmentToDoc(hospDocId): Observable<any> {
  //   const bodyString = JSON.stringify(hospobj);
  //   const headers = new Headers({ 'Content-Type': 'application/json' });
  //   const options = new RequestOptions({ headers: headers });
  //   return this.http.post(this.posturl, bodyString, options)
  //     .map((res: Response) => res.json())
  //     .catch((error: any) => Observable.throw(error.json().error));
  // }

}
