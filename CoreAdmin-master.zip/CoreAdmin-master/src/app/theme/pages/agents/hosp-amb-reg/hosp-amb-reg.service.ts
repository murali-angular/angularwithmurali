import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { HospAmbReg } from '../../common/hospAmbReg';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class HospAmbRegService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Ambulance/InsertAmbulance';
  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  updateurl = environment.prod_URL + 'Ambulance/updateambulance';
  deleteurl = environment.prod_URL + 'Ambulance/DeleteAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulanceById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Ambulance/GetAmbulanceAmbOwnID/';

  public GetAmbulance(body: object): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.geturl, body);
  }

  public GetAmbulanceByID(ID: any): Observable<HospAmbReg> {
    return this.http.get<HospAmbReg>(this.geturlbyid + ID)
  }

  public GetAmbulanceByAmbOwnID(ID: any): Observable<HospAmbReg[]> {
    return this.http.get<HospAmbReg[]>(this.geturlbyAmbOwnid + ID);
  }


  public SaveAmb(ambulance: HospAmbReg): Observable<any> {
    return this.http.post(this.posturl, ambulance);
  }


  public UpdateAmb(ambulance: HospAmbReg): Observable<any> {
    return this.http.post(this.updateurl, ambulance);
  }

  public DeleteAmb(ambulanceID): Observable<any> {
    return this.http.post(this.deleteurl, ambulanceID);
  }

}
