import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HospAmbRegRoutingModule } from './hosp-amb-reg-routing.module';
import { HospAmbRegComponent } from './hosp-amb-reg.component';
import { HospAmbRegService } from './hosp-amb-reg.service';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, HospAmbRegRoutingModule, 
    ReactiveFormsModule, HttpModule
  ],
  declarations: [HospAmbRegComponent],
  bootstrap: [HospAmbRegComponent],
  providers: [HospAmbRegService, Validation]
})
export class HospAmbRegModule { }
