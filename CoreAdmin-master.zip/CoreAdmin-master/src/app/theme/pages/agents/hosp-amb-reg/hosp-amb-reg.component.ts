import { Component, OnInit, RendererFactory2 } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HospAmbRegService } from './hosp-amb-reg.service';
import { HospAmbReg } from '../../common/hospAmbReg';
import { Validation } from '../../../../shared/Validator';
import { DomSanitizer } from '@angular/platform-browser';
import { CompressorServiceService } from '../../../../shared/compressor-service.service';
import { ActivatedRoute } from '@angular/router';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-hosp-amb-reg',
  templateUrl: './hosp-amb-reg.component.html',
  styleUrls: ['./hosp-amb-reg.component.css'],
  providers: [CompressorServiceService]
})
export class HospAmbRegComponent implements OnInit {

  myForm: FormGroup;
  hospambobj: HospAmbReg = new HospAmbReg();
  isTakenSubscription: boolean;
  base64Image: any;
  GetAmbulanceDetails: HospAmbReg[];
  hospId;

  AmbTypeList = [{ name: 'BLS Ambulance' }, { name: 'ALS Ambulance' }, { name: 'Transport Ambulance' },
  { name: 'Ventilator Ambulance' }, { name: 'Air Ambulance' }, { name: 'Oxygen Ambulance' }, { name: 'Body Freezer Ambulance' },
  { name: 'AC Ambulance' }, { name: 'ICU Ambulance' }, { name: 'Cardiac Care Ambulance' }, { name: 'Accident Case Ambulance' },
  { name: 'Critical Care Ambulance' }, { name: 'Train Ambulance' }, { name: 'Diagnostic Ambulance' }, { name: 'Other Ambulance' }];

  constructor(private fb: FormBuilder, private valid: Validation,
    private service: HospAmbRegService, public domSanitizer: DomSanitizer,
    private compressService: CompressorServiceService,
    private rendererFactory: RendererFactory2,
    private route: ActivatedRoute
    // public toastr: ToastrService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      HospAmbName: this.valid.signupform.FirstName,
      HospAmbNumber: this.valid.signupform.MobileNumber,
      HospAmbEmail: this.valid.signupform.Email,
      HospAmbAddress: this.valid.signupform.remarks,
      HospAmbNumberPlate: this.valid.signupform.Required,
      HospAmbType: this.valid.signupform.Required,
      HospAmbDriverName: this.valid.signupform.FirstName,
      HospAmbDriverNumber: this.valid.signupform.MobileNumber,
      HospAmbImgPath: this.valid.signupform.Required
    });
    // if (this.route.snapshot.url[1] !== undefined) {
    //   this.hospId = this.route.snapshot.url[1].path;
    //   if (this.hospId !== undefined && this.route.snapshot.url[0].path === 'edit') {
    //     // this.editHospitalById(this.hospId);
    //   }
    // }
  }

  editAmbById(ambID) {
    this.service.GetAmbulanceByID(ambID).subscribe(data => {
      this.hospambobj = data;
    }, error => {
    });
  }

  getSubscription() {
    if (this.hospambobj.IsSubscribe === 'subscribeYes') {
      this.isTakenSubscription = true;
    } else {
      this.isTakenSubscription = false;
    }
  }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {

      this.compressService.compressFile(this.base64Image, this.rendererFactory.createRenderer(null, null), 50, 50).then(result => {
        this.base64Image = myReader.result;
        // const normalimage_temp: any = result;
        // this.normalimage = normalimage_temp.replace(/^data:image\/(png|jpg|jpeg);base64,/, '');
        // this.captures.push(this.base64Image);
        // this.normalcaptures.push(this.normalimage);
      });
    };
    myReader.readAsDataURL(file);
  }

  public onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        const reader = new FileReader();
        // tslint:disable-next-line:no-shadowed-variable
        reader.onload = (event) => {
          this.base64Image = (<FileReader>event.target).result;
          this.compressService.compressFile(this.base64Image, this.rendererFactory.createRenderer(null, null), 50, 50).then(result => {
            this.base64Image = result;
            // const normalimage_temp: any = result;
            // this.normalimage = normalimage_temp.replace(/^data:image\/(png|jpg|jpeg);base64,/, '');
            // this.captures.push(this.base64Image);
            // this.normalcaptures.push(this.normalimage);
          });
        };
        reader.readAsDataURL(event.target.files[i]);
      }
    }
  }

  createHospAmb() {
    this.hospambobj.HospId = this.hospId;
    // this.ambulance.AmbLocation = this.autocompleteaddress;
    this.hospambobj.HospAmbImgPath = this.base64Image;
    // this.hospambobj.AmbOwnID = localStorage.getItem('loggedUser');
    this.service.SaveAmb(this.hospambobj).subscribe(data => {
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Ambulance Saved Successfully');
      this.RetieveAmbulance();
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
      this.base64Image = '';
    });
  }

  UpdateAmbulance() {
    this.service.UpdateAmb(this.hospambobj).subscribe(data => {
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Updated Successfully');
    }, erro => {

    });
  }

  DeleteAmbulance(AmbID) {
    this.service.DeleteAmb(AmbID).subscribe(data => {
      // this.toastr.success('Deleted Successfully');
      this.ngOnInit();
    }, erro => {
    });
  }

  RetieveAmbulance() {
    this.service.GetAmbulanceByAmbOwnID(localStorage.getItem('loggedUser')).subscribe(data => {
      this.GetAmbulanceDetails = data;
    }, erro => {
    });
  }


}
