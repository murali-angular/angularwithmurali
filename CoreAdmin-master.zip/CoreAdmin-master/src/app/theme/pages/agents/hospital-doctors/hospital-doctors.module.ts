import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HospitalDoctorsRoutingModule } from './hospital-doctors-routing.module';
import { HospitalDoctorsComponent } from './hospital-doctors.component';
import { HospitalDoctorsService } from './hospital-doctors.service';

@NgModule({
  imports: [
    CommonModule, HospitalDoctorsRoutingModule, SharedModule, FormsModule, ReactiveFormsModule

  ],
  declarations: [HospitalDoctorsComponent],
  bootstrap: [HospitalDoctorsComponent],
  providers: [HospitalDoctorsService, Validation],
  schemas : [CUSTOM_ELEMENTS_SCHEMA]
})
export class HospitalDoctorsModule { }
