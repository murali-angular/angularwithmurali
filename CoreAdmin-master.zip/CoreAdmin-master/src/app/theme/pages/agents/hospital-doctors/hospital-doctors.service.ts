import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { HospDoc } from '../../common/hospAmbReg';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HospitalDoctorsService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'HospitalDoctor/InsertHospDoctor';
  geturl = environment.prod_URL + 'HospitalDoctor/GetHospitalDoctorList';
  updateurl = environment.prod_URL + 'HospitalDoctor/updateHospDoctor';
  deleteurl = environment.prod_URL + 'HospitalDoctor/DeleteHospitalDoctor/';
  geturlbyid = environment.prod_URL + 'HospitalDoctor/GetDoctorByHospDocId/';
  geturlbyAmbOwnid = environment.prod_URL + 'HospitalDoctor/GetHospDocRecordsHospID/';

  public GetDoctorsListbyHospId(hospId): Observable<HospDoc[]> {
    return this.http.get<HospDoc[]>(this.geturlbyAmbOwnid + hospId);
  }

  public GetDoctorRecordByID(ID: any): Observable<HospDoc> {
    return this.http.get<HospDoc>(this.geturlbyid + ID);
  }

  public GetDoctorsList(): Observable<HospDoc[]> {
    return this.http.get<HospDoc[]>(this.geturl);
  }

  public SaveDoctor(hospdocObj: HospDoc): Observable<any> {
    return this.http.post(this.posturl, hospdocObj)
  }


  public UpdateDoctor(hospdocObj: HospDoc): Observable<any> {
    return this.http.post(this.updateurl, hospdocObj);
  }

  public DeleteDoctor(hospDocID): Observable<any> {
    return this.http.post(this.deleteurl, hospDocID);
  }


}
