import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HospitalDoctorsComponent } from './hospital-doctors.component';

const routes: Routes = [
  {
    path: '',
    component: HospitalDoctorsComponent,
    data: {
      title: 'Hospital Doctor Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: HospitalDoctorsComponent,
    data: {
      title: 'Hospital Doctor Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/hospID',
    component: HospitalDoctorsComponent,
    data: {
      title: 'Edit Doctor',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HospitalDoctorsRoutingModule { }
