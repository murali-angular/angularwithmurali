import { Component, OnInit, Input, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
// import { ToastrService } from 'ngx-toastr';
import { HospDoc, HospDetails } from '../../common/hospAmbReg';
import { HospitalDetailsService } from '../hospital-details/hospital-details.service';
import { HospitalDoctorsService } from './hospital-doctors.service';
import { HospAmbRegService } from '../hosp-amb-reg/hosp-amb-reg.service';
import { NotificationsService } from '../../../../shared/notification/notifications.service';


@Component({
  selector: 'app-hospital-doctors',
  templateUrl: './hospital-doctors.component.html',
  styleUrls: ['./hospital-doctors.component.css'],
  providers: [HospitalDetailsService, HospitalDoctorsService, HospAmbRegService]
})
export class HospitalDoctorsComponent implements OnInit {

  myForm: FormGroup;
  hospdocobj: HospDoc = new HospDoc();
  hospobj: HospDetails = new HospDetails();
  hospId;
  base64Image;
  GetDoctorDetails: HospDoc[];
  IsSavebtn = false;
  IsUpdatebtn = true;

  DocSpecList = [{ name: 'Addiction psychiatrist' }, { name: 'Hematologist' }, { name: 'Orthopedic surgeon' },
  { name: 'Adolescent medicine specialist' }, { name: 'Hepatologist' }, { name: 'Otolaryngologist' },
  { name: 'Allergist (immunologist)' }, { name: 'Hospitalist' }, { name: 'Pain management specialist' },
  { name: 'Anesthesiologist' }, { name: 'Hospice and palliative medicine specialist' }, { name: 'Pathologist' },
  { name: 'Cardiac electrophysiologist' }, { name: 'Hyperbaric physician' }, { name: 'Pediatrician' },
  { name: 'Cardiologist' }, { name: 'Infectious disease specialist' }, { name: 'Perinatologist' },
  { name: 'Cardiovascular surgeon' }, { name: 'Internist' }, { name: 'Physiatrist' },
  { name: 'Colon and rectal surgeon' }, { name: 'Interventional cardiologist' }, { name: 'Plastic surgeon' },
  { name: 'Critical care medicine specialist' }, { name: 'Medical examiner' }, { name: 'Psychiatrist' },
  { name: 'Dermatologist' }, { name: 'Medical geneticist' }, { name: 'Pulmonologist' },
  { name: 'Developmental pediatrician' }, { name: 'Neonatologist' }, { name: 'Radiation oncologist' },
  { name: 'Emergency medicine specialist' }, { name: 'Nephrologist' }, { name: 'Radiologist' },
  { name: 'Endocrinologist' }, { name: 'Neurological surgeon' }, { name: 'Reproductive endocrinologist' },
  { name: 'Family medicine physician' }, { name: 'Neurologist' }, { name: 'Rheumatologist' },
  { name: 'Forensic pathologist' }, { name: 'Nuclear medicine specialist' }, { name: 'Sleep disorders specialist' },
  { name: 'Gastroenterologist' }, { name: 'Obstetrician' }, { name: 'Spinal cord injury specialist' },
  { name: 'Geriatric medicine specialist' }, { name: 'Occupational medicine specialist' }, { name: 'Sports medicine specialist' },
  { name: 'Gynecologist' }, { name: 'Oncologist' }, { name: 'Surgeon' },
  { name: 'Gynecologic oncologist' }, { name: 'Ophthalmologist' }, { name: 'Thoracic surgeon' },
  { name: 'Hand surgeon' }, { name: 'Oral surgeon' }, { name: 'Urologist' }, { name: 'Vascular surgeon' }
  ];

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation,
    public domSanitizer: DomSanitizer,
    // public toastr: ToastrService,
    private hospservice: HospitalDetailsService,
    private hospdocservice: HospitalDoctorsService,
    private hospambservice: HospAmbRegService,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      HospDocName: this.valid.signupform.FirstName,
      HospDocNum: this.valid.signupform.MobileNumber,
      HospDocMail: this.valid.signupform.Email,
      HospDocAddress: this.valid.signupform.Required,
      HospDocQualification: this.valid.signupform.Required,
      HospDocStartTime: this.valid.signupform.Required,
      HospDocEndTime: this.valid.signupform.Required,
      HospDocSpecialization: this.valid.signupform.Required,
      HospDocDescription: this.valid.signupform.Required,
      HospDocImgPath: this.valid.signupform.Required,
      HospDocConsultingFee: this.valid.signupform.Required
    });
    if (this.route.snapshot.url[1] !== undefined) {
      this.hospId = this.route.snapshot.url[1].path;
      if (this.hospId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.editHospitalById(this.hospId);
      }
    }
  }

  editHospitalById(hospId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospitalByHospID(hospId).subscribe(data => {
      this.hospobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, error => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {
      this.base64Image = myReader.result;
    };
    myReader.readAsDataURL(file);
  }

  SaveDoctor() {
    // this.ambulance.AmbLocation = this.autocompleteaddress;
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocobj.HospId = this.hospId;
    this.hospdocobj.HospDocImgPath = this.base64Image;
    // this.ambulance.AmbOwnID = localStorage.getItem('loggedUser');
    this.hospdocservice.SaveDoctor(this.hospdocobj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Doctor Saved successfully');
      this.hospdocobj = new HospDoc();
      // this.toastr.success('Doctor Saved Successfully');
      // this.RetrieveDoctor();
      // this.RetrieveDoctorsList();
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
      this.base64Image = '';
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Doctor Saved Failed');
      this.hospdocobj = new HospDoc();
    });
  }

  UpdateDoctor() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.UpdateDoctor(this.hospdocobj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Doctor Updated successfully');
      this.hospdocobj = new HospDoc();
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Doctor Updated Successfully');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Doctor Update Failed');
      this.hospdocobj = new HospDoc();
    });
  }

  DeleteDoctor(docId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.DeleteDoctor(docId).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Doctor Deleted successfully');
      this.hospdocobj = new HospDoc();
      this.ngOnInit();
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Doctor Deleted Failed');
      this.hospdocobj = new HospDoc();
    });
  }

  RetrieveDoctorsList() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.GetDoctorsList().subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.GetDoctorDetails = data;
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  RetrieveDoctorByID(DocId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospdocservice.GetDoctorRecordByID(DocId).subscribe(data => {
      this.hospdocobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  EditDoctor(DocId) {
    this.RetrieveDoctorByID(DocId);
    this.IsSavebtn = true;
    this.IsUpdatebtn = false;
  }
}
