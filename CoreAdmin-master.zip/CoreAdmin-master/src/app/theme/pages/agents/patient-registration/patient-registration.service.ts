import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { MessageModel } from '../../common/message';
import { PatientRegistration } from '../../common/patientRegistration';
import { MailMessage } from '../../common/mailmessage';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class PatientRegistrationService {

  posturl = environment.prod_URL + 'Patient/InsertPatientDetails';
  updateurl = environment.prod_URL + 'Patient/UpdatePatientDetailsByID';

  geturlbyid = environment.prod_URL + 'Patient/GetPatientDetailsByID/';
  messageurl = environment.prod_URL + 'Message/SendMessageRegistration';
  mailurl = environment.prod_URL + 'MailMessage/RegisterPatientMail';
  getMenuurl = environment.prod_URL + 'Menu/GetMenusByLoggedUser/';
  geturllist = environment.prod_URL + 'Patient/GetPatientList/';


  constructor(private http: HttpClient) { }

  public GetPatientDetailsByID(ID: any): Observable<any> {
    return this.http.get<any>(this.geturlbyid + ID);
  }

  public GetPatientList(): Observable<PatientRegistration[]> {
    return this.http.get<PatientRegistration[]>(this.geturllist);
  }

  public MessageToPatient(message: MessageModel) {
    return this.http.post(this.messageurl, message);
  }

  public InsertPatientDetails(user: PatientRegistration) {
    return this.http.post(this.posturl, user);
  }

  public MailMessageToRegisteredPatient(mail: MailMessage) {
    return this.http.post(this.mailurl, mail);
  }

  public updatePatient(user: PatientRegistration) {
    return this.http.post(this.updateurl, user);
  }

}
