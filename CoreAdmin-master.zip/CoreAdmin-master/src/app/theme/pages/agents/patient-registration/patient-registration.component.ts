import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PatientRegistrationService } from './patient-registration.service';
import { PatientRegistration } from '../../common/patientRegistration';
import { Validation } from '../../../../shared/Validator';
import { ActivatedRoute } from '@angular/router';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-patient-registration',
  templateUrl: './patient-registration.component.html',
  styleUrls: ['./patient-registration.component.css'],
  providers: [PatientRegistrationService]
})
export class PatientRegistrationComponent implements OnInit {
  myForm: FormGroup;
  patientobj: PatientRegistration = new PatientRegistration();
  public loading = false;
  constructor(private fb: FormBuilder, private valid: Validation,
    private route: ActivatedRoute,
    private service: PatientRegistrationService,
    // private toastr: ToastrService,
    // private spinner: NgxSpinnerService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      PatientName: this.valid.signupform.FirstName,
      PatientNumber: this.valid.signupform.MobileNumber,
      patientMail: this.valid.signupform.Email,
      PatientGender: this.valid.signupform.Gender,
      PatientAddress: this.valid.signupform.remarks,
      PatientCondition: this.valid.signupform.remarks
    });
    this.editPatientById();
  }

  createPatient() {
    // this.spinner.show();
    this.patientobj.SignUpId = localStorage.getItem('loggedUser');
    this.service.InsertPatientDetails(this.patientobj).subscribe(data => {
      // this.toastr.success('Saved Successfully');
    }, erro => {

      // this.spinner.hide();
      // this.toastr.error('Saved Failed');
    });
  }

  editPatientById() {
    this.service.GetPatientDetailsByID(localStorage.getItem('loggedUser')).subscribe(data => {
      this.patientobj.patientMail = data.UserMail;
      this.patientobj.PatientNumber = data.UserMobile;
    }, error => {
    });
  }


}
