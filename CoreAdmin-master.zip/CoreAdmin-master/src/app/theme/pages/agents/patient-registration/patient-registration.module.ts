import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientRegistrationComponent } from './patient-registration.component';
import { PatientRegistrationRoutingModule } from './patient-registration-routing.module';
import { PatientRegistrationService } from './patient-registration.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { Validation } from '../../../../shared/Validator';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    CommonModule, PatientRegistrationRoutingModule, SharedModule, FormsModule,
    HttpClientModule, ReactiveFormsModule
  ],
  declarations: [PatientRegistrationComponent],
  bootstrap: [PatientRegistrationComponent],
  providers: [PatientRegistrationService, Validation]
})
export class PatientRegistrationModule { }
