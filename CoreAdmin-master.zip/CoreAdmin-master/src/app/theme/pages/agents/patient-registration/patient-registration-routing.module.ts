import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientRegistrationComponent } from './patient-registration.component';

const routes: Routes = [
  {
    path: '',
    component: PatientRegistrationComponent,
    data: {
      title: 'Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: PatientRegistrationComponent,
    data: {
      title: 'Create Patient',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/:patientId',
    component: PatientRegistrationComponent,
    data: {
      title: 'Edit Profile',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})


export class PatientRegistrationRoutingModule { }
