import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HospitalDetailsRoutingModule } from './hospital-details-routing.module';
import { HospitalDetailsComponent } from './hospital-details.component';
import { HospitalDetailsService } from './hospital-details.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    HospitalDetailsRoutingModule, SharedModule, HttpClientModule

  ],
  declarations: [HospitalDetailsComponent],
  bootstrap: [HospitalDetailsComponent],
  providers: [HospitalDetailsService, Validation],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HospitalDetailsModule { }
