import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HospitalDetailsComponent } from './hospital-details.component';
import { HospitalDoctorsComponent } from '../hospital-doctors/hospital-doctors.component';
import { HospAmbRegComponent } from '../hosp-amb-reg/hosp-amb-reg.component';

const routes: Routes = [
  {
    path: '',
    component: HospitalDetailsComponent,
    data: {
      title: 'Hospital Details',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    },
    // children: [
    //   {
    //     path: '', component: HospitalDoctorsComponent, data: {
    //       data: {
    //         title: 'Hospital Doctors',
    //         // icon: 'ti-layout-cta-right',
    //         // caption: 'variants color of nav bar',
    //         status: false
    //       }
    //     }
    //   },
    //   {
    //     path: '', component: HospAmbRegComponent, data: {
    //       data: {
    //         title: 'Hospital Ambulance',
    //         // icon: 'ti-layout-cta-right',
    //         // caption: 'variants color of nav bar',
    //         status: false
    //       }
    //     }
    //   }
    // ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HospitalDetailsRoutingModule { }
