import { Component, OnInit, Input, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
// import { ToastrService } from 'ngx-toastr';
import { HospitalDetailsService } from './hospital-details.service';
import { HospitalDoctorsService } from '../hospital-doctors/hospital-doctors.service';
import { HospAmbRegService } from '../hosp-amb-reg/hosp-amb-reg.service';
import { HospDetails } from '../../common/hospAmbReg';
import { NotificationsService } from '../../../../shared/notification/notifications.service';


@Component({
  selector: 'app-hospital-details',
  templateUrl: './hospital-details.component.html',
  styleUrls: ['./hospital-details.component.css'],
  providers: [HospitalDetailsService, HospitalDoctorsService, HospAmbRegService]
})
export class HospitalDetailsComponent implements OnInit {

  myForm: FormGroup;
  hospobj: HospDetails = new HospDetails();
  HospId: any;
  // isTakenSubscription: boolean;
  base64Image: any;
  GetHospDetails: HospDetails;
  GetHospDetailsList: HospDetails[];
  isTakenSubscription: boolean;
  isHospSaved = true;
  HospTypeList = [{ name: 'General Hospital' }, { name: 'Multi-Speciality Hospital' }, { name: 'Super specialty' }, { name: '' }];

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private hospservice: HospitalDetailsService,
    private hospdocservice: HospitalDoctorsService,
    private hospambservice: HospAmbRegService,
    public domSanitizer: DomSanitizer,
    private router: Router,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    this.myForm = this.fb.group({
      HospName: this.valid.signupform.FirstName,
      HospNum: this.valid.signupform.MobileNumber,
      HospMail: this.valid.signupform.Email,
      HospAddress: this.valid.signupform.Required,
      HospType: this.valid.signupform.Required,
      HospImgPath: this.valid.signupform.Required,
      yy: this.valid.signupform.showpass
    });
    // if (this.route.snapshot.url[1] !== undefined) {
    //   this.HospId = this.route.snapshot.url[1].path;
    //   if (this.HospId !== undefined && this.route.snapshot.url[0].path === 'edit') {
    //     this.editHospById(this.HospId);
    //   }
    // }
  }

  editHospById(hospID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospByID(hospID).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.hospobj = data;
    }, error => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  // getSubscription() {
  //   if (this.ambobj.IsSubscribe === 'subscribeYes') {
  //     this.isTakenSubscription = true;
  //   } else {
  //     this.isTakenSubscription = false;
  //   }
  // }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {
      this.base64Image = myReader.result;
    };
    myReader.readAsDataURL(file);
  }

  SaveHospital() {
    // this.ambulance.AmbLocation = this.autocompleteaddress;
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospobj.HospImgPath = this.base64Image;
    this.hospobj.SignUpID = localStorage.getItem('loggedUser');
    this.hospservice.SaveHospital(this.hospobj).subscribe(data => {
      this.notes.success('Hospital successfully saved');
      this.notes.loadingSpinnerByMessage(false, 'Loading');

      this.hospobj = new HospDetails();
      // this.toastr.success('Hospital Saved Successfully');
      this.RetieveHospital();
      this.isHospSaved = false;
    }, erro => {
      // this.ambulance = new AmbulanceDetails();
      this.base64Image = '';
      this.isHospSaved = true;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Hospital saved failed');
      this.hospobj = new HospDetails();
    });
  }

  UpdateHospital() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.UpdateHosp(this.hospobj).subscribe(data => {
      this.notes.success('Hospital Updated saved');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.hospobj = new HospDetails();
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Hospital Update failed');
      this.hospobj = new HospDetails();
    });
  }

  DeleteHosp(hospID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.DeleteHosp(hospID).subscribe(data => {
      this.notes.success('Hospital Deleted successfully');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.hospobj = new HospDetails();
      this.ngOnInit();
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Hospital Deleted failed');
      this.hospobj = new HospDetails();
    });
  }

  RetieveHospital() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospitalByHospID(this.hospobj.HospId).subscribe(data => {
      this.GetHospDetails = data;
      this.isHospSaved = false;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  RetrieveHospitalsList() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.hospservice.GetHospitalsList().subscribe(data => {
      this.GetHospDetailsList = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  addDoctors() {
    this.router.navigateByUrl('/hospitaldoctor/edit/' + this.hospobj.HospId);
  }

  addHospAmb() {
    this.router.navigateByUrl('/hospitalAmbReg/edit/' + this.hospobj.HospId);
  }

  getSubscription() {
    if (this.hospobj.IsSubscribe === 'subscribeYes') {
      this.isTakenSubscription = true;
    } else {
      this.isTakenSubscription = false;
    }
  }

}
