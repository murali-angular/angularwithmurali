import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { HospDetails } from '../../common/hospAmbReg';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class HospitalDetailsService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Hospital/InsertHospital';
  geturl = environment.prod_URL + 'Hospital/GetHospitalList';
  updateurl = environment.prod_URL + 'Hospital/updateHospital';
  deleteurl = environment.prod_URL + 'Hospital/DeleteHospital/';
  geturlbyid = environment.prod_URL + 'Hospital/GethospitalById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Hospital/GetAmbulanceAmbOwnID/';

  public GetHospitalByHospID(Id): Observable<HospDetails> {
    return this.http.get<HospDetails>(this.geturl +  Id);
  }

  public GetHospByID(ID: any): Observable<HospDetails> {
    return this.http.get<HospDetails>(this.geturlbyid + ID);
  }

  public GetAmbulanceByAmbOwnID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyAmbOwnid + ID);
  }

  public GetHospitalsList(): Observable<HospDetails[]> {
    return this.http.get<HospDetails[]>(this.geturl);
  }

  public SaveHospital(hospobj: HospDetails): Observable<any> {
    return this.http.post(this.posturl, hospobj);
  }


  public UpdateHosp(hospobj: HospDetails): Observable<any> {
    return this.http.post(this.updateurl, hospobj);
  }

  public DeleteHosp(hospId): Observable<any> {
    return this.http.post(this.deleteurl, hospId);
  }

}
