import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgentBookAmbComponent } from './agent-book-amb.component';

const routes: Routes = [
  {
    path: '',
    component: AgentBookAmbComponent,
    data: {
      title: 'Agent Book Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentBookAmbRoutingModule { }
