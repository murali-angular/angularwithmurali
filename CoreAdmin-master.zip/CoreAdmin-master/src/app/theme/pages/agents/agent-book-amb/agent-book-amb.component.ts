import { Component, OnInit } from '@angular/core';
import { BookAmbulance } from '../../common/bookAmb';
import { ActivatedRoute } from '@angular/router';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AgentBookAmbService } from './agent-book-amb.service';
import { PatientRegistration } from '../../common/patientRegistration';
// import { ToastyService } from 'ng2-toasty';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-agent-book-amb',
  templateUrl: './agent-book-amb.component.html',
  styleUrls: ['./agent-book-amb.component.css'],
  providers: [AgentBookAmbService, Validation, 
    // ToastrService
  ]
})
export class AgentBookAmbComponent implements OnInit {

  mynewForm: FormGroup;
  bookambobj: BookAmbulance = new BookAmbulance();
  ambobj: AmbRegistration = new AmbRegistration();
  ambId: any;
  agentpatientList: PatientRegistration[];

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private service: AgentBookAmbService,
    // private toastr: ToastrService
  ) {

  }

  ngOnInit() {
    this.mynewForm = this.fb.group({
      PatientName: this.valid.signupform.FirstName,
      PatientNumber: this.valid.signupform.MobileNumber,
      SelectedDate: this.valid.signupform.Required,
      SelectedTime: this.valid.signupform.Required,
      PatientAddress: this.valid.signupform.Required
    });
    if (this.route.snapshot.url[1] !== undefined) {
      this.ambId = this.route.snapshot.url[1].path;
      if (this.ambId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.editAmbById(this.ambId);
      }
    }
    this.getPatientList();
  }

  createBookAmbbyAgent() {
    this.service.BookAmbulance(this.bookambobj).subscribe(data => {
      // this.toastr.success('Ambulance Booked Successfully');
    });
  }

  editAmbById(ambID) {
    this.service.GetAmbulanceByID(ambID).subscribe(data => {
      this.ambobj = data;
      // this.toastr.success('Ambulance {{this.ambobj.AmbName}} Retrieved Successfully');
    }, error => {
    });
  }

  getPatientList() {
    this.service.GetPatientsList().subscribe(data => {
      this.agentpatientList = data;
      // this.toastr.success('Patients Retrieved Successfully');
    }, error => {
      // this.toastr.warning('Patients Retrieved Failed');
    });
  }

  getPatientRecord(patName : string){
    this.service.GetPatientRecord(patName).subscribe(data=>{
      this.bookambobj = data;
    }, error => {
      // this.toastr.warning('Patients Retrieved Failed');
    });
  }

  callAmb(){
    //// Deepija Telecom
  }

}
