import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';
import { AgentBookAmbRoutingModule } from './agent-book-amb-routing.module';
import { AgentBookAmbComponent } from './agent-book-amb.component';
import { AgentBookAmbService } from './agent-book-amb.service';
import { Validation } from '../../../../shared/Validator';

@NgModule({
  imports: [
    CommonModule, FormsModule, AgentBookAmbRoutingModule, SharedModule, ReactiveFormsModule
  ],
  declarations: [AgentBookAmbComponent],
  bootstrap: [AgentBookAmbComponent],
  providers: [AgentBookAmbService, Validation]
})
export class AgentBookAmbModule { }
