import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmbulanceRegistrationRoutingModule } from './ambulance-registration-routing.module';
import { AmbulanceRegistrationComponent } from './ambulance-registration.component';
import { AmbulanceRegistrationService } from './ambulance-registration.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Validation } from '../../../../shared/Validator';
import { SharedModule } from '../../../../shared/shared.module';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [
    CommonModule, AmbulanceRegistrationRoutingModule, SharedModule, FormsModule, ReactiveFormsModule, HttpModule

  ],
  declarations: [AmbulanceRegistrationComponent],
  bootstrap: [AmbulanceRegistrationComponent],
  providers: [AmbulanceRegistrationService, Validation],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AmbulanceRegistrationModule { }
