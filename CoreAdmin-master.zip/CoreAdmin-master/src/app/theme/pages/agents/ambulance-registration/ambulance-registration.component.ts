import { Component, OnInit, Input, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AmbulanceRegistrationService } from './ambulance-registration.service';
import { Validation } from '../../../../shared/Validator';
import { AmbRegistration } from '../../common/ambRegistration';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from '../../../../shared/notification/notifications.service';
// import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-ambulance-registration',
  templateUrl: './ambulance-registration.component.html',
  styleUrls: ['./ambulance-registration.component.css'],
  providers: [AmbulanceRegistrationService]
})
export class AmbulanceRegistrationComponent implements OnInit {

  myForm: FormGroup;
  ambobj: AmbRegistration = new AmbRegistration();
  ambId: any;
  isTakenSubscription: boolean;
  base64Image: any;
  GetAmbulanceDetails: AmbRegistration[];
  IsSavebtn = false;
  IsUpdatebtn = true;

  AmbTypeList = [{ name: 'BLS Ambulance' }, { name: 'ALS Ambulance' }, { name: 'Transport Ambulance' },
  { name: 'Ventilator Ambulance' }, { name: 'Air Ambulance' }, { name: 'Oxygen Ambulance' }, { name: 'Body Freezer Ambulance' },
  { name: 'AC Ambulance' }, { name: 'ICU Ambulance' }, { name: 'Cardiac Care Ambulance' }, { name: 'Accident Case Ambulance' },
  { name: 'Critical Care Ambulance' }, { name: 'Train Ambulance' }, { name: 'Diagnostic Ambulance' }, { name: 'Other Ambulance' }];

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private valid: Validation, private service: AmbulanceRegistrationService,
    public domSanitizer: DomSanitizer,
    private notes: NotificationsService
  ) {

  }

  ngOnInit() {
    this.IsSavebtn = false;
    this.IsUpdatebtn = true;
    this.myForm = this.fb.group({
      AmbName: this.valid.signupform.FirstName,
      AmbNumber: this.valid.signupform.MobileNumber,
      AmbMail: this.valid.signupform.Email,
      AmbAddress: this.valid.signupform.remarks,
      AmbNumberPlate: this.valid.signupform.Required,
      AmbType: this.valid.signupform.Required,
      DriverName: this.valid.signupform.FirstName,
      DriverNum: this.valid.signupform.MobileNumber,
      AmbImgPath: this.valid.signupform.Required,
    });
    if (this.route.snapshot.url[1] !== undefined) {
      this.ambId = this.route.snapshot.url[1].path;
      if (this.ambId !== undefined && this.route.snapshot.url[0].path === 'edit') {
        this.editAmbById(this.ambId);
      }
    }
    if (this.route.snapshot.url[1] !== undefined) {
      if (this.route.snapshot.url[0].path === 'create') {
      }
    }
  }

  // createAmb() {
  //   this.service.SaveAmbulance(this.ambobj).subscribe(data => {
  //     this.ambobj = new AmbRegistration();
  //   }, erro => {
  //   });
  // }

  // EditAmb() {
  //   this.updateAmb.emit();
  // }

  editAmbById(ambID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetAmbulanceByID(ambID).subscribe(data => {
      this.ambobj = data;
      this.notes.success('Retrieved successfully');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, error => {
    });
  }

  getSubscription() {
    if (this.ambobj.IsSubscribe === 'subscribeYes') {
      this.isTakenSubscription = true;
    } else {
      this.isTakenSubscription = false;
    }
  }

  changeListener($event): void {
    this.readThis($event.target);
  }

  readThis(inputValue: any): void {
    const file: File = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e: any) => {
      this.base64Image = myReader.result;
    };
    myReader.readAsDataURL(file);
  }

  SaveAmbulance() {
    // this.ambulance.AmbLocation = this.autocompleteaddress;
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.ambobj.AmbImgPath = this.base64Image;
    this.ambobj.SignUpID = localStorage.getItem('loggedUser');
    // this.ambobj.AgentId = localStorage.getItem('loggedUser');
    this.service.SaveAmb(this.ambobj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Ambulance Saved successfully');
      // this.ambulance = new AmbulanceDetails();
      // this.toastr.success('Ambulance Saved Successfully');
      // this.RetieveAmbulance();
    }, erro => {
      this.ambobj = new AmbRegistration();
      this.base64Image = '';
      this.notes.success('Retrieved successfully');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  UpdateAmbulance() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.UpdateAmb(this.ambobj).subscribe(data => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Ambulance Updated successfully');
      this.ambobj = new AmbRegistration();
      // this.toastr.success('Updated Successfully');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Ambulance Updated Falied');
    });
  }

  DeleteAmbulance(AmbID) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.DeleteAmb(AmbID).subscribe(data => {
      // this.toastr.success('Deleted Successfully');
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.success('Ambulance Deleted successfully');
      this.ngOnInit();
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
      this.notes.error('Ambulance Deleted Falied');
    });
  }

  RetieveAmbulance() {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetAmbulanceByAmbOwnID(localStorage.getItem('loggedUser')).subscribe(data => {
      this.GetAmbulanceDetails = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  RetieveAmbulanceById(ambId) {
    this.notes.loadingSpinnerByMessage(true, 'Loading');
    this.service.GetAmbulanceByID(ambId).subscribe(data => {
      this.ambobj = data;
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    }, erro => {
      this.notes.loadingSpinnerByMessage(false, 'Loading');
    });
  }

  EditAmbulance(ambId) {
    this.RetieveAmbulanceById(ambId);
    this.IsSavebtn = true;
    this.IsUpdatebtn = false;
  }

  ambType(event) {
    this.ambobj.AmbType =  event.target.value;

  }

}
