import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';
import { environment } from '../../../../../environments/environment.prod';
import { AmbRegistration } from '../../common/ambRegistration';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HospAmbReg } from '../../common/hospAmbReg';

@Injectable()
export class AmbulanceRegistrationService {

  constructor(private http: HttpClient) { }
  posturl = environment.prod_URL + 'Ambulance/InsertAmbulance';
  geturl = environment.prod_URL + 'Ambulance/GetAmbulance';
  updateurl = environment.prod_URL + 'Ambulance/updateambulance';
  deleteurl = environment.prod_URL + 'Ambulance/DeleteAmbulance';
  geturlbyid = environment.prod_URL + 'Ambulance/GetAmbulanceById/';
  geturlbyAmbOwnid = environment.prod_URL + 'Ambulance/GetAmbulanceAmbOwnID/';

  public GetAmbulance(): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.geturl);
  }

  public GetAmbulanceByID(ID: any): Observable<AmbRegistration> {
    return this.http.get<AmbRegistration>(this.geturlbyid + ID);
  }

  public GetAmbulanceByAmbOwnID(ID: any): Observable<AmbRegistration[]> {
    return this.http.get<AmbRegistration[]>(this.geturlbyAmbOwnid + ID);
  }

  public SaveAmb(ambulance: AmbRegistration): Observable<any> {
    return this.http.post(this.posturl, ambulance);
  }


  public UpdateAmb(ambulance: AmbRegistration): Observable<any> {
    return this.http.post(this.updateurl, ambulance);
  }

  public DeleteAmb(ambulanceID): Observable<any> {
    return this.http.post(this.deleteurl, ambulanceID);
  }

}
