import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AmbulanceRegistrationComponent } from './ambulance-registration.component';

const routes: Routes = [
  {
    path: '',
    component: AmbulanceRegistrationComponent,
    data: {
      title: 'Ambulance Registration',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'create',
    component: AmbulanceRegistrationComponent,
    data: {
      title: 'Create Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  },
  {
    path: 'edit/ambID',
    component: AmbulanceRegistrationComponent,
    data: {
      title: 'Edit Ambulance',
      // icon: 'ti-layout-cta-right',
      // caption: 'variants color of nav bar',
      status: false
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AmbulanceRegistrationRoutingModule { }
