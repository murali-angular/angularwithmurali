export class AddlabTest {
    LabId: string;
    LabTestName: string;
    LabTestDesc: string;
    ActualPrice: string;
    AddDate: Date;
    EditDate: Date;
}
