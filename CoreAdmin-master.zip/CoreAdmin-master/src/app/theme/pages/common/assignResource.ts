export class AssignResource {
    PartnerId: string;
    ResourceId: string;
    AssignedDate: Date;
    DropedDate: Date;
    IsAssigned = false;
    AddDate: Date;
    EditDate: Date;
}
