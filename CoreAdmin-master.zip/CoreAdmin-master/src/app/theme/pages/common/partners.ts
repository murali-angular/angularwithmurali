export class Partners {
    PartnerId: string;
    PartnerName: string;
    PartnerNum: string;
    PartnerAltNum: string;
    PartnerMailId: string;
    PartnerAddress: string;
    CatogeryType: string;
    PartnerStatus = true;
    AddDate: Date;
    EditDate: Date;
}
