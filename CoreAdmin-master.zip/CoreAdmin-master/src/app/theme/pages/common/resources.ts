export class Resources {
    ResourceId: string;
    ResourceName: string;
    ResourceNum: string;
    ResourceAltNum: string;
    ResourceMailId: string;
    ResourceAddress: string;
    ResourceType: string;
    IsActive: boolean;
    IsEngagedtoWrk: boolean;
    DaysWorkedPerMonth: string;
    AddDate: Date;
    EditDate: Date;
}
