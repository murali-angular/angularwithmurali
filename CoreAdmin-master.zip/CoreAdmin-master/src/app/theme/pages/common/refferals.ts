export class AddRefferals {
    ReferralId: string;
    ReferralName: string;
    ReferralNum: string;
    ReferralAltNum: string;
    ReferralMailId: string;
    ReferralAddress: string;
    ReferralStatus = true;
    ReferralPercentage: string;
    AddDate: Date;
    EditDate: Date;
}

