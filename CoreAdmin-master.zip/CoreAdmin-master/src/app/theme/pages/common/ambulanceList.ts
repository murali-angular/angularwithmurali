export class AmbList {
    AmbSource: string;
    AmbName: string;
    AmbNumber: number;
    AmbMail: string;
    AmbAddress: string;
    AmbNumberPlate: string;
    AmbType: string;
    DriverName: string;
    DriverNum: string;
    Priority: number;
    TodaysContactStatus: any;
}
