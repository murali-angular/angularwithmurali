export class MessageModel {
    UserKey: string;
    Passkey: string;
    message: string;
    messageClient: string;
    numbers: string;
    time: string;
    date: string;
    Type: string;
    VehicleName: string;
    AmbNumber: string;
    DriverNme: string;
    DriverNum: string;
    patName: string;
    patNum: string;
    patientAddress: string;
    numberplate: string;
    ClientName: string;
    AddedDate: Date;
    EditedDate: Date;

    DoctorNme : string;
    HospAddress : string;
    HospNumber : string;
}
