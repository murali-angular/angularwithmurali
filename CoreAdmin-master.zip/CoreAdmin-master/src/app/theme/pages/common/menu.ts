export class MenuItems {
    MenuId: any;
    SignUpId: any;
    MenuName: string;
    MenuLink: string;
    MenuIcon: any;
}