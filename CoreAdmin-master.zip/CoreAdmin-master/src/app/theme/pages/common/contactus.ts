export class Contact {
    ContactId: any;
    UserName: string;
    UserMail: string;
    UserNum: string;
    UserServiceTypeId: any;
    UserServiceType: string;
    UserMessage: string;
    Location: string;
}
