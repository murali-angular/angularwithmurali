import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Login } from '../theme/pages/common/login';
import { MenuItems } from '../theme/pages/common/menu';
import { Validation } from '../shared/Validator';
import { LoginService } from '../theme/pages/default/login/login.service';
import { NotificationsService } from '../shared/notification/notifications.service';

// facebook auth
import { AuthService, FacebookLoginProvider, SocialUser } from 'angularx-social-login';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    myForm: FormGroup;
    newlogin: Login = new Login();
    MenuListObj: MenuItems[] = [];

    user: SocialUser;
    loggedIn: boolean;

    constructor(private fb: FormBuilder, private valid: Validation, private service: LoginService,
        private notes: NotificationsService,
        private router: Router,
        private authService: AuthService) {
    }

    ngOnInit() {
        this.myForm = this.fb.group({
            UserName: this.valid.signupform.Required,
            Password: this.valid.signupform.Required
        });
        this.MenuListObj = [];
        this.MenusAssignedByUserType();
        // facebook auth
        this.authService.authState.subscribe((user) => {
            this.user = user;
            this.loggedIn = (user != null);
            console.log(this.user);
          });
    }

    AuthenticateLogin(loginmodal) {
        this.notes.loadingSpinnerByMessage(true, 'Loading');
        if (loginmodal) {
            this.service.credentialslogin(loginmodal).subscribe(data => {
                this.notes.loadingSpinnerByMessage(false, 'Loading');
                // this.notes.success('Login successfully');
                // this.newlogin = new Login();
                if (data.Status === 'PASS') {
                    localStorage.setItem('loggedUser', data.SignUpID);
                    localStorage.setItem('loggedUserTypeId', data.UserTypeId);
                    this.MenusAssignedByUserType();
                    if (localStorage.getItem('loggedUserTypeId') === '0') {
                        this.router.navigate(['/home']);
                    }
                    if (localStorage.getItem('loggedUserTypeId') === '1' || localStorage.getItem('loggedUserTypeId') === '3') {
                        this.router.navigate(['/hospitaldetails']);
                    }
                    if (localStorage.getItem('loggedUserTypeId') === '2' || localStorage.getItem('loggedUserTypeId') === '3') {
                        this.router.navigate(['/ambualnceRegistration']);
                    }
                    if (localStorage.getItem('loggedUserTypeId') === null || localStorage.getItem('loggedUserTypeId') === undefined) {
                        this.router.navigate(['/login']);
                    }
                    // this.refresh();
                    // this.router.navigate(['/home']);
                }
            }, erro => {
                this.newlogin = new Login();
                this.notes.error('Login Failed');
                this.notes.loadingSpinnerByMessage(false, 'Loading');
                this.MenuListObj = [];
            });
        }
    }

    refresh(): void {
        window.location.reload();
    }

    MenusAssignedByUserType() {
        this.MenuListObj = [];
        this.notes.loadingSpinnerByMessage(true, 'Loading');
        this.service.GetUserMenusByUserTypeId(localStorage.getItem('loggedUserTypeId')).subscribe(data => {
            this.notes.loadingSpinnerByMessage(false, 'Loading');
            this.MenuListObj = data;
        }, erro => {
            this.notes.loadingSpinnerByMessage(false, 'Loading');
            this.MenuListObj = [];
        });
    }

    signInWithFB(): void {
        this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
      }
      
      signOut(): void {
        this.authService.signOut();
      }

      forgotpwd(){
          
      }

}
