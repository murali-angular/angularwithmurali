import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: '',
                redirectTo: 'dashboard'
            },
            {
                path: 'dashboard',
                loadChildren: './dashboard/dashboard.module#DashboardModule'
            },
            {
                path: 'patientRegistration',
                loadChildren: '../theme/pages/agents/patient-registration/patient-registration.module#PatientRegistrationModule'
            },
            {
                path: 'ambualnceRegistration',
                loadChildren: '../theme/pages/agents/ambulance-registration/ambulance-registration.module#AmbulanceRegistrationModule'
            },
            {
                path: 'bookAmbulance',
                loadChildren: '../theme/pages/home/book-amb/book-amb.module#BookAmbModule'
            },
            {
                path: 'agentsAmbulanceList',
                loadChildren: '../theme/pages/agents/agents-amb-list/agents-amb-list.module#AgentsAmbListModule'
            },
            {
                path: 'agentsHospitalList',
                loadChildren: '../theme/pages/agents/agent-hosp-list/agent-hosp-list.module#AgentHospListModule'
            },
            {
                path: 'agentsBookAmbulance',
                loadChildren: '../theme/pages/agents/agent-book-amb/agent-book-amb.module#AgentBookAmbModule'
            },
            {
                path: 'searchAmb',
                loadChildren: '../theme/pages/home/amb-search/amb-search.module#AmbSearchModule'
            },
            {
                path: 'scheduleAmb',
                loadChildren: '../theme/pages/agents/schedule-amb/schedule-amb.module#ScheduleAmbModule'
            },
            {
                path: 'hospitalAmbReg',
                loadChildren: '../theme/pages/agents/hosp-amb-reg/hosp-amb-reg.module#HospAmbRegModule'
            },
            {
                path: 'customsearch',
                loadChildren: '../theme/pages/default/custom-search-amb/custom-search-amb.module#CustomSearchAmbModule'
            },
            {
                path: 'changepassword',
                loadChildren: '../theme/pages/patients/change-pwd/change-pwd.module#ChangePwdModule'
            },
            {
                path: 'mybookings',
                loadChildren: '../theme/pages/patients/patient-bookings/patient-bookings.module#PatientBookingsModule'
            },
            {
                path: 'myprofile',
                loadChildren: '../theme/pages/patients/patient-profile/patient-profile.module#PatientProfileModule'
            },
            {
                path: 'hospitaldetails',
                loadChildren: '../theme/pages/agents/hospital-details/hospital-details.module#HospitalDetailsModule'
            },
            {
                path: 'hospitaldoctor',
                loadChildren: '../theme/pages/agents/hospital-doctors/hospital-doctors.module#HospitalDoctorsModule'
            },
            {
                path: 'hospital',
                loadChildren: '../theme/pages/agents/hospital/hospital.module#HospitalModule'
            },
            {
                path: 'bookappointment',
                loadChildren: '../theme/pages/agents/book-hosp-doc/book-hosp-doc.module#BookHospDocModule'
            },
            {
                path: 'agentRegistration',
                loadChildren: '../theme/pages/admin/agent-registration/agent-registration.module#AgentRegistrationModule'
            },
            {
                path: 'bookfreeamb',
                loadChildren: '../theme/pages/agents/book-hosp-amb/book-hosp-amb.module#BookHospAmbModule'
            },
            {
                path: 'home',
                loadChildren: '../theme/pages/home/home/home.module#HomeModule'
            },
            {
                path: 'aboutus',
                data: { title: 'About Us', status: false },
                loadChildren: '../theme/default-pages/about-us/about-us.module#AboutUsModule'
            },
            {
                path: 'contactus',
                data: { title: 'Contact Us', status: false },
                loadChildren: '../theme/default-pages/contact-us/contact-us.module#ContactUsModule'
            },
            {
                path: 'error',
                data: { title: '404 Error', status: false },
                loadChildren: '../theme/default-pages/error-message/error-message.module#ErrorMessageModule'
            },
            {
                path: 'thankyou',
                data: { title: 'Thank You', status: false },
                loadChildren: '../theme/default-pages/thank-you-page/thank-you-page.module#ThankYouPageModule'
            },
            {
                path: 'forgotpassword',
                data: { title: 'Forgot Password' },
                loadChildren: '../theme/pages/default/forgot-pwd/forgot-pwd.module#ForgotPwdModule'
            },
            {
                path: 'payment',
                loadChildren: '../theme/pages/payment-page/payment-page.module#PaymentPageModule'
            },
            {
                path: 'hosplist',
                loadChildren: '../theme/pages/agents/hosp-list/hosp-list.module#HospListModule'
            },
            {
                path: 'amblist',
                loadChildren: '../theme/pages/agents/amb-list/amb-list.module#AmbListModule'
            },
            {
                path: 'addLabtest',
                loadChildren: '../theme/pages/agents/add-lab-test/add-lab-test.module#AddLabTestModule'
            },
            {
                path: 'configlab',
                loadChildren: '../theme/pages/agents/config-lab-test/config-lab-test.module#ConfigLabTestModule'
            },
            {
                path: 'viewlabreports',
                loadChildren: '../theme/pages/agents/view-lab-reports/view-lab-reports.module#ViewLabReportsModule'
            },
            {
                path: 'addrefferal',
                loadChildren: '../theme/pages/refferals/add-referal/add-referal.module#AddReferalModule'
            },
            {
                path: 'addpartner',
                loadChildren: '../theme/pages/staffing/add-partners/add-partners.module#AddPartnersModule'
            },
            {
                path: 'addresource',
                loadChildren: '../theme/pages/staffing/add-resource/add-resource.module#AddResourceModule'
            },
            {
                path: 'assignresource',
                loadChildren: '../theme/pages/staffing/assign-resource/assign-resource.module#AssignResourceModule'
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LayoutRoutingModule { }
