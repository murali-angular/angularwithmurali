export const environment = {
  production: true,
  prod_URL: 'http://localhost:64010/'
};
