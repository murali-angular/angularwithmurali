﻿using CoreWebApiApp.Models;
using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    [RoutePrefix("BookHospDoc")]
    public class BookHospDocController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertBookHospDoc")]
        public string InsertBookHospDoc(BookHospDoc BookHospDoc)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterBookHospDoctor";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospDocId", BookHospDoc.HospDocId);
                sqlcmd.Parameters.AddWithValue("@PatientID", BookHospDoc.PatientID);
                sqlcmd.Parameters.AddWithValue("@SelectedDate", BookHospDoc.SelectedDate);
                sqlcmd.Parameters.AddWithValue("@SelectedTime", BookHospDoc.SelectedTime);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditedDate", DateTime.Now);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";

            }
        }

        [HttpGet]
        [Route("GetBookHospDocList")]
        public List<BookHospDoc> GetBookHospDocList()
        {
            List<BookHospDoc> ambulanceLst = new List<BookHospDoc>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterBookHospDoctor";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    BookHospDoc ambulance = new BookHospDoc()
                    {
                        HospDocId = Convert.ToInt32(reader["HospDocId"]),
                        PatientID = Convert.ToInt32(reader["PatientID"]),
                        SelectedDate = reader["SelectedDate"].ToString(),
                        SelectedTime = reader["SelectedTime"].ToString(),
                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GetBookHospDocByHospId/{HospId}")]
        public BookHospDoc GetBookHospDocByHospId(int HospId)
        {
            BookHospDoc ambulance = new BookHospDoc();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterBookHospDoctor";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", HospId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectByID");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new BookHospDoc()
                    {
                        HospDocId = Convert.ToInt32(reader["HospDocId"]),
                        PatientID = Convert.ToInt32(reader["PatientID"]),
                        SelectedDate = reader["SelectedDate"].ToString(),
                        SelectedTime = reader["SelectedTime"].ToString(),
                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")



                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };
                }
            }
            return ambulance;
        }
    }
}
