﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CoreWebApiApp.Models.Entities;
using System.Data.SqlClient;
using System.Data;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("Ambulance")]
    public class AmbualnceController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertAmbulance")]
        public string InsertAmbulance(AmbReg ambulanceViewModel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpID", ambulanceViewModel.SignUpID);
                sqlcmd.Parameters.AddWithValue("@AgentId", ambulanceViewModel.AgentId);

                sqlcmd.Parameters.AddWithValue("@AmbName", ambulanceViewModel.AmbName);
                sqlcmd.Parameters.AddWithValue("@AmbNumber", ambulanceViewModel.AmbNumber);
                sqlcmd.Parameters.AddWithValue("@AmbAltNumber", ambulanceViewModel.AmbAltNumber);
                sqlcmd.Parameters.AddWithValue("@AmbMail", ambulanceViewModel.AmbMail);
                sqlcmd.Parameters.AddWithValue("@AmbAddress", ambulanceViewModel.AmbAddress);
                sqlcmd.Parameters.AddWithValue("@AmbNumberPlate", ambulanceViewModel.AmbNumberPlate);
                sqlcmd.Parameters.AddWithValue("@DriverName", ambulanceViewModel.DriverName);
                sqlcmd.Parameters.AddWithValue("@DriverNum", ambulanceViewModel.DriverNum);

                sqlcmd.Parameters.AddWithValue("@IsSubscribe", ambulanceViewModel.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", ambulanceViewModel.SubscriptionPlan);
                sqlcmd.Parameters.AddWithValue("@AmbImgPath", ambulanceViewModel.AmbImgPath);
                sqlcmd.Parameters.AddWithValue("@AmbDescription", ambulanceViewModel.AmbDescription);

                //DateTime date1 = Convert.ToDateTime(DateTime.Now);
                //DateTime date2 = Convert.ToDateTime(DateTime.Now);

                //sqlcmd.Parameters.AddWithValue("@AddedDate", date1);
                //sqlcmd.Parameters.AddWithValue("@EditDate", date2);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("updateambulance")]
        public string updateambulance(AmbReg ambulanceViewModel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpID", ambulanceViewModel.SignUpID);
                sqlcmd.Parameters.AddWithValue("@AgentId", ambulanceViewModel.AgentId);

                sqlcmd.Parameters.AddWithValue("@AmbName", ambulanceViewModel.AmbName);
                sqlcmd.Parameters.AddWithValue("@AmbNumber", ambulanceViewModel.AmbNumber);
                sqlcmd.Parameters.AddWithValue("@AmbAltNumber", ambulanceViewModel.AmbAltNumber);
                sqlcmd.Parameters.AddWithValue("@AmbMail", ambulanceViewModel.AmbMail);
                sqlcmd.Parameters.AddWithValue("@AmbAddress", ambulanceViewModel.AmbAddress);
                sqlcmd.Parameters.AddWithValue("@AmbNumberPlate", ambulanceViewModel.AmbNumberPlate);
                sqlcmd.Parameters.AddWithValue("@DriverName", ambulanceViewModel.DriverName);
                sqlcmd.Parameters.AddWithValue("@DriverNum", ambulanceViewModel.DriverNum);

                sqlcmd.Parameters.AddWithValue("@IsSubscribe", ambulanceViewModel.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", ambulanceViewModel.SubscriptionPlan);
                sqlcmd.Parameters.AddWithValue("@AmbImgPath", ambulanceViewModel.AmbImgPath);
                sqlcmd.Parameters.AddWithValue("@AmbDescription", ambulanceViewModel.AmbDescription);

                //DateTime date1 = Convert.ToDateTime(DateTime.Now);
                //DateTime date2 = Convert.ToDateTime(DateTime.Now);

                //sqlcmd.Parameters.AddWithValue("@AddedDate", date1);
                //sqlcmd.Parameters.AddWithValue("@EditDate", date2);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.ExecuteNonQuery();
                return "Updated: " + ambulanceViewModel.AmbName;
            }
        }

        [HttpPost]
        [Route("DeleteAmbulance/{AmbID}")]
        public string DeleteAmbulance(int AmbID)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AmbID", AmbID);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Delete");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                return "Deleted";
            }
        }

        [HttpGet]
        [Route("GetAmbulance")]
        public List<AmbReg> GetAmbulance()
        {
            List<AmbReg> ambulanceLst = new List<AmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AmbReg ambulance = new AmbReg()
                    {
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AmbName = reader["AmbName"].ToString(),
                        AmbNumber = reader["AmbNumber"].ToString(),
                        AmbAltNumber = reader["AmbAltNumber"].ToString(),

                        AmbMail = reader["AmbMail"].ToString(),
                        AmbAddress = reader["AmbAddress"].ToString(),
                        AmbNumberPlate = reader["AmbNumberPlate"].ToString(),
                        AmbType = reader["AmbType"].ToString(),
                        DriverName = reader["DriverName"].ToString(),

                        DriverNum = reader["DriverNum"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        AmbImgPath = reader["AmbImgPath"].ToString(),
                        AmbDescription = reader["AmbDescription"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GetAmbulanceAutoPopulate")]
        public List<AmbReg> GetAmbulanceAutoPopulate()
        {
            List<AmbReg> ambulanceLst = new List<AmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AmbReg ambulance = new AmbReg()
                    {
                        AmbName = reader["AmbName"].ToString(),
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GetAmbulanceAmbOwnID/{ambOwnId}")]
        public List<AmbReg> GetAmbulanceAmbOwnID(string ambOwnId)
        {
            List<AmbReg> ambulanceLst = new List<AmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AmbOwnID", ambOwnId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AmbReg ambulance = new AmbReg()
                    {
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AmbName = reader["AmbName"].ToString(),
                        AmbNumber = reader["AmbNumber"].ToString(),
                        AmbAltNumber = reader["AmbAltNumber"].ToString(),

                        AmbMail = reader["AmbMail"].ToString(),
                        AmbAddress = reader["AmbAddress"].ToString(),
                        AmbNumberPlate = reader["AmbNumberPlate"].ToString(),
                        AmbType = reader["AmbType"].ToString(),
                        DriverName = reader["DriverName"].ToString(),


                        DriverNum = reader["DriverNum"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        AmbImgPath = reader["AmbImgPath"].ToString(),
                        AmbDescription = reader["AmbDescription"].ToString()



                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }


        [HttpGet]
        [Route("GetAmbulanceSearch/{ambloc}/{ambName}")]
        public List<AmbReg> GetAmbulanceSearch(string ambloc, string ambName)
        {
            List<AmbReg> ambulanceLst = new List<AmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spGetAmbulanceSearchbyLocandNameDetails";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AreaName", ambloc);
                sqlcmd.Parameters.AddWithValue("@AmbulanceName", ambName);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AmbReg ambulance = new AmbReg()
                    {
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AmbName = reader["AmbName"].ToString(),
                        AmbNumber = reader["AmbNumber"].ToString(),
                        AmbAltNumber = reader["AmbAltNumber"].ToString(),

                        AmbMail = reader["AmbMail"].ToString(),
                        AmbAddress = reader["AmbAddress"].ToString(),
                        AmbNumberPlate = reader["AmbNumberPlate"].ToString(),
                        AmbType = reader["AmbType"].ToString(),
                        DriverName = reader["DriverName"].ToString(),


                        DriverNum = reader["DriverNum"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        AmbImgPath = reader["AmbImgPath"].ToString(),
                        AmbDescription = reader["AmbDescription"].ToString()



                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GetAmbulanceById/{ambId}")]
        public AmbReg GetAmbulanceById(int ambId)
        {
            AmbReg ambulance = new AmbReg();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AmbID", ambId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new AmbReg()
                    {
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AmbName = reader["AmbName"].ToString(),
                        AmbNumber = reader["AmbNumber"].ToString(),
                        AmbAltNumber = reader["AmbAltNumber"].ToString(),

                        AmbMail = reader["AmbMail"].ToString(),
                        AmbAddress = reader["AmbAddress"].ToString(),
                        AmbNumberPlate = reader["AmbNumberPlate"].ToString(),
                        AmbType = reader["AmbType"].ToString(),
                        DriverName = reader["DriverName"].ToString(),


                        DriverNum = reader["DriverNum"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        AmbImgPath = reader["AmbImgPath"].ToString(),
                        AmbDescription = reader["AmbDescription"].ToString()



                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };
                }
            }
            return ambulance;
        }
    }
}
