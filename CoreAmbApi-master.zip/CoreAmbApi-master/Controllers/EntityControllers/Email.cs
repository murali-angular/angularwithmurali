﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace Ambufree.Library
{
    public class Email
    {
        public string SendMail(string toList,string fromdisplayname, string subject, string body)
        {

            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("mail.ambufree.com");
                mail.From = new MailAddress("info@ambufree.com");
                mail.To.Add(toList);
                mail.Subject = subject;
                mail.IsBodyHtml = true;
                mail.Body = body;
                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential("info@ambufree.com", "%Muvp790");
                SmtpServer.EnableSsl = false;
                SmtpServer.Send(mail);
                return "Mail Send Successfully";
            }
            catch (Exception ex)
            {
                return  ex +"Mail Send Failed";
            }
        }
    }
}
