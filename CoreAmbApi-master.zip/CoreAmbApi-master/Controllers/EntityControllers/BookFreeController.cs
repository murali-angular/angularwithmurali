﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("BookFreeAmbulance")]
    public class BookFreeController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertBookFreeAmbulance")]
        public string InsertBookFreeAmbulance(BookFreeAmb bookAmb)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spInsertBookPaidAmbDetails";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospAmbId", bookAmb.HospAmbId);
                sqlcmd.Parameters.AddWithValue("@PatientID", bookAmb.PatientID);
                sqlcmd.Parameters.AddWithValue("@SelectedDate", bookAmb.SelectedDate);
                sqlcmd.Parameters.AddWithValue("@SelectedTime", bookAmb.SelectedTime);
                sqlcmd.Parameters.AddWithValue("@AddDate", DateTime.Now);
                sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                int status = sqlcmd.ExecuteNonQuery();

                return status > 0 ? "Saved" : "Failed";
            }
        }

        [HttpGet]
        [Route("GetBookHospAmbulanceByHospID/{HospId}")]
        public List<BookFreeAmb> GetBookAmbulanceDetailsByAmbOwnerID(int HospId)
        {
            List<BookFreeAmb> ambBookingLst = new List<BookFreeAmb>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spGetBookHospAmbByHospId";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", HospId);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    BookFreeAmb ambulance = new BookFreeAmb()
                    {
                        BookHospAmbId = Convert.ToInt32(reader["BookHospAmbId"]),
                        HospId = Convert.ToInt32(reader["HospId"]),
                        PatientID = Convert.ToInt32(reader["PatientID"]),
                        HospAmbId = Convert.ToInt32(reader["HospAmbId"]),
                        SelectedDate = Convert.ToDateTime(reader["SelectedDate"]),
                        SelectedTime = Convert.ToDateTime(reader["SelectedTime"]),
                        AddedDate = Convert.ToDateTime(reader["AddedDate"]),
                        EditDate = Convert.ToDateTime(reader["EditDate"]),
                    };
                    ambBookingLst.Add(ambulance);
                }
            }
            return ambBookingLst;
        }
    }
}
