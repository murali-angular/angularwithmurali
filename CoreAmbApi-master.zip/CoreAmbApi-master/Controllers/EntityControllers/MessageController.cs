﻿using CoreWebApiApp.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    public class newsms
    {
        public string message { get; set; }
        public string numbers { get; set; }
        public string messageClient { get; set; }

        /// <summary>
        /// /////////////////Registration
        /// </summary>
        public string patName { get; set; }
        public string UserKey { get; set; }
        public string Passkey { get; set; }

        ///////////////////////Amb
        public string Type { get; set; }
        public DateTime date { get; set; }
        public DateTime time { get; set; }
        public string VehicleName { get; set; }
        public string AmbNumber { get; set; }
        public string DriverNme { get; set; }
        public string DriverNum { get; set; }
        public string patientAddress { get; set; }
        public string numberplate { get; set; }

        public string patNum { get; set; }

        ///// doc app
        public string DoctorNme { get; set; }
        public string HospAddress { get; set; }
        public string HospNumber { get; set; }

    }

    [RoutePrefix("Message")]
    public class MessageController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("SendMessageRegistration")]
        public void SendMessageRegistration(newsms sms)
        {

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.numbers;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");

            String message = HttpUtility.UrlEncode(sms.message);
            message = message.Replace("UserKey", sms.UserKey);
            message = message.Replace("Passkey", sms.Passkey);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", "4");

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }


        }

        [HttpPost]
        [Route("SendMessageBookAmbPatient")]
        public void SendMessageBookAmbPatient(newsms sms)
        {

            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.numbers;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");

            String message = HttpUtility.UrlEncode(sms.message);
            message = message.Replace("Type", sms.Type);
            message = message.Replace("date", OnlyDate);
            message = message.Replace("time", OnlyTime);
            message = message.Replace("VehicleName", sms.VehicleName);
            message = message.Replace("AmbNumber", sms.AmbNumber);
            message = message.Replace("DriverNme", sms.DriverNme);
            message = message.Replace("DriverNum", sms.DriverNum);
            message = message.Replace("numberplate", sms.numberplate);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {

                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }

        [HttpPost]
        [Route("SendMessageBookAmbOwner")]
        public void SendMessageBookAmbOwner(newsms sms)
        {

            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.AmbNumber;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");
            String message = HttpUtility.UrlEncode(sms.messageClient);
            message = message.Replace("Type", sms.Type);
            message = message.Replace("date", OnlyDate);
            message = message.Replace("time", OnlyTime);
            message = message.Replace("patName", sms.patName);
            message = message.Replace("patNum", sms.patNum);
            message = message.Replace("patientAddress", sms.patientAddress);
            message = message.Replace("VehicleName", sms.VehicleName);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }


        [HttpPost]
        [Route("SendMessageBookDetailsToSuperAdmin")]
        public void SendMessageBookDetailsToSuperAdmin(newsms sms)
        {

            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.AmbNumber;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");
            String message = HttpUtility.UrlEncode(sms.messageClient);
            //message = message.Replace("Type", sms.Type);
            message = message.Replace("date", OnlyDate);
            message = message.Replace("time", OnlyTime);
            message = message.Replace("patName", sms.patName);
            message = message.Replace("patNum", sms.patNum);
            message = message.Replace("patNum", sms.patNum);
            message = message.Replace("VehicleName", sms.VehicleName);
            message = message.Replace("AmbNumber", sms.AmbNumber);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }

        [HttpPost]
        [Route("ForGotPwdMessage")]
        public void ForGotPwdMessage(newsms sms)
        {

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.numbers;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");

            String message = HttpUtility.UrlEncode(sms.message);
            message = message.Replace("UserKey", sms.UserKey);
            message = message.Replace("Passkey", sms.Passkey);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", "4");

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }


        }


        [HttpPost]
        [Route("SendMessageDocApp")]
        public void SendMessageDocApp(newsms sms)
        {

            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.numbers;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");

            String message = HttpUtility.UrlEncode(sms.message);
            message = message.Replace("DoctorNme", sms.DoctorNme);
            message = message.Replace("date", OnlyDate);
            message = message.Replace("time", OnlyTime);
            message = message.Replace("HospAddress", sms.HospAddress);
            message = message.Replace("HospNumber", sms.HospNumber);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }


        [HttpPost]
        [Route("SendMessageToHospAboutDocApp")]
        public void SendMessageToDocAnother(newsms sms)
        {

            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");

            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.HospNumber;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.

            String message = HttpUtility.UrlEncode(sms.messageClient);
            message = message.Replace("DoctorNme", sms.DoctorNme);
            message = message.Replace("patName", sms.patName);
            message = message.Replace("patNum", sms.patNum);
            message = message.Replace("date", OnlyDate);
            message = message.Replace("time", OnlyTime);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }


        [HttpPost]
        [Route("SendMessageFreeAmb")]
        public void SendMessageFreeAmb(newsms sms)
        {
            DateTime newActivity = Convert.ToDateTime(sms.time);
            DateTime newDate = Convert.ToDateTime(sms.date);
            TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
            string newDates = Convert.ToString(newDate.Add(Newtime));

            DateTime dtValue = Convert.ToDateTime(newDates);
            string OnlyDate = dtValue.ToString("dd-MM-yyyy");
            string OnlyTime = dtValue.ToString("hh:mm tt");


            string authKey = "176712Avq203zhF1oe59cb89c9";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = sms.numbers;
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "AMBFRE";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Test message");

            String message = HttpUtility.UrlEncode(sms.message);
            message = message.Replace("patName", sms.patName);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", 4);

            try
            {


                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

        }
        



        //[HttpPost]
        //[Route("SendMessageDocApp/{Tid:int}")]
        //public void SendMessageDocApp(newsms sms, int Tid)
        //{
        //    DateTime newActivity = Convert.ToDateTime(sms.time);
        //    DateTime newDate = Convert.ToDateTime(sms.date);
        //    TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
        //    string newDates = Convert.ToString(newDate.Add(Newtime));

        //    DateTime dtValue = Convert.ToDateTime(newDates);
        //    string OnlyDate = dtValue.ToString("dd-MM-yyyy");
        //    string OnlyTime = dtValue.ToString("hh:mm tt");

        //    string authKey = "176712Avq203zhF1oe59cb89c9";
        //    //Multiple mobiles numbers separated by comma
        //    string mobileNumber = sms.numbers;
        //    //Sender ID,While using route4 sender id should be 6 characters long.
        //    string senderId = "AMBFRE";
        //    //Your message to send, Add URL encoding here.
        //    //string message = HttpUtility.UrlEncode("Test message");

        //    String message = HttpUtility.UrlEncode(sms.message);
        //    message = message.Replace("DoctorNme", DoctorNme);
        //    message = message.Replace("date", OnlyDate);
        //    message = message.Replace("time", OnlyTime);
        //    message = message.Replace("HospAddress", HospAddress);
        //    message = message.Replace("HospNumber", HospNumber);
        //    message = message.Replace("percent", percentage);
        //    message = message.Replace("BillType", BillType);

        //    //Prepare you post parameters
        //    StringBuilder sbPostData = new StringBuilder();
        //    sbPostData.AppendFormat("authkey={0}", authKey);
        //    sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
        //    sbPostData.AppendFormat("&message={0}", message);
        //    sbPostData.AppendFormat("&sender={0}", senderId);
        //    sbPostData.AppendFormat("&route={0}", 4);

        //    try
        //    {


        //        //Call Send SMS API
        //        string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
        //        //Create HTTPWebrequest
        //        HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
        //        //Prepare and Add URL Encoded data
        //        UTF8Encoding encoding = new UTF8Encoding();
        //        byte[] data = encoding.GetBytes(sbPostData.ToString());
        //        //Specify post method
        //        httpWReq.Method = "POST";
        //        httpWReq.ContentType = "application/x-www-form-urlencoded";
        //        httpWReq.ContentLength = data.Length;
        //        using (Stream stream = httpWReq.GetRequestStream())
        //        {
        //            stream.Write(data, 0, data.Length);
        //        }
        //        //Get the response
        //        HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
        //        StreamReader reader = new StreamReader(response.GetResponseStream());
        //        string responseString = reader.ReadToEnd();

        //        //Close the response
        //        reader.Close();
        //        response.Close();
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //}


        //[HttpPost]
        //[Route("SendMessageToDocAnother/{Tid:int}")]
        //public void SendMessageToDocAnother(newsms sms, int Tid)
        //{
        //    DBConnect Dbcontext = new DBConnect();
        //    var DoctorNme = Dbcontext.HospitalDoctors.Where(x => x.id == Tid).Select(x => x.hosp_doc_name).FirstOrDefault();
        //    var DoctorFrom = Dbcontext.HospitalDoctors.Where(x => x.id == Tid).Select(x => x.hosp_id).FirstOrDefault();
        //    var HospAddress = Dbcontext.Hospital.Where(x => x.id == DoctorFrom).Select(x => x.hosp_street).FirstOrDefault();
        //    var HospNumber = Dbcontext.Hospital.Where(x => x.id == DoctorFrom).Select(x => x.hosp_ph_num).FirstOrDefault();
        //    var percent = Dbcontext.Hospital.Where(x => x.id == DoctorFrom).Select(x => x.hosp_dis_rate).FirstOrDefault();
        //    var percentage = Convert.ToString(percent);
        //    var BillType = Dbcontext.Hospital.Where(x => x.id == DoctorFrom).Select(x => x.hosp_dis_type).FirstOrDefault();

        //    DateTime newActivity = Convert.ToDateTime(sms.time);
        //    DateTime newDate = Convert.ToDateTime(sms.date);
        //    TimeSpan Newtime = new TimeSpan(newActivity.Hour, newActivity.Minute, 0);
        //    string newDates = Convert.ToString(newDate.Add(Newtime));

        //    DateTime dtValue = Convert.ToDateTime(newDates);
        //    string OnlyDate = dtValue.ToString("dd-MM-yyyy");
        //    string OnlyTime = dtValue.ToString("hh:mm tt");

        //    string authKey = "176712Avq203zhF1oe59cb89c9";
        //    //Multiple mobiles numbers separated by comma
        //    string mobileNumber = HospNumber;
        //    //Sender ID,While using route4 sender id should be 6 characters long.
        //    string senderId = "AMBFRE";
        //    //Your message to send, Add URL encoding here.

        //    String message = HttpUtility.UrlEncode(sms.messageTenant);
        //    message = message.Replace("DoctorNme", DoctorNme);
        //    message = message.Replace("patName", sms.patName);
        //    message = message.Replace("patNum", sms.patNum);
        //    message = message.Replace("date", OnlyDate);
        //    message = message.Replace("time", OnlyTime);
        //    message = message.Replace("percent", percentage);
        //    message = message.Replace("BillType", BillType);

        //    //Prepare you post parameters
        //    StringBuilder sbPostData = new StringBuilder();
        //    sbPostData.AppendFormat("authkey={0}", authKey);
        //    sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
        //    sbPostData.AppendFormat("&message={0}", message);
        //    sbPostData.AppendFormat("&sender={0}", senderId);
        //    sbPostData.AppendFormat("&route={0}", 4);

        //    try
        //    {


        //        //Call Send SMS API
        //        string sendSMSUri = "https://control.msg91.com/api/sendhttp.php";
        //        //Create HTTPWebrequest
        //        HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
        //        //Prepare and Add URL Encoded data
        //        UTF8Encoding encoding = new UTF8Encoding();
        //        byte[] data = encoding.GetBytes(sbPostData.ToString());
        //        //Specify post method
        //        httpWReq.Method = "POST";
        //        httpWReq.ContentType = "application/x-www-form-urlencoded";
        //        httpWReq.ContentLength = data.Length;
        //        using (Stream stream = httpWReq.GetRequestStream())
        //        {
        //            stream.Write(data, 0, data.Length);
        //        }
        //        //Get the response
        //        HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
        //        StreamReader reader = new StreamReader(response.GetResponseStream());
        //        string responseString = reader.ReadToEnd();

        //        //Close the response
        //        reader.Close();
        //        response.Close();
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //}

    }
}