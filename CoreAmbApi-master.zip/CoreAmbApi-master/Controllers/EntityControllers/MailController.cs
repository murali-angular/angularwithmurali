﻿using Ambufree.Library;
using System;
using System.IO;
using System.Web;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    public class MailMessageViewModel
    {
        public string ID { get; set; }
        public string ClientID { get; set; }
        public string UserName { get; set; }
        public string UserNum { get; set; }
        public string UserEmail { get; set; }
        public string UserAddress { get; set; }
        public string AmbID { get; set; }
        public DateTime SelectedDate { get; set; }
        public DateTime SelectedTime { get; set; }
        public string Password { get; set; }
        public string AmbName { get; set; }
        public string AmbNum { get; set; }
        public string AmbNumberPlate { get; set; }
        public string DriverName { get; set; }
        public string DriverNum { get; set; }


    }
    [RoutePrefix("MailMessage")]
    public class MailController : ApiController
    {
        [HttpPost]
        [Route("BookAmbPatientMail")]
        public void BookAmbPatientMail(MailMessageViewModel mail)
        {
            string vSubject = "Welcome to Ambufree";
            string vBody = File.ReadAllText(HttpContext.Current.Server.MapPath("~") + "/Templates/Email/Book_Amb_User_Email.html");
            vBody = vBody.Replace("!uid", mail.UserName.ToString());
            vBody = vBody.Replace("!date", mail.SelectedDate.ToString());
            vBody = vBody.Replace("!time", mail.SelectedTime.ToString());

            vBody = vBody.Replace("!driverName", mail.DriverName.ToString());
            vBody = vBody.Replace("!driverNum", mail.DriverNum.ToString());
            vBody = vBody.Replace("!numPlate", mail.AmbNumberPlate.ToString());

            vBody = vBody.Replace("!ambname", mail.AmbName.ToString());
            vBody = vBody.Replace("!ambphonenumber", mail.AmbNum.ToString());


            Email vEmail = new Email();
            var emailsent = vEmail.SendMail(mail.UserEmail, "Ambufree", vSubject, vBody);

        }

        [HttpPost]
        [Route("BookAmbOwnerMail")]
        public void BookAmbOwnerMail(MailMessageViewModel mail)
        {
            string vSubject = "Welcome to Ambufree";
            string vBody = File.ReadAllText(HttpContext.Current.Server.MapPath("~") + "/Templates/Email/Book_Amb_Client_Email.html");
            vBody = vBody.Replace("!uid", mail.AmbName.ToString());
            vBody = vBody.Replace("!date", mail.SelectedDate.ToString());
            vBody = vBody.Replace("!time", mail.SelectedTime.ToString());

            vBody = vBody.Replace("!patName", mail.UserName.ToString());
            vBody = vBody.Replace("!patNum", mail.UserNum.ToString());
            vBody = vBody.Replace("!patientAddress", mail.UserAddress.ToString());

            vBody = vBody.Replace("!ambName", mail.AmbName.ToString());


            Email vEmail = new Email();
            var emailsent = vEmail.SendMail(mail.UserEmail, "Ambufree", vSubject, vBody);
        }

        [HttpPost]
        [Route("RegisterPatientMail")]
        public void RegisterUserMail(MailMessageViewModel mail)
        {
            string vSubject = "Welcome to Ambufree";
            string vBody = File.ReadAllText(HttpContext.Current.Server.MapPath("~") + "/Templates/Email/user_registration_email.html");
            vBody = vBody.Replace("!uid", mail.UserName.ToString());
            vBody = vBody.Replace("!pwd", mail.Password.ToString());

            Email vEmail = new Email();
            var emailsent = vEmail.SendMail(mail.UserEmail, "Ambufree", vSubject, vBody);
        }

        [HttpPost]
        [Route("SendRegisterAmbOwnerMail")]
        public void RegisterAmbOwnerMail(MailMessageViewModel mail)
        {
            string vSubject = "Welcome to Ambufree";
            string vBody = File.ReadAllText(HttpContext.Current.Server.MapPath("~") + "/Templates/Email/client_registration_email.html");
            vBody = vBody.Replace("!uid", mail.AmbName.ToString());
            vBody = vBody.Replace("!pwd", mail.Password.ToString());

            Email vEmail = new Email();
            var emailsent = vEmail.SendMail(mail.UserEmail, "Ambufree", vSubject, vBody);
        }

        [HttpPost]
        [Route("ForgotPasswordMail")]
        public void ForgotPasswordMail(MailMessageViewModel mail)
        {
            string vSubject = "Welcome to Ambufree";
            string vBody = File.ReadAllText(HttpContext.Current.Server.MapPath("~") + "/Templates/Email/forgot_password_email.html");
            vBody = vBody.Replace("!uid", mail.AmbName.ToString());
            vBody = vBody.Replace("!pwd", mail.Password.ToString());

            Email vEmail = new Email();
            var emailsent = vEmail.SendMail(mail.UserEmail, "Ambufree", vSubject, vBody);
        }

    }
}
