﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("SignUp")]

    public class SignUpController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertUser")]
        public string InsertUser(SignUp signupobj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterSignupInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@UserMail", signupobj.UserMail);
                sqlcmd.Parameters.AddWithValue("@UserTypeID", signupobj.UserTypeID);

                sqlcmd.Parameters.AddWithValue("@UserMobile", signupobj.UserMobile);
                sqlcmd.Parameters.AddWithValue("@UserPwd", signupobj.UserPwd);


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }


        [HttpPost]
        [Route("UpadteUser")]
        public string UpadteUser(SignUp signupobj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spChngPwd";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                // sqlcmd.Parameters.AddWithValue("@UserMail", signupobj.UserMail);
                //sqlcmd.Parameters.AddWithValue("@UserTypeID", signupobj.UserTypeID);

                //sqlcmd.Parameters.AddWithValue("@UserMobile", signupobj.UserMobile);
                sqlcmd.Parameters.AddWithValue("@SignUpId", signupobj.SignUpId);
                sqlcmd.Parameters.AddWithValue("@UserPwd", signupobj.UserPwd);


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                //sqlcmd.Parameters.AddWithValue("@StatementType", "Update");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }


        [HttpGet]
        [Route("GetUserById/{SignUpID}")]
        public SignUp GetAgentById(int SignUpID)
        {
            SignUp ambulance = new SignUp();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterSignupInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpID", SignUpID);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new SignUp()
                    {
                        SignUpId = Convert.ToInt32(reader["SignUpId"]),
                        UserMail = reader["UserMail"].ToString(),
                        UserMobile = reader["UserMobile"].ToString(),
                        //UserPwd = reader["UserPwd"].ToString(),
                        UserTypeID = Convert.ToInt32(reader["UserTypeID"]),
                        //AddedDate = Convert.ToDateTime(reader["AddedDate"]),
                        //EditDate = Convert.ToDateTime(reader["EditDate"])
                    };
                }
            }
            return ambulance;
        }
    }
}
