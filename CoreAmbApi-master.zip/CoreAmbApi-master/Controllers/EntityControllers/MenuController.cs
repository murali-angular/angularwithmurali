﻿using CoreWebApiApp.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    public class MenuModelView
    {
        public int MenuId { get; set; }
        public int SignUpId { get; set; }
        public string MenuName { get; set; }
        public string MenuLink { get; set; }
        public string MenuIcon { get; set; }
        public string component { get; set; }
    }

    [RoutePrefix("Menu")]
    public class MenuController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion


        [HttpPost]
        [Route("InsertMenu")]
        public string InsertMenu(MenuModelView menu)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterMenuDetails";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@MenuId", menu.MenuId);
                sqlcmd.Parameters.AddWithValue("@MenuName", menu.MenuName);
                sqlcmd.Parameters.AddWithValue("@MenuLink", menu.MenuLink);
                sqlcmd.Parameters.AddWithValue("@MenuIcon", menu.MenuIcon);
                sqlcmd.Parameters.AddWithValue("@SignUpId", menu.SignUpId);
                sqlcmd.Parameters.AddWithValue("@component", menu.component);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");
            
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpGet]
        [Route("GetMenusByLoggedUser/{SignUpId}")]
        public List<MenuModelView> GetMenusByLoggedUser(int SignUpId)
        {
            List<MenuModelView> MenuList = new List<MenuModelView>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterMenu";
  
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpId", SignUpId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    MenuModelView ambulance = new MenuModelView()
                    {
                        MenuId = Convert.ToInt32(reader["MenuId"]),
                        MenuName = reader["MenuName"].ToString(),
                        MenuLink = reader["MenuLink"].ToString(),
                        MenuIcon = reader["MenuIcon"].ToString(),
                        SignUpId = Convert.ToInt32(reader["SignUpId"]),
                        component = reader["component"].ToString()
                    };

                    MenuList.Add(ambulance);
                }
            }
            return MenuList;
        }

        [HttpGet]
        [Route("GetMenusList")]
        public List<MenuModelView> GetMenusList()
        {
            List<MenuModelView> MenuList = new List<MenuModelView>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterMenuList";
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");

                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    MenuModelView ambulance = new MenuModelView()
                    {
                        MenuId = Convert.ToInt32(reader["MenuId"]),
                        MenuName = reader["MenuName"].ToString(),
                        MenuLink = reader["MenuLink"].ToString(),
                        MenuIcon = reader["MenuIcon"].ToString(),
                        SignUpId = Convert.ToInt32(reader["SignUpId"]),
                        component = reader["component"].ToString()

                    };

                    MenuList.Add(ambulance);
                }
            }
            return MenuList;
        }
    }
}