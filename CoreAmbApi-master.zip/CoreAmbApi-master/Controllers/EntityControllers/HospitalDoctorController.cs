﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("HospitalDoctor")]
    public class HospitalDoctorController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertHospDoctor")]
        public string InsertHospDoctor(HospDocReg hospDocObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", hospDocObj.HospId);
                sqlcmd.Parameters.AddWithValue("@HospDocName", hospDocObj.HospDocName);
                sqlcmd.Parameters.AddWithValue("@HospDocMail", hospDocObj.HospDocMail);
                sqlcmd.Parameters.AddWithValue("@HospDocNum", hospDocObj.HospDocNum);
                sqlcmd.Parameters.AddWithValue("@HospDocAltNum", hospDocObj.HospDocAltNum);

                sqlcmd.Parameters.AddWithValue("@HospDocQualification", hospDocObj.HospDocQualification);
                sqlcmd.Parameters.AddWithValue("@HospDocStartTime", hospDocObj.HospDocStartTime);
                sqlcmd.Parameters.AddWithValue("@HospDocEndTime", hospDocObj.HospDocEndTime);

                sqlcmd.Parameters.AddWithValue("@HospDocSpecialization", hospDocObj.HospDocSpecialization);
                sqlcmd.Parameters.AddWithValue("@HospDocDescription", hospDocObj.HospDocDescription);

                sqlcmd.Parameters.AddWithValue("@HospDocImgPath", hospDocObj.HospDocImgPath);
                sqlcmd.Parameters.AddWithValue("@HospDocConsultingFee", hospDocObj.HospDocConsultingFee);
                sqlcmd.Parameters.AddWithValue("@HospDocAddress", hospDocObj.HospDocAddress);


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("updateHospDoctor")]
        public string updateHospDoctor(HospDocReg hospDocObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", hospDocObj.HospId);
                sqlcmd.Parameters.AddWithValue("@HospDocName", hospDocObj.HospDocName);
                sqlcmd.Parameters.AddWithValue("@HospDocMail", hospDocObj.HospDocMail);
                sqlcmd.Parameters.AddWithValue("@HospDocNum", hospDocObj.HospDocNum);
                sqlcmd.Parameters.AddWithValue("@HospDocAltNum", hospDocObj.HospDocAltNum);

                sqlcmd.Parameters.AddWithValue("@HospDocQualification", hospDocObj.HospDocQualification);
                sqlcmd.Parameters.AddWithValue("@HospDocStartTime", hospDocObj.HospDocStartTime);
                sqlcmd.Parameters.AddWithValue("@HospDocEndTime", hospDocObj.HospDocEndTime);

                sqlcmd.Parameters.AddWithValue("@HospDocSpecialization", hospDocObj.HospDocSpecialization);
                sqlcmd.Parameters.AddWithValue("@HospDocDescription", hospDocObj.HospDocDescription);

                sqlcmd.Parameters.AddWithValue("@HospDocImgPath", hospDocObj.HospDocImgPath);
                sqlcmd.Parameters.AddWithValue("@HospDocConsultingFee", hospDocObj.HospDocConsultingFee);
                sqlcmd.Parameters.AddWithValue("@HospDocAddress", hospDocObj.HospDocAddress);


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.ExecuteNonQuery();
                return "Updated: " + hospDocObj.HospDocName;
            }
        }

        [HttpPost]
        [Route("DeleteHospitalDoctor/{HospDocId}")]
        public string DeleteAmbulance(int HospDocId)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospDocId", HospDocId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Delete");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                return "Deleted";
            }
        }

        [HttpGet]
        [Route("GetHospitalDoctorList")]
        public List<HospDocReg> GetHospitalList()
        {
            List<HospDocReg> ambulanceLst = new List<HospDocReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospDocReg ambulance = new HospDocReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospDocId = Convert.ToInt32(reader["HospDocId"]),

                        HospDocName = reader["HospDocName"].ToString(),
                        HospDocMail = reader["HospDocMail"].ToString(),
                        HospDocNum = reader["HospDocNum"].ToString(),
                        HospDocAltNum = reader["HospDocAltNum"].ToString(),
                        HospDocQualification = reader["HospDocQualification"].ToString(),
                        HospDocStartTime = reader["HospDocStartTime"].ToString(),
                        HospDocEndTime = reader["HospDocEndTime"].ToString(),
                        HospDocSpecialization = reader["HospDocSpecialization"].ToString(),
                        HospDocDescription = reader["HospDocDescription"].ToString(),
                        HospDocImgPath = reader["HospDocImgPath"].ToString(),
                        HospDocConsultingFee = reader["HospDocConsultingFee"].ToString(),
                        HospDocAddress = reader["HospDocAddress"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GetDoctorByHospDocId/{HospDocId}")]
        public HospDocReg GetDoctorByHospDocId(int HospDocId)
        {
            HospDocReg ambulance = new HospDocReg();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospDocId", HospDocId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new HospDocReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospDocId = Convert.ToInt32(reader["HospDocId"]),

                        HospDocName = reader["HospDocName"].ToString(),
                        HospDocMail = reader["HospDocMail"].ToString(),
                        HospDocNum = reader["HospDocNum"].ToString(),
                        HospDocAltNum = reader["HospDocAltNum"].ToString(),
                        HospDocQualification = reader["HospDocQualification"].ToString(),
                        HospDocStartTime = reader["HospDocStartTime"].ToString(),
                        HospDocEndTime = reader["HospDocEndTime"].ToString(),
                        HospDocSpecialization = reader["HospDocSpecialization"].ToString(),
                        HospDocDescription = reader["HospDocDescription"].ToString(),
                        HospDocImgPath = reader["HospDocImgPath"].ToString(),
                        HospDocConsultingFee = reader["HospDocConsultingFee"].ToString(),
                        HospDocAddress = reader["HospDocAddress"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };
                }
            }
            return ambulance;
        }


        [HttpGet]
        [Route("GetHospDocRecordsHospID/{HospId}")]
        public List<HospDocReg> GetHospDocRecordsHospID(int HospId)
        {
            List<HospDocReg> ambulanceLst = new List<HospDocReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospDocInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", HospId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectDocByHospOnly");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospDocReg ambulance = new HospDocReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospDocId = Convert.ToInt32(reader["HospDocId"]),

                        HospDocName = reader["HospDocName"].ToString(),
                        HospDocMail = reader["HospDocMail"].ToString(),
                        HospDocNum = reader["HospDocNum"].ToString(),
                        HospDocAltNum = reader["HospDocAltNum"].ToString(),
                        HospDocQualification = reader["HospDocQualification"].ToString(),
                        HospDocStartTime = reader["HospDocStartTime"].ToString(),
                        HospDocEndTime = reader["HospDocEndTime"].ToString(),
                        HospDocSpecialization = reader["HospDocSpecialization"].ToString(),
                        HospDocDescription = reader["HospDocDescription"].ToString(),
                        HospDocImgPath = reader["HospDocImgPath"].ToString(),
                        HospDocConsultingFee = reader["HospDocConsultingFee"].ToString(),
                        HospDocAddress = reader["HospDocAddress"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }
    }
}
