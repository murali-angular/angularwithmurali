﻿using CoreWebApiApp.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Http;
using System.Drawing;

namespace CoreWebApiApp.Controllers.EntityControllers
{

    public class ForgotPwdViewModel
    {
        public string Number { get; set; }
        public string Password { get; set; }
    }


    [RoutePrefix("Default")]

    public class DefaultController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion


        //public void SendEmail(ForgotPwdViewModel forgotpwd)
        //{
        //    string username = string.Empty;
        //    string password = string.Empty;
        //    using (SqlConnection con = new SqlConnection(conStr))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("SELECT Username, [Password] FROM Users WHERE Email = @Email or PhoneNumber = @Email"))
        //        {
        //            cmd.Parameters.AddWithValue("@Email", forgotpwd.Email.Trim());
        //            cmd.Connection = con;
        //            con.Open();
        //            using (SqlDataReader sdr = cmd.ExecuteReader())
        //            {
        //                if (sdr.Read())
        //                {
        //                    username = sdr["Username"].ToString();
        //                    password = sdr["Password"].ToString();
        //                }
        //            }
        //            con.Close();
        //        }
        //    }
        //    if (!string.IsNullOrEmpty(password))
        //    {
        //        MailMessage mm = new MailMessage("kasanihealthexpress@gmail.com", forgotpwd.Email.Trim());
        //        mm.Subject = "Password Recovery";
        //        mm.Body = string.Format("Hi {0},<br /><br />Your password is {1}.<br /><br />Thank You.", username, password);
        //        mm.IsBodyHtml = true;
        //        SmtpClient smtp = new SmtpClient();
        //        smtp.Host = "smtp.gmail.com";
        //        smtp.EnableSsl = true;
        //        NetworkCredential NetworkCred = new NetworkCredential();
        //        NetworkCred.UserName = "kasanihealthexpress@gmail.com";
        //        NetworkCred.Password = "smeagle@456";
        //        smtp.UseDefaultCredentials = true;
        //        smtp.Credentials = NetworkCred;
        //        smtp.Port = 587;
        //        smtp.Send(mm);
        //        //lblMessage.ForeColor = Color.Green;
        //        //lblMessage.Text = "Password has been sent to your email address.";
        //    }
        //    else
        //    {
        //        //lblMessage.ForeColor = Color.Red;
        //        //lblMessage.Text = "This email address does not match our records.";
        //    }
        //}



        [HttpPost]
        [Route("ForgotPassword")]
        public string ForgotPassword(ForgotPwdViewModel forgotpwd)
        {
            string Mobile = string.Empty;
            string password = string.Empty;
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spForgotPwd";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@Email", forgotpwd.Number);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                using (SqlDataReader sdr = sqlcmd.ExecuteReader())
                {
                    if (sdr.Read())
                    {
                        Mobile = sdr["UserMobile"].ToString();
                        password = sdr["UserPwd"].ToString();
                    }
                }
                sqlcon.Close();
            }
            if (!string.IsNullOrEmpty(password))
            {
                MailMessage mm = new MailMessage("kasanihealthexpress@gmail.com", forgotpwd.Number.Trim());
                mm.Subject = "Password Recovery";
                mm.Body = string.Format("Hi {0},<br /><br />Your password is {1}.<br /><br />Thank You.", password);
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential();
                NetworkCred.UserName = "kasanihealthexpress@gmail.com";
                NetworkCred.Password = "smeagle@456";
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                smtp.Send(mm);
                //lblMessage.ForeColor = Color.Green;
                //lblMessage.Text = "Password has been sent to your email address.";
            }
            return password;
        }




        //[HttpPost]
        //[Route("ForgotPassword")]
        //public string ForgotPassword(ForgotPwdViewModel pwd)
        //{
        //    object rootclient;
        //    using (SqlConnection sqlcon = new SqlConnection(conStr))
        //    {
        //        SqlCommand sqlcmd = new SqlCommand();
        //        sqlcmd.CommandText = "spGetAmbulanceOwnerDetails";
        //        sqlcmd.CommandType = CommandType.StoredProcedure;
        //        sqlcmd.Parameters.AddWithValue("@EmailId", pwd.Email);
        //        sqlcmd.Connection = sqlcon;
        //        sqlcon.Open();
        //        rootclient = sqlcmd.ExecuteScalar();
        //    }

        //    if (rootclient == null)
        //    {
        //        using (SqlConnection sqlcon = new SqlConnection(conStr))
        //        {
        //            SqlCommand sqlcmd = new SqlCommand();
        //            sqlcmd.Connection = sqlcon;
        //            sqlcmd.CommandText = "spGetPatientDetails";
        //            sqlcmd.CommandType = CommandType.StoredProcedure;
        //            sqlcmd.Parameters.AddWithValue("@EmailId", pwd.Email);
        //            sqlcon.Open();
        //            rootclient = sqlcmd.ExecuteScalar();
        //        }
        //    }

        //    return Convert.ToString(rootclient);
        //}

        [HttpPost]
        [Route("AmbOwnerNameExists/{AmbOwnerName}")]
        public string IsAmbOwnerNameExists(string AmbOwnerName)
        {
            object ambOwner;
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandText = "spCheckAmbOwnUsernameExists";
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Username", AmbOwnerName);
                sqlCmd.Connection = sqlcon;
                sqlcon.Open();
                ambOwner = sqlCmd.ExecuteScalar();
            }

            return Convert.ToString(ambOwner);
        }

        [HttpPost]
        [Route("AmbOwnerEmailExists/{AmbOwnerMail}")]
        public string IsAmbOwnerEmailExists(string AmbOwnerMail)
        {
            object ambOwner;
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandText = "spCheckAmbOwnEmailExists";
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@EmailId", AmbOwnerMail);
                sqlCmd.Connection = sqlcon;
                sqlcon.Open();
                ambOwner = sqlCmd.ExecuteScalar();
            }

            return Convert.ToString(ambOwner);
        }

        [HttpPost]
        [Route("PatientNameExists/{PatientName}")]
        public string IsPatientNameExists(string PatientName)
        {
            object patient;
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandText = "spCheckPatientNameExists";
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Name", PatientName);
                sqlCmd.Connection = sqlcon;
                sqlcon.Open();
                patient = sqlCmd.ExecuteScalar();
            }
            return Convert.ToString(patient);
        }

        [HttpPost]
        [Route("PatientEmailExists/{PatientMail}")]
        public string IsPatientEmailExists(string PatientMail)
        {
            object patient;
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandText = "spCheckPatientEmailExists";
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@EmailId", PatientMail);
                sqlCmd.Connection = sqlcon;
                sqlcon.Open();
                patient = sqlCmd.ExecuteScalar();
            }

            return Convert.ToString(patient);
        }
    }
}
