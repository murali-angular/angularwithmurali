﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    public class LoginViewModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class LoginResponse
    {
        public string SignUpID { get; set; }
        public int UserTypeId { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
    }

    public class changepwd
    {
        public int SignUpID { get; set; }
        public string CurrentPwd { get; set; }
        public string NewPwd { get; set; }

    }

    [RoutePrefix("Login")]
    public class LoginController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("Authenticate")]
        public LoginResponse Authenticate(LoginViewModel login)
        {
            LoginResponse loginResponse = new LoginResponse();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spAuthenticate";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@UserName", login.UserName);
                sqlcmd.Parameters.AddWithValue("@Password", login.Password);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    loginResponse = new LoginResponse()
                    {
                        SignUpID = reader["SignUpID"].ToString(),
                        UserTypeId = Convert.ToInt32(reader["UserTypeId"]),
                        Status = "PASS"
                    };
                }

                if(string.IsNullOrWhiteSpace(loginResponse.SignUpID))
                {
                    loginResponse = new LoginResponse()
                    {
                        Status = "FAIL",
                        Message = "Invalid Credentials" 
                    };
                }

                return loginResponse;
            }
        }


        [HttpPost]
        [Route("ChangePwd")]
        public string ChangePwd(changepwd changepwdObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spChngPwd";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpId", changepwdObj.SignUpID);
                sqlcmd.Parameters.AddWithValue("@Currpwd", changepwdObj.CurrentPwd);
                sqlcmd.Parameters.AddWithValue("@Newpwd", changepwdObj.NewPwd);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        //[HttpPost]
        //[Route("ConfirmPassword")]
        //public SqlDataReader ConfirmPassword(loginviewmodel login)
        //{
        //    SqlDataReader NewReader;
        //    List<loginviewmodel> ClientList = new List<loginviewmodel>();
        //    SqlConnection sqlcon = new SqlConnection(conStr);
        //    SqlCommand sqlcmd = new SqlCommand("select * from tbl_Client where ClientName='" + login.UserName + "' and Password='" + login.Password + "'", sqlcon);
        //    sqlcon.Open();
        //    SqlDataReader reader = sqlcmd.ExecuteReader();
        //    while (reader.Read())
        //    {
        //        loginviewmodel client = new loginviewmodel()
        //        {
        //            UserName = reader["ClientName"].ToString(),
        //            Password = reader["Password"].ToString(),
        //        };

        //       ClientList.Add(client);
        //    }
        //    sqlcon.Close();
        //    if (reader == null)
        //    {
        //        SqlCommand sqlcmd1 = new SqlCommand("select UserName,Password from tbl_User where UserName='" + login.UserName + "' and Password ='" + login.Password + "'", sqlcon);
        //        sqlcon.Open();
        //        SqlDataReader reader2 = sqlcmd.ExecuteReader();
        //        while (reader.Read())
        //        {
        //            loginviewmodel client = new loginviewmodel()
        //            {
        //                UserName = reader["ClientName"].ToString(),
        //                Password = reader["Password"].ToString(),
        //            };

        //            ClientList.Add(client);
        //        }
        //        sqlcon.Close();
        //    }
        //    return reader;

        //}
    }
}