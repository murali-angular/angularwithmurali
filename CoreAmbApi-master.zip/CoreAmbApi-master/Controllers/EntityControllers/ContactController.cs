﻿using CoreWebApiApp.Models;
using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace CoreWebApiApp.Controllers
{
    [RoutePrefix("Contact")]
    public class ContactController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertContactEnquiry")]
        public string InsertContactEnquiry(ContactViewModel contactViewModel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterContactDetails";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@UserName", contactViewModel.UserName);
                sqlcmd.Parameters.AddWithValue("@UserMail", contactViewModel.UserMail);
                sqlcmd.Parameters.AddWithValue("@UserNum", contactViewModel.UserNum);
                sqlcmd.Parameters.AddWithValue("@UserServiceTypeId", contactViewModel.UserServiceTypeId);
                sqlcmd.Parameters.AddWithValue("@UserServiceType", contactViewModel.UserServiceType);
                sqlcmd.Parameters.AddWithValue("@UserMessage", contactViewModel.UserMessage);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditedDate", DateTime.Now);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }
    }
}