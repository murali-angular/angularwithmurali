﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("Agent")]
    public class AgentController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertAgent")]
        public string InsertAgent(AgentViewModel agentviewmodel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAgentInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AgentName", agentviewmodel.AgentName);
                sqlcmd.Parameters.AddWithValue("@AgentNumber", agentviewmodel.AgentNumber);
                sqlcmd.Parameters.AddWithValue("@AgentAltNumber", agentviewmodel.AgentAltNumber);
                sqlcmd.Parameters.AddWithValue("@AgentMail", agentviewmodel.AgentMail);
                sqlcmd.Parameters.AddWithValue("@AgentGender", agentviewmodel.AgentGender);
                sqlcmd.Parameters.AddWithValue("@AgentAddress", agentviewmodel.AgentAddress);
                sqlcmd.Parameters.AddWithValue("@AgentCode", agentviewmodel.AgentCode);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");
                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("updateAgent")]
        public string updateAgent(AgentViewModel agentviewmodel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAgentInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;

                sqlcmd.Parameters.AddWithValue("@AgentName", agentviewmodel.AgentName);
                sqlcmd.Parameters.AddWithValue("@AgentNumber", agentviewmodel.AgentNumber);
                sqlcmd.Parameters.AddWithValue("@AgentAltNumber", agentviewmodel.AgentAltNumber);
                sqlcmd.Parameters.AddWithValue("@AgentMail", agentviewmodel.AgentMail);
                sqlcmd.Parameters.AddWithValue("@AgentGender", agentviewmodel.AgentGender);
                sqlcmd.Parameters.AddWithValue("@AgentAddress", agentviewmodel.AgentAddress);
                sqlcmd.Parameters.AddWithValue("@AgentCode", agentviewmodel.AgentCode);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");
                //sqlcmd.Parameters.AddWithValue("@AddedDate", agentviewmodel.AddedDate);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.ExecuteNonQuery();
                return "Updated: " + agentviewmodel.AgentName;
            }
        }

        [HttpDelete]
        [Route("DeleteAgent/{AgentID}")]
        public string DeleteAgent(int AgentID)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAgentInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AgentID", AgentID);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Delete");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                return "Deleted";
            }
        }

        [HttpGet]
        [Route("GetAgent")]
        public List<AgentViewModel> GetAgent()
        {
            List<AgentViewModel> agentLst = new List<AgentViewModel>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAgentInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AgentViewModel agent = new AgentViewModel()
                    {
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AgentName = reader["AgentName"].ToString(),
                        AgentNumber = reader["AgentNumber"].ToString(),
                        AgentAltNumber = reader["AgentAltNumber"].ToString(),

                        AgentMail = reader["AgentMail"].ToString(),
                        AgentGender = reader["AgentGender"].ToString(),
                        AgentAddress = reader["AgentAddress"].ToString(),

                        AgentCode = reader["AgentCode"].ToString()
                        //AddedDate = Convert.ToDateTime(reader["AddedDate"]),
                        //EditDate = Convert.ToDateTime(reader["EditDate"])

                    };

                    agentLst.Add(agent);
                }
            }
            return agentLst;
        }

        [HttpGet]
        [Route("GetAgentById/{AgentID}")]
        public AgentViewModel GetAgentById(int AgentID)
        {
            AgentViewModel ambulance = new AgentViewModel();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterAgentInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AgentID", AgentID);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new AgentViewModel()
                    {
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        AgentName = reader["AgentName"].ToString(),
                        AgentNumber = reader["AgentNumber"].ToString(),
                        AgentAltNumber = reader["AgentAltNumber"].ToString(),

                        AgentMail = reader["AgentMail"].ToString(),
                        AgentGender = reader["AgentGender"].ToString(),
                        AgentAddress = reader["AgentAddress"].ToString(),

                        AgentCode = reader["AgentCode"].ToString()
                        //AddedDate = Convert.ToDateTime(reader["AddedDate"]),
                        //EditDate = Convert.ToDateTime(reader["EditDate"])
                    };
                }
            }
            return ambulance;
        }


    }
}
