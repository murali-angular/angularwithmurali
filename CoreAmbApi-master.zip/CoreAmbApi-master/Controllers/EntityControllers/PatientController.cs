﻿using CoreWebApiApp.Models;
using Ambufree.Library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using CoreWebApiApp.Models.Entities;

namespace CoreWebApiApp.Controllers
{
    [RoutePrefix("Patient")]
    public class PatientController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertPatientDetails")]
        public string InsertPatientDetails(PatientReg patientViewModel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterPatientInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@PatientName", patientViewModel.PatientName);
                sqlcmd.Parameters.AddWithValue("@PatientNumber", patientViewModel.PatientNumber);
                sqlcmd.Parameters.AddWithValue("@patientMail", patientViewModel.patientMail);
                sqlcmd.Parameters.AddWithValue("@PatientAddress", patientViewModel.PatientAddress);
                sqlcmd.Parameters.AddWithValue("@PatientCondition", patientViewModel.PatientCondition);
                sqlcmd.Parameters.AddWithValue("@PatientGender", patientViewModel.PatientGender);
                sqlcmd.Parameters.AddWithValue("@SignUpId", patientViewModel.SignUpId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");
                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("UpdatePatientDetailsByID")]
        public string UpdatePatientDetailsByID(PatientReg patientViewModel)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterPatientInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@PatientName", patientViewModel.PatientName);
                sqlcmd.Parameters.AddWithValue("@PatientNumber", patientViewModel.PatientNumber);
                sqlcmd.Parameters.AddWithValue("@patientMail", patientViewModel.patientMail);
                sqlcmd.Parameters.AddWithValue("@PatientAddress", patientViewModel.PatientAddress);
                sqlcmd.Parameters.AddWithValue("@PatientCondition", patientViewModel.PatientCondition);
                sqlcmd.Parameters.AddWithValue("@PatientGender", patientViewModel.PatientGender);
                sqlcmd.Parameters.AddWithValue("@SignUpId", patientViewModel.SignUpId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");
                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                sqlcmd.ExecuteNonQuery();
            }
            return "Updated";
        }

        [HttpGet]
        [Route("GetPatientDetailsByID/{patientID}")]
        public PatientReg GetPatientDetailsByID(int patientID)
        {
            PatientReg patientViewModel = new PatientReg();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterPatientInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@PatientID", patientID);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();
                SqlDataReader reader = sqlcmd.ExecuteReader();
                while (reader.Read())
                {
                    patientViewModel = new PatientReg()
                    {
                        SignUpId = Convert.ToInt32(reader["SignUpId"]),
                        PatientID = Convert.ToInt32(reader["PatientID"]),
                        PatientName = reader["PatientName"].ToString(),
                        PatientNumber = reader["PatientNumber"].ToString(),
                        PatientAddress = reader["PatientAddress"].ToString(),
                        PatientCondition = reader["PatientCondition"].ToString(),
                        PatientGender = reader["PatientGender"].ToString(),
                        patientMail = reader["patientMail"].ToString()

                    };
                }
            }
            return patientViewModel;
        }
    }
}