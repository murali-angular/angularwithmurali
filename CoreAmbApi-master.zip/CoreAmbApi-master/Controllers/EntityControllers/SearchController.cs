﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    public class customsearch
    {
       public Array AgentSearch { get; set; }
       public Array HospReg { get; set; }
    }

    [RoutePrefix("Search")]
    public class SearchController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpGet]
        [Route("GetAgentsAmbList")]
        public List<AgentSearch> GetAgentsAmbList()
        {
            List<AgentSearch> ambulanceLst = new List<AgentSearch>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spGetHospitalAmbulanceList";
                sqlcmd.CommandType = CommandType.StoredProcedure;

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    AgentSearch ambulance = new AgentSearch()
                    {

                        AmbSource = reader["AmbSource"].ToString(),
                        AmbName = reader["AmbName"].ToString(),
                        AmbNumber = reader["AmbNumber"].ToString(),
                        AmbMail = reader["AmbMail"].ToString(),
                        AmbAddress = reader["AmbAddress"].ToString(),
                        AmbNumberPlate = reader["AmbNumberPlate"].ToString(),
                        AmbType = reader["AmbType"].ToString(),
                        DriverName = reader["DriverName"].ToString(),
                        DriverNum = reader["DriverNum"].ToString(),
                        Priority = reader["Priority"].ToString(),
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }


        //[HttpGet]
        //[Route("searchCustomResults")]
        //public List<AgentSearch> searchCustomResults(customsearch search)
        //{
        //    List<customsearch> ambulanceLst = new List<customsearch>();
        //    using (SqlConnection sqlcon = new SqlConnection(conStr))
        //    {
        //        SqlCommand sqlcmd = new SqlCommand();
        //        sqlcmd.CommandText = "spGetHospitalAmbulanceList";
        //        sqlcmd.CommandType = CommandType.StoredProcedure;

        //        sqlcmd.Connection = sqlcon;
        //        sqlcon.Open();

        //        SqlDataReader reader = sqlcmd.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            customsearch ambulance = new customsearch()
        //            {

        //                AgentSearch = Convert.ToString(reader["AgentSearch"]),
        //                HospReg = Convert.(reader["HospReg"]),

        //            };

        //            ambulanceLst.Add(ambulance);
        //        }
        //    }
        //    return ambulanceLst;
        //}
    }
}
