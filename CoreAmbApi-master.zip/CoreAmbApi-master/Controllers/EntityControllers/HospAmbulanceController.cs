﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("HospitalAmbulance")]
    public class HospAmbulanceController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertHospAmbulance")]
        public string InsertHospAmbulance(HospAmbReg hospAmbObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", hospAmbObj.HospId);
                sqlcmd.Parameters.AddWithValue("@HospAmbName", hospAmbObj.HospAmbName);
                sqlcmd.Parameters.AddWithValue("@HospAmbNumber", hospAmbObj.HospAmbNumber);
                sqlcmd.Parameters.AddWithValue("@HospAltAmbNumber", hospAmbObj.HospAltAmbNumber);

                sqlcmd.Parameters.AddWithValue("@HospAmbEmail", hospAmbObj.HospAmbEmail);
                sqlcmd.Parameters.AddWithValue("@HospAmbAddress", hospAmbObj.HospAmbAddress);
                sqlcmd.Parameters.AddWithValue("@HospAmbNumberPlate", hospAmbObj.HospAmbNumberPlate);

                sqlcmd.Parameters.AddWithValue("@HospAmbType", hospAmbObj.HospAmbType);
                sqlcmd.Parameters.AddWithValue("@HospAmbDriverName", hospAmbObj.HospAmbDriverName);

                sqlcmd.Parameters.AddWithValue("@HospAmbDriverNumber", hospAmbObj.HospAmbDriverNumber);
                sqlcmd.Parameters.AddWithValue("@HospAmbDesc", hospAmbObj.HospAmbDesc);

                sqlcmd.Parameters.AddWithValue("@IsSubscribe", hospAmbObj.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", hospAmbObj.SubscriptionPlan);
                sqlcmd.Parameters.AddWithValue("@HospAmbImgPath", hospAmbObj.HospAmbImgPath);


                sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("updateHospAmbulance")]
        public string updateHospAmbulance(HospAmbReg hospAmbObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", hospAmbObj.HospId);
                sqlcmd.Parameters.AddWithValue("@HospAmbName", hospAmbObj.HospAmbName);
                sqlcmd.Parameters.AddWithValue("@HospAmbNumber", hospAmbObj.HospAmbNumber);
                sqlcmd.Parameters.AddWithValue("@HospAltAmbNumber", hospAmbObj.HospAltAmbNumber);

                sqlcmd.Parameters.AddWithValue("@HospAmbEmail", hospAmbObj.HospAmbEmail);
                sqlcmd.Parameters.AddWithValue("@HospAmbAddress", hospAmbObj.HospAmbAddress);
                sqlcmd.Parameters.AddWithValue("@HospAmbNumberPlate", hospAmbObj.HospAmbNumberPlate);

                sqlcmd.Parameters.AddWithValue("@HospAmbType", hospAmbObj.HospAmbType);
                sqlcmd.Parameters.AddWithValue("@HospAmbDriverName", hospAmbObj.HospAmbDriverName);

                sqlcmd.Parameters.AddWithValue("@HospAmbDriverNumber", hospAmbObj.HospAmbDriverNumber);
                sqlcmd.Parameters.AddWithValue("@HospAmbDesc", hospAmbObj.HospAmbDesc);

                sqlcmd.Parameters.AddWithValue("@IsSubscribe", hospAmbObj.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", hospAmbObj.SubscriptionPlan);
                sqlcmd.Parameters.AddWithValue("@HospAmbImgPath", hospAmbObj.HospAmbImgPath);


                sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.ExecuteNonQuery();
                return "Updated: " + hospAmbObj.HospAmbName;
            }
        }

        [HttpPost]
        [Route("DeleteHospitalAmb/{HospAmbId}")]
        public string DeleteAmbulance(int HospAmbId)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospAmbId", HospAmbId);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Delete");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                return "Deleted";
            }
        }

        [HttpGet]
        [Route("GetHospitalAmbList")]
        public List<HospAmbReg> GetHospitalAmbList()
        {
            List<HospAmbReg> ambulanceLst = new List<HospAmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;

                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospAmbReg ambulance = new HospAmbReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospAmbId = Convert.ToInt32(reader["HospAmbId"]),

                        HospAmbName = reader["HospAmbName"].ToString(),
                        HospAmbNumber = reader["HospAmbNumber"].ToString(),
                        HospAltAmbNumber = reader["HospAltAmbNumber"].ToString(),
                        HospAmbEmail = reader["HospAmbEmail"].ToString(),
                        HospAmbAddress = reader["HospAmbAddress"].ToString(),
                        HospAmbType = reader["HospAmbType"].ToString(),
                        HospAmbDriverName = reader["HospAmbDriverName"].ToString(),
                        HospAmbDriverNumber = reader["HospAmbDriverNumber"].ToString(),
                        HospAmbNumberPlate = reader["HospAmbNumberPlate"].ToString(),
                        HospAmbDesc = reader["HospAmbDesc"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospAmbImgPath = reader["HospAmbImgPath"].ToString(),

                        AddedDate = Convert.ToDateTime("AddedDate"),
                        EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GethospAmbByHospAmbId/{HospAmbId}")]
        public HospAmbReg GetAmbulanceById(int HospAmbId)
        {
            HospAmbReg ambulance = new HospAmbReg();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospAmbId", HospAmbId);

                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new HospAmbReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospAmbId = Convert.ToInt32(reader["HospAmbId"]),

                        HospAmbName = reader["HospAmbName"].ToString(),
                        HospAmbNumber = reader["HospAmbNumber"].ToString(),
                        HospAltAmbNumber = reader["HospAltAmbNumber"].ToString(),
                        HospAmbEmail = reader["HospAmbEmail"].ToString(),
                        HospAmbAddress = reader["HospAmbAddress"].ToString(),
                        HospAmbType = reader["HospAmbType"].ToString(),
                        HospAmbDriverName = reader["HospAmbDriverName"].ToString(),
                        HospAmbDriverNumber = reader["HospAmbDriverNumber"].ToString(),
                        HospAmbNumberPlate = reader["HospAmbNumberPlate"].ToString(),
                        HospAmbDesc = reader["HospAmbDesc"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospAmbImgPath = reader["HospAmbImgPath"].ToString(),

                        AddedDate = Convert.ToDateTime("AddedDate"),
                        EditDate = Convert.ToDateTime("EditDate")
                    };
                }
            }
            return ambulance;
        }


        [HttpGet]
        [Route("GetHospAmbRecordsHospID/{HospId}")]
        public List<HospAmbReg> GetHospAmbRecordsHospID(int HospId)
        {
            List<HospAmbReg> ambulanceLst = new List<HospAmbReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospAmbInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", HospId);
                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospAmbReg ambulance = new HospAmbReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        HospAmbId = Convert.ToInt32(reader["HospAmbId"]),

                        HospAmbName = reader["HospAmbName"].ToString(),
                        HospAmbNumber = reader["HospAmbNumber"].ToString(),
                        HospAltAmbNumber = reader["HospAltAmbNumber"].ToString(),
                        HospAmbEmail = reader["HospAmbEmail"].ToString(),
                        HospAmbAddress = reader["HospAmbAddress"].ToString(),
                        HospAmbType = reader["HospAmbType"].ToString(),
                        HospAmbDriverName = reader["HospAmbDriverName"].ToString(),
                        HospAmbDriverNumber = reader["HospAmbDriverNumber"].ToString(),
                        HospAmbNumberPlate = reader["HospAmbNumberPlate"].ToString(),
                        HospAmbDesc = reader["HospAmbDesc"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospAmbImgPath = reader["HospAmbImgPath"].ToString(),

                        AddedDate = Convert.ToDateTime("AddedDate"),
                        EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }
    }
}
