﻿using CoreWebApiApp.Models.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoreWebApiApp.Controllers.EntityControllers
{
    [RoutePrefix("Hospital")]
    public class HospitalController : ApiController
    {
        #region Variables
        string conStr = ConfigurationManager.ConnectionStrings["myDBCon"].ToString();
        #endregion

        [HttpPost]
        [Route("InsertHospital")]
        public string InsertHospital(HospReg hospObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospitalInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpID", hospObj.SignUpID);
                sqlcmd.Parameters.AddWithValue("@AgentId", hospObj.AgentId);

                sqlcmd.Parameters.AddWithValue("@HospName", hospObj.HospName);
                sqlcmd.Parameters.AddWithValue("@HospMail", hospObj.HospMail);
                sqlcmd.Parameters.AddWithValue("@HospNum", hospObj.HospNum);
                sqlcmd.Parameters.AddWithValue("@HospAltNum", hospObj.HospAltNum);

                sqlcmd.Parameters.AddWithValue("@HospAddress", hospObj.HospAddress);
                sqlcmd.Parameters.AddWithValue("@HospType", hospObj.HospType);
                sqlcmd.Parameters.AddWithValue("@HospImgPath", hospObj.HospImgPath);
                sqlcmd.Parameters.AddWithValue("@IsSubscribe", hospObj.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", hospObj.SubscriptionPlan);

                sqlcmd.Parameters.AddWithValue("@HospDesc", hospObj.HospDesc);

                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Insert");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();


                int status = sqlcmd.ExecuteNonQuery();
                if (status > 0)
                    return "PASS";
                else
                    return "FAIL";
            }
        }

        [HttpPost]
        [Route("updateHospital")]
        public string updateHospital(HospReg hospObj)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospitalInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@SignUpID", hospObj.SignUpID);
                sqlcmd.Parameters.AddWithValue("@AgentId", hospObj.AgentId);

                sqlcmd.Parameters.AddWithValue("@HospName", hospObj.HospName);
                sqlcmd.Parameters.AddWithValue("@HospMail", hospObj.HospMail);
                sqlcmd.Parameters.AddWithValue("@HospNum", hospObj.HospNum);
                sqlcmd.Parameters.AddWithValue("@HospAltNum", hospObj.HospAltNum);

                sqlcmd.Parameters.AddWithValue("@HospAddress", hospObj.HospAddress);
                sqlcmd.Parameters.AddWithValue("@HospType", hospObj.HospType);
                sqlcmd.Parameters.AddWithValue("@HospImgPath", hospObj.HospImgPath);
                sqlcmd.Parameters.AddWithValue("@IsSubscribe", hospObj.IsSubscribe);
                sqlcmd.Parameters.AddWithValue("@SubscriptionPlan", hospObj.SubscriptionPlan);

                sqlcmd.Parameters.AddWithValue("@HospImgPath", hospObj.SubscriptionPlan);
                sqlcmd.Parameters.AddWithValue("@HospDesc", hospObj.HospDesc);

                //sqlcmd.Parameters.AddWithValue("@AddedDate", DateTime.Now);
                //sqlcmd.Parameters.AddWithValue("@EditDate", DateTime.Now);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Update");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                sqlcmd.ExecuteNonQuery();
                return "Updated: " + hospObj.HospName;
            }
        }

        [HttpPost]
        [Route("DeleteHospital/{HospID}")]
        public string DeleteHospital(int HospID)
        {
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospitalInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospID", HospID);

                sqlcmd.Parameters.AddWithValue("@StatementType", "Delete");


                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                int status = sqlcmd.ExecuteNonQuery();
                return "Deleted";
            }
        }

        [HttpGet]
        [Route("GetHospitalList")]
        public List<HospReg> GetHospitalList()
        {
            List<HospReg> ambulanceLst = new List<HospReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospitalInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@StatementType", "Select");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospReg ambulance = new HospReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),

                        HospName = reader["HospName"].ToString(),
                        HospMail = reader["HospMail"].ToString(),
                        HospNum = reader["HospNum"].ToString(),
                        HospAltNum = reader["HospAltNum"].ToString(),

                        HospAddress = reader["HospAddress"].ToString(),
                        HospType = reader["HospType"].ToString(),

                        HospImgPath = reader["HospImgPath"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospDesc = reader["HospDesc"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }

        [HttpGet]
        [Route("GethospitalById/{HospId}")]
        public HospReg GethospitalById(int HospId)
        {
            HospReg ambulance = new HospReg();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "MasterHospitalInsertUpdateDelete";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@HospId", HospId);
                sqlcmd.Parameters.AddWithValue("@StatementType", "SelectOnly");

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    ambulance = new HospReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),

                        HospName = reader["HospName"].ToString(),
                        HospMail = reader["HospMail"].ToString(),
                        HospNum = reader["HospNum"].ToString(),
                        HospAltNum = reader["HospAltNum"].ToString(),

                        HospAddress = reader["HospAddress"].ToString(),
                        HospType = reader["HospType"].ToString(),

                        HospImgPath = reader["HospImgPath"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospDesc = reader["HospDesc"].ToString(),

                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };
                }
            }
            return ambulance;
        }

        [HttpGet]
        [Route("GetHospSearch/{hosploc}/{hospName}")]
        public List<HospReg> GetHospSearch(string hosploc, string hospName)
        {
            List<HospReg> ambulanceLst = new List<HospReg>();
            using (SqlConnection sqlcon = new SqlConnection(conStr))
            {
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "spGetHospSearchbyLocandNameDetails";
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@AreaName", hosploc);
                sqlcmd.Parameters.AddWithValue("@HospName", hospName);

                sqlcmd.Connection = sqlcon;
                sqlcon.Open();

                SqlDataReader reader = sqlcmd.ExecuteReader();

                while (reader.Read())
                {
                    HospReg ambulance = new HospReg()
                    {
                        HospId = Convert.ToInt32(reader["HospId"]),
                        AgentId = Convert.ToInt32(reader["AgentId"]),
                        SignUpID = Convert.ToInt32(reader["SignUpID"]),

                        HospName = reader["HospName"].ToString(),
                        HospMail = reader["HospMail"].ToString(),
                        HospNum = reader["HospNum"].ToString(),
                        HospAltNum = reader["HospAltNum"].ToString(),

                        HospAddress = reader["HospAddress"].ToString(),
                        HospType = reader["HospType"].ToString(),

                        HospImgPath = reader["HospImgPath"].ToString(),
                        IsSubscribe = reader["IsSubscribe"].ToString(),
                        SubscriptionPlan = reader["SubscriptionPlan"].ToString(),
                        HospDesc = reader["HospDesc"].ToString()


                        //AddedDate = Convert.ToDateTime("AddedDate"),
                        //EditDate = Convert.ToDateTime("EditDate")
                    };

                    ambulanceLst.Add(ambulance);
                }
            }
            return ambulanceLst;
        }
    }
}
