﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class PatientReg
    {

        public int PatientID { get; set; }
        public int SignUpId { get; set; }


        public string PatientName { get; set; }
        public string PatientNumber { get; set; }
        public string PatientAddress { get; set; }
        public string PatientCondition { get; set; }
        public string PatientGender { get; set; }

        public string patientMail { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }
    }
}