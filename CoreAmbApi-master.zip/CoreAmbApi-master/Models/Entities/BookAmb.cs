﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class BookAmb
    {
        public int AmbBookID { get; set; }
        public int AmbID { get; set; }
        public int PatientID { get; set; }
        public DateTime SelectedDate { get; set; }
        public DateTime SelectedTime { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }

    }
}