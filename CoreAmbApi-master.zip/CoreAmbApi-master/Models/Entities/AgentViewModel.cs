﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class AgentViewModel
    {
        public int AgentId { get; set; }
        public string AgentName { get; set; }
        public string AgentNumber { get; set; }
        public string AgentAltNumber { get; set; }
        public string AgentMail { get; set; }
        public string AgentGender { get; set; }
        public string AgentAddress { get; set; }
        public string AgentCode { get; set; }

        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }

    }
}