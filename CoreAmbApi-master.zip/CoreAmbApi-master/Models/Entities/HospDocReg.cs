﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class HospDocReg
    {

        public int HospId { get; set; }
        public int HospDocId { get; set; }
        public string HospDocName { get; set; }
        public string HospDocMail { get; set; }
        public string HospDocNum { get; set; }
        public string HospDocAltNum { get; set; }

        public string HospDocQualification { get; set; }
        public string HospDocStartTime { get; set; }
        public string HospDocEndTime { get; set; }
        public string HospDocSpecialization { get; set; }
        public string HospDocDescription { get; set; }
        public string HospDocImgPath { get; set; }
        public string HospDocConsultingFee { get; set; }
        public string HospDocAddress { get; set; }

        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }

    }
}