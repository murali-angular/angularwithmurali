﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class BookHospDoc
    {
        public int BookDocId { get; set; }
        public int HospDocId { get; set; }
        public int PatientID { get; set; }
        public string SelectedDate { get; set; }
        public string SelectedTime { get; set; }
        //public DateTime AddedDate { get; set; }
        //public DateTime EditDate { get; set; }
    }
}