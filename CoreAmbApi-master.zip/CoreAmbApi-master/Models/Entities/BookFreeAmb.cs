﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class BookFreeAmb
    {
        public int BookHospAmbId { get; set; }

        public int HospId { get; set; }
        public int HospAmbId { get; set; }
        public int PatientID { get; set; }
        public DateTime SelectedDate { get; set; }
        public DateTime SelectedTime { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }
    }
}