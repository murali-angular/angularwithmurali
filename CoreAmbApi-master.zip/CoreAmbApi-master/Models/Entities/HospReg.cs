﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class HospReg
    {
        public int HospId { get; set; }
        public int SignUpID { get; set; }
        public int AgentId { get; set; }
        public string HospName { get; set; }
        public string HospMail { get; set; }
        public string HospNum { get; set; }
        public string HospAltNum { get; set; }
        public string HospAddress { get; set; }
        public string HospType { get; set; }
        public string HospImgPath { get; set; }
        public string IsSubscribe { get; set; }
        public string SubscriptionPlan { get; set; }
        public string HospDesc { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }

    }
}