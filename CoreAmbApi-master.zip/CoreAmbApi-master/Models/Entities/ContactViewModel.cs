﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class ContactViewModel
    {
        public int ContactId { get; set; }
        public string UserName { get; set; }
        public string UserMail { get; set; }
        public string UserNum { get; set; }
        public int UserServiceTypeId { get; set; }
        public string UserServiceType { get; set; }
        public string UserMessage { get; set; }

    }
}