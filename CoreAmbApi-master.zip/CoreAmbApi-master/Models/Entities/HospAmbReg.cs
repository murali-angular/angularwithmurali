﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class HospAmbReg
    {
        public int HospId { get; set; }
        public int HospAmbId { get; set; }
        public string HospAmbName { get; set; }

        public string HospAmbNumber { get; set; }

        public string HospAltAmbNumber { get; set; }
        public string HospAmbNumberPlate { get; set; }


        public string HospAmbEmail { get; set; }
        public string HospAmbAddress { get; set; }
        public string HospAmbType { get; set; }
        public string HospAmbDriverName { get; set; }
        public string HospAmbDriverNumber { get; set; }

        public string HospAmbDesc { get; set; }

        public string IsSubscribe { get; set; }
        public string SubscriptionPlan { get; set; }
        public string HospAmbImgPath { get; set; }

        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }
    }
}