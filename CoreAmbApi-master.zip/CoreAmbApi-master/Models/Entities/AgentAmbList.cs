﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class AgentAmbList
    {
        public string AmbSource { get; set; }

        public string AmbName { get; set; }
        public string AmbNumber { get; set; }
        public string AmbMail { get; set; }
        public string AmbAddress { get; set; }
        public string AmbNumberPlate { get; set; }


        public string AmbType { get; set; }
        public string DriverName { get; set; }
        public string DriverNum { get; set; }
        public string Priority { get; set; }

    }
}