﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class SignUp
    {
        public int SignUpId { get; set; }
        public string UserMail { get; set; }
        public string UserMobile { get; set; }
        public string UserPwd { get; set; }
        public int UserTypeID { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }
    }
}