﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoreWebApiApp.Models.Entities
{
    public class AmbReg
    {
        public int AmbId { get; set; }
        public int SignUpID { get; set; }
        public int AgentId { get; set; }
        public string AmbName { get; set; }
        public string AmbNumber { get; set; }
        public string AmbAltNumber { get; set; }
        public string AmbMail { get; set; }
        public string AmbAddress { get; set; }
        public string AmbNumberPlate { get; set; }
        public string AmbType { get; set; }
        public string DriverName { get; set; }
        public string DriverNum { get; set; }
        public string IsSubscribe { get; set; }
        public string SubscriptionPlan { get; set; }
        public string AmbImgPath { get; set; }
        public string AmbDescription { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime EditDate { get; set; }

    }
}